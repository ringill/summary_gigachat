# dash/dash_load_data.py
import glob
import logging
import os

import pandas as pd
from config import app_config

# Поля с типом date в витрине DS
DE_files_date_fields = ['dtdate', 'dtdate_15_days', 'calc_date']

def Load_DE_data(folder_data_str, load_type='csv'):
    logging.info(f'dash_load_data.Load_DE_data: Начинаем загрузку с витриной от DE ...(  folder_data_str ={folder_data_str}  load_type ={load_type} )')

    # загрузка даннях из директории
    if load_type == 'csv':

        path = os.path.join(app_config.DE_data_path, folder_data_str)

        file_name = find_and_sort_files(path, 'ewi_etc_dev*.csv')[0]

        data_path = os.path.join(path, file_name)

        logging.info(f'Load_DE_data: data_path ={data_path} ')
        df = pd.read_csv(data_path,
                         delimiter=',',
                         parse_dates=DE_files_date_fields)

        for col in DE_files_date_fields:
            df[col] = pd.to_datetime(df[col], dayfirst=True).dt.date

    logging.info('dash_load_data.Load_DE_data: Закончили загрузку, отдаём df')

    return df


def find_and_sort_files(directory, pattern):
    """
    Функция, которая ищет файлы по заданному шаблону в указанной директории
    и возвращает отсортированный список найденных файлов (без путей).

    :param directory: строка с указанием директории для поиска
    :param pattern: маска файла (например, '*.csv')
    :return: отсортированный список файлов
    """

    logging.info(f'dash_load_data.find_and_sort_files: Ищем файлы в директоии ({directory}) по маске ({pattern})')

    search_path = os.path.join(directory, pattern)
    matched_files = glob.glob(search_path, recursive=True)

    matched_files.sort(key=os.path.getmtime, reverse=True)

    # Извлекаем только имена файлов без путей
    filenames_only = [os.path.basename(file) for file in matched_files]

    # Сортируем список файлов
    sorted_filenames = sorted(filenames_only)

    return sorted_filenames
