# dash/jwt_auth/authentification.py
import json
import logging
from json import JSONDecodeError
from typing import Optional

import jwt
import requests
from jwt.algorithms import RSAAlgorithm

from .settings import JWKS_SERVER, TEST_TOKEN, TEST_USER


class JWKSProviderNotAvailableException(Exception):
    """Провайдер недоступен."""


def get_provider_keys(jwks_server: str) -> dict:
    public_keys = {}
    try:
        jwks_keys = requests.get(jwks_server, timeout=5).json()
    except JSONDecodeError as e:
        logging.exception(f"Can't decode json from jwks provider {jwks_server} {e}")
        raise JWKSProviderNotAvailableException(e)

    for jwk in jwks_keys.get('keys', []):
        kid = jwk['kid']
        public_keys[kid] = RSAAlgorithm.from_jwk(json.dumps(jwk))

    return public_keys


def get_public_key(kid: str) -> str:
    public_keys = get_provider_keys(JWKS_SERVER)
    return public_keys[kid]


class UserObject:
    def __init__(self, login: str, roles: list[str], permissions: list[str], sid: Optional[str], ip: Optional[str]):
        self.login = login
        self.roles = roles
        self.permissions = permissions
        self.sid = sid
        self.ip = ip

    @property
    def is_authenticated(self) -> bool:
        return bool(self.login)

    @property
    def is_active(self) -> bool:
        return self.is_authenticated

    def __repr__(self) -> str:
        return self.login

    def to_dict(self):
        return self.__dict__


def get_user_from_jwt(jwt_token: str) -> UserObject:
    jwt_user = {'permissions': []}
    if jwt_token == TEST_TOKEN:
        jwt_user = TEST_USER
    else:
        kid = jwt.get_unverified_header(jwt_token)['kid']
        public_key = get_public_key(kid)

        try:
            user_info = jwt.decode(jwt_token, public_key, audience='PALM', algorithms='RS256')
            jwt_user['login'] = user_info['login']
            jwt_user['roles'] = user_info['roles']
            jwt_user['permissions'] = user_info['permissions']
            jwt_user['sid'] = user_info['sid']
            jwt_user['ip'] = user_info['ip_address']
        except jwt.InvalidSignatureError as e:
            logging.exception(f"Can't decode jwt token {jwt_token} with {public_key} {e}")
            raise

    return UserObject(**jwt_user)
