# dash/jwt_auth/settings.py
import os

STAND = os.getenv('stand', 'dev')
JWKS_SERVER = os.getenv('JWKS_SERVER')
TEST_TOKEN = os.getenv('TEST_TOKEN', 'test_token')
REQUIRED_ROLES = ['PALM_SANDBOX_UI_OPTIONS_USER']

TEST_USER = {
    'login': 'test_user',
    'roles': ['PALM_SANDBOX_UI_OPTIONS_USER'],
    'permissions': [
        'PALM_SANDBOX_UI_OPTIONS_VIEW',
        'PALM_SANDBOX_UI_OPTIONS_UPLOAD',
        'PALM_SANDBOX_UI_OPTIONS_EXECUTE',
        'PALM_SANDBOX_UI_OPTIONS_DOWNLOAD'
    ],
    'sid': '000000',
    'ip': '192.168.0.1'
}
