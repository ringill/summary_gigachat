# dash/jwt_auth/auth_middleware.py

import logging

from flask import request, session  # Импортируем session для сохранения данных пользователя
from jwt_auth.authentification import UserObject, get_user_from_jwt
from jwt_auth.settings import REQUIRED_ROLES, STAND, TEST_TOKEN


def auth_middleware():
    logging.info(f'start auth_middleware. Request path: {request.path}')
    jwt_token = None
    try:
        jwt_token = request.headers['Authorization'].split()[-1]
    except (KeyError, IndexError):
        pass
    if STAND.lower() == 'dev' or not STAND:
        logging.info('STAND is Dev. No JWT auth')
        jwt_token = TEST_TOKEN
    if not jwt_token:
        msg = 'JWT token is missing'
        logging.exception(msg)
        return False
    try:
        user: UserObject = get_user_from_jwt(jwt_token)
        # Сохраняем данные пользователя в сессии
        session['user'] = {
            'login': user.login,
            'roles': user.roles,
            'ip': user.ip
        }
    except Exception as e:
        logging.exception(e)
        return False
    if not any(role in user.roles for role in REQUIRED_ROLES):
        msg = 'Not allowed for current user roles'
        logging.exception(msg)
        return False
    return True
