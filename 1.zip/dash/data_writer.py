import os
import zipfile
import pandas as pd
from typing import Dict, List

from config import TableConfig, TableSaverMeta, split_file_params
from navigator.navigator_funcs import add_to_archive

# список поддерживаемых расширений
CSV_EXT = ".csv"
XLSX_EXT = ".xlsx"
JSON_EXT = ".json"

def save_excel_sheet(
    df: pd.DataFrame, 
    filepath: str, 
    datetime_format: str = 'DD.MM.YYYY', 
    date_format: str = 'DD.MM.YYYY', 
    engine: str = 'openpyxl',
    if_sheet_exists: str = 'replace', 
    mode: str = 'a',
    **kwargs
):
    
    if not os.path.exists(filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with pd.ExcelWriter(
            filepath, 
            datetime_format=datetime_format, 
            date_format=date_format
            ) as writer:
            df.to_excel(writer, **kwargs)
            
    else:
        with pd.ExcelWriter(
            filepath, 
            engine=engine, 
            if_sheet_exists=if_sheet_exists, 
            mode=mode, 
            datetime_format=datetime_format, 
            date_format=date_format
            ) as writer:
            df.to_excel(writer, **kwargs) 

class ExcelManager:
    def __init__(self):
        self.file_storage: Dict[str, Dict[str, pd.DataFrame]] = {}
        self.params_storage: Dict[str, Dict[str, dict]] = {}
        
    def add_file(self, df: pd.DataFrame, filepath: str, sheet_name: str, save_params: dict):
        if filepath not in self.file_storage:
            self.file_storage[filepath] = {}
            self.params_storage[filepath] = {}
        self.file_storage[filepath][sheet_name] = df
        self.params_storage[filepath][sheet_name] = save_params
        
    def save(
        self, 
        engine: str = 'xlsxwriter',
        datetime_format: str = 'DD.MM.YYYY', 
        date_format: str = 'DD.MM.YYYY',
    ):
        for filepath, sheets in self.file_storage.items():
            # os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with pd.ExcelWriter(
                filepath, 
                engine=engine,
                datetime_format=datetime_format, 
                date_format=date_format
            ) as writer:
                for sheet_name, df in sheets.items():
                    params = self.params_storage[filepath][sheet_name]
                    df.to_excel(writer, sheet_name=sheet_name, **params)
        self.file_storage.clear()
        self.params_storage.clear()
        
class ZipManager:
    def __init__(self):
        self.file_storage: Dict[str, List[str]] = {}
        
    def add_file(self, store_filepath: str, source_filepath: str):
        if store_filepath not in self.file_storage:
            self.file_storage[store_filepath] = []
        self.file_storage[store_filepath].append(source_filepath)
        
    def save(self):
        for store_filepath, source_filepaths in self.file_storage.items():
            os.makedirs(os.path.dirname(store_filepath), exist_ok=True)
            with zipfile.ZipFile(store_filepath, 'w') as zipf:
                for source_filepath in source_filepaths:
                    zipf.write(source_filepath, arcname=os.path.basename(source_filepath))
        self.file_storage.clear()
             
def write_df(df: pd.DataFrame, cfg: TableConfig):
    if not cfg.store_type:
        raise ValueError(f"No store type for table {cfg.name}")
    
    if cfg.store_transform:
        df = cfg.store_transform(df)
    
    if cfg.store_type == 'file':
        
        filepath, params = split_file_params(params=cfg.store_params)
        ext = os.path.splitext(filepath)[1]
        
        if ext == CSV_EXT:
            df.to_csv(filepath, **params)
        elif ext == XLSX_EXT:
            df.to_excel(filepath, **params)
            # save_excel_sheet(df=df, filepath=filepath, **params)
        else:
            raise ValueError(f"Unsupported file extension: {ext}")
    elif cfg.store_type == 'db':
        # потом пропишем
        pass
    else:
        raise ValueError(f"Unknown store type: {cfg.store_type}")

def write_data(tables_meta: List[TableSaverMeta]) -> None:
    
    excel_manager = ExcelManager()
    
    for meta in tables_meta:
        if meta.is_local_storetype:
            os.makedirs(meta.path, exist_ok=True)
            if meta.ext == CSV_EXT:
                meta.df.to_csv(meta.filepath, **meta.oth_params)
            elif meta.ext == XLSX_EXT:
                excel_manager.add_file(df=meta.df, filepath=meta.filepath, sheet_name=meta.sheet_name, save_params=meta.oth_params)
        else:
            pass
    if excel_manager.file_storage:
        excel_manager.save()

def write_to_archive(
    navigator_report: Dict[str, Dict[str, pd.DataFrame]],
    navig_report_cfg: Dict[str, TableConfig],
    res_archive_sheets: Dict[str, List[str]],
    calc_date: str
) -> None:
    # эта функция временная - частично дублирует write_df, т.к. подход не вписывается в логику
    for report in navigator_report:
        
        cfg = navig_report_cfg[report]   
        
        filepath, _ = split_file_params(params=cfg.store_params)
        add_to_archive(
            arch_df_names=res_archive_sheets[report],
            report=navigator_report[report],
            archive_fullpath=filepath, 
            model_date=calc_date,
            verbose=False
        )
        
def write_to_zip(file_configs: List[TableConfig]) -> None:
    
    zip_manager = ZipManager()
    
    for cfg in file_configs:
        store_filepath, _ = split_file_params(params=cfg.store_params)
        source_filepath, _ = split_file_params(params=cfg.source_params)
        zip_manager.add_file(store_filepath=store_filepath, source_filepath=source_filepath)
        
    if zip_manager.file_storage:
        zip_manager.save()