# dash/utils.py
import base64
import datetime as dt
import json
import logging
import os
import re
import queue

import dash


# Возвращаем набор директорий в переданной директории
def Get_Folders_in_Folder(folder_path):
    """Возвращаем набор директорий в переданной директории"""
    if not os.path.exists(folder_path):
        logging.error(f"Папка {folder_path} не существует")
        raise FileNotFoundError(f"Папка {folder_path} не существует")
    return [dI for dI in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, dI))]


# Функция возвращает данные по выбранной ячейки
def Get_Data_Table_Callback(active_cell, table_data):
    logging.info('utlis.Get_Data_Table_Callback ')

    # Смотрим на состояние call_back
    # Иногда нужно для того, чтоб понять кто его вызвал
    ctx = dash.callback_context

    # Форма для печати. Выгружать надо в html.Pre, не в html.Div
    ctx_msg = json.dumps({
        'triggered': ctx.triggered,
        'states': ctx.states,
        # 'inputs': ctx.inputs,
        # 'outputs_list': ctx.outputs_list,
        # 'inputs_list': ctx.inputs_list,
        # 'states_list': ctx.states_list,
    }, indent=4)

    # Процесс, который вызвал callback
    prop_id = ctx.triggered[0]['prop_id']

    # print(f"ctx.triggered = {ctx.triggered}  prod_id = {prod_id} ")

    # Получаем данные об выбранной ячейке
    # active_cell
    if active_cell:
        active_cell_msg = f"col = {active_cell['column']} row = {min(active_cell['row'], len(table_data))}  col_id = {active_cell['column_id']}"
    else:
        active_cell_msg = 'Нет выбрана ячейка'

    # Данные в таблице
    try:
        selected_row_table_data = table_data[active_cell['row']]
    except:
        selected_row_table_data = str(active_cell)

    # Данные в таблице
    try:
        selected_cell_table_data = table_data[active_cell['row']][active_cell['column_id']]
    except:
        selected_cell_table_data = str(active_cell)

    return_data = {}
    return_data['ctx_msg'] = ctx_msg
    return_data['prop_id'] = prop_id
    return_data['state_data'] = table_data

    return_data['active_cell_msg'] = active_cell_msg
    if active_cell:
        return_data['selected_row_num'] = active_cell['row']
        return_data['selected_col_num'] = active_cell['column']
        return_data['selected_column_id'] = active_cell['column_id']
        return_data['selected_row'] = selected_row_table_data
        return_data['selected_cell'] = selected_cell_table_data

    return return_data


# Функция выбирает из списка текстовых дат дату не больше заданной
def Get_Max_date_in_list(date_str_list, date, date_format='%Y-%m-%d'):
    # переводим в формат даты
    logging.info(f'utlis.Get_Max_date_in_list path_folder_list = {date_str_list}')
    date_list = [dt.datetime.strptime(i, date_format) for i in date_str_list]

    # отбираем даты, не больше указанной
    date_list = [i for i in date_list if i <= dt.datetime.strptime(date, date_format)]

    # сортируем полученные даты и берём последнею
    max_date = sorted(date_list)[-1]
    return max_date.strftime(date_format)


# Get_Max_date_in_list(Curve_folder_date_list, dt.strptime('2025-01-22', '%Y-%m-%d'))

def deploy_or_local_path(file_path: str) -> str:
    if not os.getenv('stand', ''):
        return file_path
    else:
        return os.path.join('app', file_path)


# добавляем настройку в список
def edit_column_set(dict_list, new_dict, uniq_fields='field', mode='add'):
    row_position = -1

    for i, row in enumerate(dict_list):
        # print(f'field = {row['field']}')

        # ищем нужный элемент
        if row[uniq_fields] == new_dict[uniq_fields]:
            row_position = i
            break

    if row_position > -1:
        if mode == 'add':
            dict_list[row_position] = dict_list[row_position] | new_dict
        elif mode == 'replace':
            dict_list[row_position] = new_dict


# Запускает сохранение файлов и формируем лог
# save_folder - папочка, в которую складываются файлы
# save_direcory - директория в которой создаём папочу
def run_save_upload_files(list_of_contents, list_of_names, list_of_dates, save_folder, save_directory):
    logging.info(f'utlis.run_save_upload_files: Разбираем подгруженные файлы save_folder = {save_folder}  save_directory = {save_directory} ')

    # Выходной кусок
    output_layout = []

    # Папка в которую сохраняем
    file_path = os.path.join(save_directory, save_folder)

    # Создаём её, если её нет
    if not os.path.exists(file_path):
        os.makedirs(file_path)
        # children = children + f'Создали папку {file_path}...<br>'
        output_layout.append(f'Создали папку {file_path}...')

    # бежим по выбранным файлам
    if list_of_contents is not None:

        for c, n, d in zip(list_of_contents, list_of_names, list_of_dates):
            # сохраняем файл
            save_upload_file(content=c, name=n, upload_directory=file_path)

            # формируем текст
            text_string = f'  Файл = {str(n)}  Время загрузки = {dt.datetime.fromtimestamp(d)}'
            output_layout.append(text_string)

    return output_layout


# процедура сохраняет файл
# content - загруженный файл
# name - имя файла
# upload_directory - место куда сохраняем
def save_upload_file(content, name, upload_directory):
    """Decode and store a file uploaded with Plotly Dash."""
    logging.info(f'utlis.save_upload_file: Сохраняем файлы в директорию  name = {name}  upload_directory = {upload_directory} ')

    data = content.encode('utf8').split(b';base64,')[1]
    with open(os.path.join(upload_directory, name), 'wb') as fp:
        fp.write(base64.decodebytes(data))

# Возвращаем контекст вызова callback-а
def get_callback_context():

    ##################################################
    # Определяем кто нажал на кнопку
    ctx = dash.callback_context

    # Форма для печати. Выгружать надо в html.Pre, не в html.Div
    ctx_msg = json.dumps({
        'triggered': ctx.triggered,
        'states': ctx.states,
        'inputs': ctx.inputs,
        'outputs_list': ctx.outputs_list,
        'inputs_list': ctx.inputs_list,
        'states_list': ctx.states_list,
    }, indent=4)

    return ctx, ctx_msg

def extract_rgb(color: str):
    color = color.strip()

    if color.startswith("#"):
        hex_str = color.lstrip("#")
        if len(hex_str) == 3:
            hex_str = "".join([ch * 2 for ch in hex_str])
        r, g, b = (int(hex_str[i:i+2], 16) for i in (0, 2, 4))
    else:
        nums = re.findall(r"\d+", color)
        if len(nums) >= 3:
            r, g, b = tuple(map(int, nums[:3]))
        else:
            raise ValueError(f"Не удалось определить формат цвета: {color}")
            
    return r, g, b

def read_queue(q: queue.Queue):
    last_q = None
    while not q.empty():
        try:
            last_q = q.get_nowait()
        except queue.Empty:
            break
    return last_q

def calc_approx_progress(cur_progress: float, expected_duration: int, max_progress: int = 100, update_freq: int = 5) -> float:
        """Расчет значения прогресса для заданной ожидаемой длительности расчета. 

        Args:
            cur_progress (float): Текущее значение прогресса.
            expected_duration (int): Ожидаемая длительность процедуры (сек).
            max_progress (int, optional): Максимальное значение прогресса (%). Defaults to 100.
            update_freq (int, optional): Частота обновления (сек). Defaults to 5.

        Returns:
            float: Новое значение прогресса.
        """
        progress_step = round((max_progress / (expected_duration / update_freq)) * 2) / 2 # округление с шагом 0.5
        # progress_step = round((max_progress / (expected_duration / update_freq)), 2) # округление до 2 знаков
        new_progress = min(cur_progress + progress_step, max_progress)
        return new_progress
