# components/user_profile.py

from dash import html


def UserProfileComponent(user):
    return html.Div(
        className="user-profile-component",
        children=[
            html.H3("Пользователь", className="profile-title"),
            html.P(f"Имя: {user.get('login', '')}", className="profile-info"),
            html.P(f"Роли: {user.get('roles', '')}", className="profile-info"),
            html.P(f"IP: {user.get('ip', '')}", className="profile-info"),
        ]
    )
