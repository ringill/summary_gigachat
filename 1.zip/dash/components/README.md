# Модуль компонентов (dash/components)

Модуль предоставляет набор переиспользуемых UI компонентов для приложения Dash.

## Структура модуля

```
dash/components/
└── user_profile.py
```

### user_profile.py

**Компонент профиля пользователя** - UI компонент для отображения информации о пользователе в интерфейсе приложения.

**Ключевые особенности:**

- Простой и лаконичный интерфейс для отображения пользовательских данных
- Использование классов CSS для стилизации (`user-profile-component`, `profile-title`, `profile-info`)
- Поддержка стандартной структуры данных пользователя из сессии

**Функции:**

- `UserProfileComponent(user)` - создает компонент профиля пользователя

**Параметры:**

- `user` - словарь с данными пользователя, содержащий:
  - `login` - логин пользователя
  - `roles` - роли пользователя
  - `ip` - IP адрес пользователя

**Возвращаемая структура:**

```html
<div class="user-profile-component">
  <h3 class="profile-title">Пользователь</h3>
  <p class="profile-info">Имя: {login}</p>
  <p class="profile-info">Роли: {roles}</p>
  <p class="profile-info">IP: {ip}</p>
</div>
```

**CSS классы:**

- user-profile-component - основной контейнер компонента

- profile-title - заголовок компонента

- profile-info - элементы с информацией о пользователе

## Использование

```python
from dash import Dash, html
from dash.components.user_profile import UserProfileComponent

# Пример данных пользователя
user_data = {
    'login': 'ivanov_ii',
    'roles': 'admin,user',
    'ip': '192.168.1.100'
}

# Создание компонента
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Мое приложение"),
    UserProfileComponent(user_data),
    # ... другие компоненты
])
```

## Интеграция с данными сессии

Компонент может использоваться вместе с данными из Flask сессии:

```python
from flask import session
from dash.components.user_profile import UserProfileComponent

# В колбэке Dash
@app.callback(
    Output('user-profile-container', 'children'),
    Input('url', 'pathname')
)
def update_user_profile(pathname):
    user_data = session.get('user', {})
    return UserProfileComponent(user_data)
```

## Стилизация

```css
.user-profile-component {
  border: 1px solid #ddd;
  padding: 20px;
  border-radius: 8px;
  background-color: #f9f9f9;
}

.profile-title {
  color: #333;
  margin-bottom: 15px;
}

.profile-info {
  margin: 5px 0;
  color: #666;
}
```
