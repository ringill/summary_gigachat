# dash/config.py
import os
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple, Union

import pandas as pd


class Config:
    """Singletone класс для хранения параметров всего приложения"""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            # Инициализация значений по умолчанию
            cls._instance.tmp_folder = None
        return cls._instance

    @property
    def data_folder(self):
        """Возвращает путь к папке с данными"""
        if self.tmp_folder:
            return self.tmp_folder
        proj_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(proj_root, "data")

    @property
    def default_version_folder(self):
        """Путь к папке с версиями моделей"""
        return os.path.join(self.data_folder, 'Model Version')

    @property
    def excel_target_path(self):
        """Путь к файлу с таргетами"""
        return os.path.join(self.data_folder, 'Target', 'Таргет.xlsx')

    @property
    def DE_data_path(self):
        """Путь к директории с папками с данными"""
        return os.path.join(self.data_folder, 'DE_data')

    @property
    def DS_Model_Output_path(self):
        """Путь к директории c файлами выходами модели"""
        return os.path.join(self.data_folder, 'DS_Model_Output')

    @property
    def Navigator_data_path(self):
        """Путь к директории c файлами для Навигатора"""
        return os.path.join(self.data_folder, 'Navigator_data')

    @property
    def Test_Folder(self):
        """Путь к директории для тестирования Test_Folder"""
        return os.path.join(self.data_folder, 'Test_Folder')

    def set_tmp_folder(self, tmp_folder):
        """Устанавливает временную папку (из аргументов командной строки)"""
        self.tmp_folder = tmp_folder

@dataclass
class TableConfig:
    name: str
    source_type: Optional[str] = None
    source_params: Optional[Dict[str, Any]] = None #сюда же можно передать kwargs
    store_type: Optional[str] = None
    store_params: Optional[Dict[str, Any]] = None #сюда же можно передать kwargs
    store_transform: Optional[Callable[[pd.DataFrame], pd.DataFrame]] = None

@dataclass
class TableSaverMeta:

    df: pd.DataFrame
    cfg: TableConfig

    def __post_init__(self):

        self.store_type = self.cfg.store_type
        self.store_params = self.cfg.store_params
        self.is_local_storetype = self.store_type == "file"

        if self.is_local_storetype:
            store_params = self.store_params.copy()
            self.path = store_params.pop('path', None) or ""
            self.filename = store_params.pop('filename', None) or "default.csv"
            self.sheet_name = store_params.pop('sheet_name', None) or self.cfg.name
            self.filepath = os.path.join(self.path, self.filename)
            self.ext = os.path.splitext(self.filename)[1]
            self.oth_params = store_params

class DataConfig:
    def __init__(self, calc_date: str, data_path: str = 'data', mode: str = 'dev'):

        self.mode = mode
        self.data_path = data_path
        self.calc_date = calc_date

        self.schema = self.set_schema()
        self.names = list(self.schema)

    def set_schema(self):

        data_path = self.data_path
        calc_date = self.calc_date

        # глобальная отсечка по дате для записи данных
        MIN_DATE = '2017-01-01'

        if self.mode == 'dev':
            # только локальные источники
            return {
                'masterfile': TableConfig(
                    name='masterfile',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'tech'), 'filename': 'Обработка данных V2 для DS.xlsx'}
                ),
                'techfile': TableConfig(
                    name='techfile',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'tech'), 'filename': 'tech_file_v2.xlsx'}
                ),
                # tribute to https://github.com/d10xa/holidays-calendar
                'holidays': TableConfig(
                    name='holidays',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'tech'), 'filename': 'calendar.json'}
                ),
                'factors_daily': TableConfig(
                    name='factors_daily',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DE_data', calc_date), 'filename': 'ewi_etc_dev.csv'}
                ),
                'factors_weekly': TableConfig(
                    name='factors_weekly',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'factors_weekly_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'factors_weekly_{}.csv'.format(calc_date), 'index': False},
                    store_transform=lambda df: df.loc[df['report_date'] >= MIN_DATE]
                ),
                'data_1_agg': TableConfig(
                    name='data_1_agg',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_1_agg_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_1_agg_{}.csv'.format(calc_date), 'index': False},
                    store_transform=lambda df: df.loc[df['report_date'] >= MIN_DATE]
                ),
                'data_1_agg_nolag': TableConfig(
                    name='data_1_agg_nolag',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_1_agg_nolag_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_1_agg_nolag_{}.csv'.format(calc_date), 'index': False},
                    store_transform=lambda df: df.loc[df['report_date'] >= MIN_DATE]
                ),
                'features_info': TableConfig(
                    name='features_info',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'features_info_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'features_info_{}.csv'.format(calc_date), 'index': False}
                ),
                'data_2_modif': TableConfig(
                    name='data_2_modif',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_2_modif_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_2_modif_{}.csv'.format(calc_date), 'index': False}
                ),
                'data_3_signals': TableConfig(
                    name='data_3_signals',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_3_signals_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_3_signals_{}.csv'.format(calc_date), 'index': False}
                ),
                'data_4_signals_decomp': TableConfig(
                    name='data_4_signals_decomp',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_4_signals_decomp_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_4_signals_decomp_{}.csv'.format(calc_date), 'index': False}
                ),
                'data_ewi': TableConfig(
                    name='data_ewi',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_ewi_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'data_ewi_{}.csv'.format(calc_date), 'index': False}
                ),
                'ewi_threshold': TableConfig(
                    name='ewi_threshold',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'ewi_threshold_{}.csv'.format(calc_date)},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'DS_Model_Output', calc_date), 'filename': 'ewi_threshold_{}.csv'.format(calc_date), 'index': False}
                ),
                'segments_res_archive': TableConfig(
                    name='segments_res_archive',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'res_archive'), 'filename': 'KSmodel_SEGMENTS_runarchive.xlsx', 'sheet_name': None},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'res_archive'), 'filename': 'KSmodel_SEGMENTS_runarchive.xlsx'}
                ),
                'total_res_archive': TableConfig(
                    name='total_res_archive',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'res_archive'), 'filename': 'KSmodel_TOTAL_runarchive.xlsx', 'sheet_name': None},
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'res_archive'), 'filename': 'KSmodel_TOTAL_runarchive.xlsx'}
                ),
                'factors_dictionary': TableConfig(
                    name='factors_dictionary',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'navig_tmp'), 'filename': 'TriggerBSM_RUB_Dictionary_V3.xlsx'}
                ),
                'features_windows': TableConfig(
                    name='features_windows',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'navig_tmp'), 'filename': 'Окна фичей.xlsx', 'sheet_name': None}
                ),
                'features_df_segments': TableConfig(
                    name='features_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'features'}
                ),
                'threshold_df_segments': TableConfig(
                    name='threshold_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'ewi_threshold'}
                ),
                'data_2_df_segments': TableConfig(
                    name='data_2_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_2_modif'}
                ),
                'data_3_df_segments': TableConfig(
                    name='data_3_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_3_signals'}
                ),
                'ewi_df_segments': TableConfig(
                    name='ewi_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_ewi'}
                ),
                'f_windows_df': TableConfig(
                    name='f_windows_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'features_windows'}
                ),
                'features_df_total': TableConfig(
                    name='features_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'features'}
                ),
                'threshold_df_total': TableConfig(
                    name='threshold_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'ewi_threshold'}
                ),
                'data_1_df_total': TableConfig(
                    name='data_1_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_1_agg'}
                ),
                'data_2_df_total': TableConfig(
                    name='data_2_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_2_modif'}
                ),
                'data_3_df_total': TableConfig(
                    name='data_3_df',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_3_signals'}
                ),
                'ewi_df_total': TableConfig(
                    name='data_ewi',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'data_ewi'}
                ),
                'target_df': TableConfig(
                    name='target',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'target'}
                ),
                'factors_dict_df': TableConfig(
                    name='factors_dictionary',
                    store_type='file',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date), 'index': False, 'sheet_name': 'factors_dictionary'}
                ),
                'navigator_segments_report': TableConfig(
                    name='navigator_segments_report',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_SEGMENTS_KPv3.4_{}.xlsx'.format(calc_date)},
                    store_type='zip',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'navigator_{}.zip'.format(calc_date)}
                ),
                'navigator_total_report': TableConfig(
                    name='navigator_total_report',
                    source_type='file',
                    source_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'KSmodel_TOTAL_KPv3.4_{}.xlsx'.format(calc_date)},
                    store_type='zip',
                    store_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'navigator_{}.zip'.format(calc_date)}
                ),
                'navigator_report': TableConfig(
                    name='navigator_report',
                    source_type='zip',
                    source_params={'path': os.path.join(data_path, 'Navigator_data', calc_date), 'filename': 'navigator_{}.zip'.format(calc_date)}
                ),
            }

def split_file_params(params: Dict[str, Any]) -> Tuple[Union[str, dict]]:

    params = params.copy() or {}

    path = params.pop('path', None) or ""
    filename = params.pop('filename', None) or "default.csv"
    filepath = os.path.join(path, filename)

    return filepath, params

# Глобальный экземпляр конфигурации
app_config = Config()
