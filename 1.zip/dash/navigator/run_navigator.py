import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas as pd
import datetime as dt

from typing import Optional, Union, Dict, List

# import argparse

# from update_csv_target import update_target
from .navigator_funcs import prep_segments, add_archive_info, make_factors_data_df, prep_total, make_zero_target_df, add_to_archive, res_archive_sheets


__version__ = "3.5.0"


def make_report(
    calc_date: str,
    factors_dictionary: pd.DataFrame,
    model_data: Dict[str, pd.DataFrame],
    segments_res_archive: pd.DataFrame,
    total_res_archive: pd.DataFrame,
    features_windows: pd.DataFrame,
    factors_lag_data_df: pd.DataFrame,
    factors_act_data_df: pd.DataFrame,
    add_archive_data: bool = True
) -> Dict[str, Dict[str, pd.DataFrame]]:
    
    # отчет по сегментам
    segm_report = prep_segments(model_data, features_windows=features_windows)
    
    # действия с данными (кажется, в следующей версии будут не нужны)
    # сейчас склеиваем данные из модели (со сдвигами) и актуальные, потом возможно не будем
    factors_data_df = make_factors_data_df(factors_lag_data_df=factors_lag_data_df, factors_act_data_df=factors_act_data_df)
    # здесь нужно сделать какой-то зеро-фрейм того же вида, что и оригинальный (данные таргета в навигаторе не используются сейчас)
    target_df = make_zero_target_df(calc_date=calc_date) 
    
    # отчет по тотал
    total_report = prep_total(
        model_data, 
        factors_data_df=factors_data_df,
        target_df=target_df,
        factors_dictionary=factors_dictionary
    )
    
    if add_archive_data:
        # добавим архивные данные
        segm_report = add_archive_info(
            arch_df_names=res_archive_sheets['segments_report'],
            report=segm_report, 
            archive=segments_res_archive, 
            actual_date=calc_date
        )
        total_report = add_archive_info(
            arch_df_names=res_archive_sheets['total_report'],
            report=total_report, 
            archive=total_res_archive, 
            actual_date=calc_date
            )
        
    return dict(segments_report=segm_report, total_report=total_report)