#!/usr/bin/env python
# coding: utf-8

import os
from typing import Optional, Union, Tuple, Dict, List
import pandas as pd
import numpy as np
import datetime as dt
import shutil
import logging

from tqdm import tqdm
from tqdm.notebook import tqdm as tqdm_notebook

import openpyxl
from openpyxl.styles import NamedStyle 

__version__ = "1.2.0"

# blocks_dict = {
#     'ALM': 'Метрики ALM',
#     'DUL': 'ДЮЛ',
#     'KFL': 'КФЛ',
#     'KUL': 'КЮЛ',
#     'MARKET': 'Рынок',
#     'SFL': 'СФЛ'
# }

blocks_dict = {
    'alm': 'Метрики ALM',
    'dul': 'ДЮЛ',
    'kfl': 'КФЛ',
    'kul': 'КЮЛ',
    'market': 'Рынок',
    'sfl': 'СФЛ'
}

segments_dict = {
    'alm_total': 'Метрики ALM',
    'dul_total': 'ДЮЛ',
    'kfl_total': 'КФЛ',
    'kul_total': 'КЮЛ',
    'market_total': 'Рынок',
    'sfl_total': 'СФЛ'
}

KPI_ID_dict = {
    'treshold': 1000000734,
    'features': 1000000744,
    'target': 1000000740,
    'dataset': 1000000743
}

# report_sheet_names = {
#     'features_df': 'features',
#     'threshold_df': 'ewi_threshold',
#     'data_1_df': 'data_1_agg',
#     'data_2_df': 'data_2_modif',
#     'data_3_df': 'data_3_signals',
#     'ewi_df': 'data_ewi',
#     'bin_ewi_df': 'data_ewi_bin',
#     'target_df': 'target',
#     'factors_dict_df': 'factors_dictionary',
#     'f_windows_df': 'features_windows'
# }

report_sheet_names = {
    'features_df_segments': 'features',
    'features_df_total': 'features',
    'threshold_df_segments': 'ewi_threshold',
    'threshold_df_total': 'ewi_threshold',
    'data_1_df_total': 'data_1_agg',
    'data_2_df_segments': 'data_2_modif',
    'data_2_df_total': 'data_2_modif',
    'data_3_df_segments': 'data_3_signals',
    'data_3_df_total': 'data_3_signals',
    'ewi_df_segments': 'data_ewi',
    'ewi_df_total': 'data_ewi',
    'target_df': 'target',
    'factors_dict_df': 'factors_dictionary',
    'f_windows_df': 'features_windows'
}

res_archive_sheets = {
    'segments_report': ['data_3_df_segments', 'ewi_df_segments'],
    'total_report': ['data_2_df_total', 'data_3_df_total', 'ewi_df_total']
}

# формат дат openpyxl
date_style = NamedStyle(name='date_style', number_format='DD.MM.YYYY')


def prepare_target_df(target_df: pd.DataFrame, KPI_ID_dict: Dict[str, int] = KPI_ID_dict):

    change_dict = {
        'short': 'Короткий конец',
        'long': 'Длинный конец'
    }

    target_df = target_df[['end_date', 'short_down_value', 'short_up_value', 'long_down_value', 'long_up_value']].copy()
    
    target_df = rearrange_df_uni(
        target_df, 
        index_colnames=['end_date'],
        new_index_colnames={'end_date': 'DATE_'},
        new_desc_colname='Axis_2',
        new_value_colname='fValue'
    )
    
    target_df['KPI_ID'] = KPI_ID_dict.get('target')
    target_df['Axis_1'] = target_df['Axis_2'].map(lambda x: change_dict.get(x.split('_')[0]))
    target_df['DATE_'] = pd.to_datetime(target_df['DATE_'])
    
    ORDERED_COLS = ['DATE_', 'KPI_ID', 'Axis_1', 'Axis_2', 'fValue']
    
    return target_df[ORDERED_COLS]

def prep_segments(
    model_dict: Dict[str, pd.DataFrame], 
    features_windows: dict = None, 
    end_date: Optional[str] = None, 
    blocks_dict: Dict[str, str] = blocks_dict
) -> Dict[str, pd.DataFrame]:
    
    features_df_orig = model_dict['features_info']
    features_df_orig = features_df_orig.loc[features_df_orig['block'] != 'total'].copy()
    features_df = features_df_orig.drop_duplicates(subset=['factor', 'model', 'segment']).copy()
    features_df = features_df.drop(
        columns=['feature', 'treshold_val', 'type', 'sub_type', 'block'], 
        errors='ignore'
    )
    features_df['factor_origin'] = features_df['factor_origin'].fillna(features_df['factor'].map(lambda x: x.strip('_OLD').strip('_ABS').strip('_NEW')))

    threshold_df = model_dict['ewi_threshold']
    threshold_df = threshold_df.loc[threshold_df['block'] != 'total'].copy()
    threshold_df['segment'] = threshold_df['block'].map(blocks_dict)
    threshold_df = threshold_df.drop(columns=['block'], errors='ignore')

    data_2_df = model_dict['data_2_modif']
    data_2_df = data_2_df.loc[data_2_df['block'] != 'total']
    data_4_df = model_dict['data_4_signals_decomp']
    data_4_df = data_4_df.loc[data_4_df['block'] != 'total']
    data_2_df = pd.merge(
        data_2_df, 
        data_4_df, 
        how='left', 
        on=['report_date', 'factor', 'feature_type', 'model', 'block']
    )
    data_2_df['segment'] = data_2_df['block'].map(blocks_dict)
    data_2_df = data_2_df.drop(columns=['block'], errors='ignore')
    move_column(data_2_df, colname='Signal', to_position=2)
    # Финально уберем пропуски и inf
    data_2_df = data_2_df.loc[~data_2_df['Value'].isin([-np.inf, np.inf])].dropna(subset=['Value'])
    data_2_df['Signal'] = data_2_df['Signal'].fillna(0)
    data_2_df['report_date'] = pd.to_datetime(data_2_df['report_date'])

    data_3_df = model_dict['data_3_signals']
    data_3_df = data_3_df.loc[data_3_df['block'] != 'total'].copy()
    data_3_df['segment'] = data_3_df['block'].map(blocks_dict)
    data_3_df = data_3_df.drop(columns=['block'], errors='ignore')
    data_3_df = data_3_df.dropna(subset=['Signal'])
    # Финально уберем пропуски и inf
    data_3_df = data_3_df.loc[~data_3_df['Signal'].isin([-np.inf, np.inf])].dropna(subset=['Signal'])
    data_3_df['report_date'] = pd.to_datetime(data_3_df['report_date'])

    ewi_df = model_dict['data_ewi']
    ewi_df = ewi_df.loc[ewi_df['block'] != 'total'].copy()
    ewi_df['segment'] = ewi_df['block'].map(blocks_dict)
    ewi_df = ewi_df.drop(columns=['block'], errors='ignore')
    # Финально уберем пропуски и inf
    ewi_df = ewi_df.loc[~ewi_df['ewi'].isin([-np.inf, np.inf])].dropna(subset=['ewi', 'signal'])
    ewi_df['report_date'] = pd.to_datetime(ewi_df['report_date'])

    if features_windows is not None:

        f_windows_df = pd.DataFrame()
        for key in features_windows:
            f_windows_df = pd.concat([f_windows_df, features_windows[key]])
        
        f_windows_df = pd.merge(
            features_df_orig[['model', 'segment_name', 'factor', 'sub_type']],
            f_windows_df[['model', 'factor', 'sub_type', 'T']],
            on=['model', 'factor', 'sub_type'],
            how='left'
        ).rename(
            columns={
                'sub_type': 'feature_type', 
                'T': 'feature_window', 
                'segment_name': 'segment'
                }
            )

        f_windows_df['feature_window'] = f_windows_df['feature_window'].fillna(0)
    else:
        f_windows_df = pd.DataFrame()

    if end_date is not None:
        data_2_df = data_2_df.loc[data_2_df['report_date'] <= end_date]
        data_3_df = data_3_df.loc[data_3_df['report_date'] <= end_date]
        ewi_df = ewi_df.loc[ewi_df['report_date'] <= end_date]

    out_dict = {
        'features_df_segments': features_df, 
        'threshold_df_segments': threshold_df, 
        'data_2_df_segments': data_2_df, 
        'data_3_df_segments': data_3_df, 
        'ewi_df_segments': ewi_df,
        'f_windows_df': f_windows_df
    }
        
    return out_dict

def prep_total(
    model_dict_total: Dict[str, pd.DataFrame], 
    factors_data_df: pd.DataFrame, 
    target_df: pd.DataFrame,
    factors_dictionary: pd.DataFrame,
    end_date: Optional[str] = None,
    segments_dict: Dict[str, str] = segments_dict
) -> Dict[str, pd.DataFrame]:
    
    features_df_total = model_dict_total['features_info']
    features_df_total = features_df_total.loc[features_df_total['block'] == 'total'].copy()
    features_df_total['segment_name'] = features_df_total['segment'].map(segments_dict)
    # features_df_total = features_df_total.drop(columns=['block'], errors='ignore')
    features_df_total['yellow_val'] = 0.01
    features_df_total = features_df_total.rename(columns={'treshold_val': 'red_val'})
    features_df_total = features_df_total[['directions', 'yellow_val', 'red_val', 'coefs', 'segment', 'model', 'segment_name']]

    threshold_df_total = model_dict_total['ewi_threshold']
    threshold_df_total = threshold_df_total.loc[threshold_df_total['block'] == 'total'].copy()
    threshold_df_total = threshold_df_total.drop(columns=['block'], errors='ignore')
    
    data_1_df_total = factors_data_df.copy()
    data_1_df_total = data_1_df_total.drop_duplicates(subset=['factor_origin', 'report_date', 'data_version'])
    # data_1_df_total.drop(columns=['model', 'block'], inplace=True, errors='ignore')
    # data_1_df_total.rename(columns={'factor': 'factor_origin'}, inplace=True)
    # Финально уберем пропуски и inf
    data_1_df_total = data_1_df_total.loc[~data_1_df_total['Value'].isin([-np.inf, np.inf])].dropna(subset=['Value'])
    data_1_df_total['report_date'] = pd.to_datetime(data_1_df_total['report_date'])

    data_2_df_total = model_dict_total['data_2_modif']
    data_2_df_total = data_2_df_total.loc[data_2_df_total['block'] == 'total'].copy()
    data_2_df_total = data_2_df_total.drop(columns=['feature_type', 'block'])
    # Финально уберем пропуски и inf
    data_2_df_total = data_2_df_total.loc[~data_2_df_total['Value'].isin([-np.inf, np.inf])].dropna(subset=['Value'])
    data_2_df_total['report_date'] = pd.to_datetime(data_2_df_total['report_date'])

    data_3_df_total = model_dict_total['data_3_signals']
    data_3_df_total = data_3_df_total.loc[data_3_df_total['block'] == 'total'].copy()
    data_3_df_total = data_3_df_total.drop(columns=['block'])
    # Финально уберем пропуски и inf
    data_3_df_total = data_3_df_total.loc[~data_3_df_total['Signal'].isin([-np.inf, np.inf])].dropna(subset=['Signal'])
    data_3_df_total['report_date'] = pd.to_datetime(data_3_df_total['report_date'])

    ewi_df_total = model_dict_total['data_ewi']
    ewi_df_total = ewi_df_total.loc[ewi_df_total['block'] == 'total'].copy()
    ewi_df_total = ewi_df_total.drop(columns=['block'])
    # Финально уберем пропуски и inf
    ewi_df_total = ewi_df_total.loc[~ewi_df_total['ewi'].isin([-np.inf, np.inf])].dropna(subset=['ewi', 'signal'])
    ewi_df_total['report_date'] = pd.to_datetime(ewi_df_total['report_date'])
    
    target_df = prepare_target_df(target_df)

    if end_date is not None:
        data_1_df_total = data_1_df_total.loc[data_1_df_total['report_date'] <= end_date]
        data_2_df_total = data_2_df_total.loc[data_2_df_total['report_date'] <= end_date]
        data_3_df_total = data_3_df_total.loc[data_3_df_total['report_date'] <= end_date]
        ewi_df_total = ewi_df_total.loc[ewi_df_total['report_date'] <= end_date]
        target_df = target_df.loc[target_df['DATE_'] <= end_date]

    out_dict = {
        'features_df_total': features_df_total, 
        'threshold_df_total': threshold_df_total, 
        'data_1_df_total': data_1_df_total, 
        'data_2_df_total': data_2_df_total, 
        'data_3_df_total': data_3_df_total,
        'ewi_df_total': ewi_df_total,
        'target_df': target_df,
        'factors_dict_df': factors_dictionary
    }
        
    return out_dict

def make_factors_data_df(
    factors_lag_data_df: pd.DataFrame, 
    factors_act_data_df: pd.DataFrame,
):
    
    factors_lag_data_df = factors_lag_data_df.copy()
    factors_act_data_df = factors_act_data_df.copy()
    
    factors_lag_data_df['report_date'] = pd.to_datetime(factors_lag_data_df['report_date'])
    factors_lag_data_df['data_version'] = 'Модель'
    factors_act_data_df['report_date'] = pd.to_datetime(factors_act_data_df['report_date'])
    factors_act_data_df['data_version'] = 'Актуальный'
    factors_data_df = pd.concat([factors_act_data_df, factors_lag_data_df])
    
    return factors_data_df

def make_zero_target_df(
    calc_date: str
):
    target_columns = [
        'start_date', 
        'end_date', 
        'short_down_value', 
        'short_up_value',
        'short_down_target', 
        'short_up_target', 
        'long_down_value',
        'long_up_value', 
        'long_down_target', 
        'long_up_target'
    ]
    
    date_range = pd.date_range(start='2016-01-01', end=calc_date, freq='W-FRI')

    target_df = pd.DataFrame(columns=target_columns)
    target_df['start_date'] = date_range[:-1]
    target_df['end_date'] = date_range[1:]
    target_df = target_df.fillna(0)
    
    return target_df
    
def save_report(
    path: str,
    report: dict,
    report_sheet_names: dict = report_sheet_names,
    progressbar=False,
    progressbar_mode='cmd'
    ) -> None:
    # Сделаем путь
    os.makedirs(os.path.split(path)[0], exist_ok=True)

    progress_bar = report.keys()
    
    if progressbar:
        if progressbar_mode == 'notebook':
            progressbar_engine = tqdm_notebook
        elif progressbar_mode == 'cmd':
            progressbar_engine = tqdm   
        progress_bar = progressbar_engine(
            progress_bar,
            desc='saving data'
        )

    with pd.ExcelWriter(path, datetime_format='DD.MM.YYYY') as writer:
        for key_name in progress_bar:
            report[key_name].to_excel(writer, sheet_name=report_sheet_names[key_name], index=False)
    

def add_to_archive_sheets(data_to_add: dict, xlsx_archive_path: str, check=False, verbose=False) -> None:
    
    """data_to_add - словарь с ключами-листами и данными в виде pd.DataFrame"""
    
    wb = openpyxl.load_workbook(filename=xlsx_archive_path)
    
    # если стиль уже был зарегистрирован в объекте wb, выдаст ошибку
    try:
        wb.add_named_style(date_style)
    except ValueError:
        pass

    for sheet_name in data_to_add:

        sheet = wb[sheet_name]
        data_by_rows = data_to_add[sheet_name].to_numpy()
        
        if len(data_by_rows) == 0:
            continue

        if check:
            # просто дата на последней строке архива (формат даты, т.к. специфицировали его при записи)
            last_archive_date = sheet['A'+str(sheet.max_row)].value.date()
            # дата на первой строке таблицы
            date_to_add = data_by_rows[0][0].date()
            if last_archive_date >= date_to_add:
                if verbose:
                    print(f'Архив: лист {sheet_name} уже содержит данные за {date_to_add}')
                continue

        for row in data_by_rows:
            sheet.append(list(row))
            # первый столбец - даты
            cell = sheet[sheet.max_row][0]
            cell.style = 'date_style'

        if verbose:
            print(f'Архив: лист {sheet_name} дополнен данными за {date_to_add}')

    wb.save(xlsx_archive_path)
    wb.close()
    
def enrich_with_archive(df, archive_df, actual_date, archive_start_date='2025-01-01') -> pd.DataFrame:
    
    enr_df = df.copy()

    enr_df['version'] = 'Актуальный'

    enr_df = pd.concat([
        enr_df, 
        archive_df.loc[(archive_df['report_date'] >= archive_start_date) & (archive_df['report_date'] < actual_date)],
        df.loc[df['report_date'] == actual_date]
    ], ignore_index=True)

    enr_df['version'].fillna('Архив', inplace=True)
    
    return enr_df

def add_archive_info(arch_df_names: list, report: dict, archive: dict, actual_date: str, report_sheet_names: dict = report_sheet_names) -> dict:

    ext_report = report.copy()
    for df_name in arch_df_names:
        arch_name = report_sheet_names[df_name]
        df = enrich_with_archive(df=report[df_name], archive_df=archive[arch_name], actual_date=actual_date)
        ext_report[df_name] = df

    return ext_report

def add_to_archive(
    arch_df_names: list, 
    report: dict, 
    archive_fullpath: str, 
    model_date: str, 
    check_archive: bool = True, 
    report_sheet_names: dict = report_sheet_names,
    verbose: bool = False
) -> None:

    dfs_for_archive = []
    for df_name in arch_df_names:
        df = report[df_name]
        # если calc_date не пятница, не запишет в архив (т.к. отчет навигатора на пятницу формируется)
        df_for_archive = df.loc[(df['report_date'] == model_date)].copy()
        if 'version' in df.columns:
            df_for_archive = df_for_archive.loc[df_for_archive['version'] == 'Актуальный'].drop(columns=['version'])
        dfs_for_archive.append(df_for_archive)

    t_dict = dict(zip(
        [report_sheet_names[x] for x in arch_df_names],
        dfs_for_archive
    ))

    add_to_archive_sheets(data_to_add=t_dict, xlsx_archive_path=archive_fullpath, check=check_archive, verbose=verbose)


def archive_integrity_check(archive: dict) -> Tuple[Dict, Dict]:
    
    # столбцы без численных значений
    COLS = ['report_date', 'factor', 'factor_origin', 'feature_type', 'model', 'segment']
    
    change_dict = dict()
    
    for sheet in archive:
        
        change_flag = False
        sort_flag = False
    
        df = archive[sheet]
        COLS_IN_DF = [col for col in COLS if col in df.columns]
        
        if df.duplicated().any():
            df.drop_duplicates(subset=COLS_IN_DF, inplace=True)
            change_flag = True

        # нужны все пятницы со стартовой даты архива
        required_dates = pd.date_range(start=df['report_date'].min(), end=dt.datetime.today(), freq='7D')
        # в предположении, что данные за дату либо записываются все, либо не записываются (количество строк сложно оценить)
#         skipped_dates = [date for date in required_dates if date not in df['report_date'].unique()]
        archive_dates = df['report_date'].unique()
        
        skipped_dates = []
        for i, req_date in enumerate(required_dates):
            
            if req_date not in archive_dates:
                skipped_dates.append(req_date)
                
            elif req_date != archive_dates[i]:
                sort_flag = True
                print('needs sort')
                
        if len(skipped_dates) > 0:
            # пока просто пишем
            print('В архиве пропущены даты:\n ', ' \n'.join(skipped_dates))
            
        if sort_flag:
            df.sort_values(COLS_IN_DF, ignore_index=True, inplace=True)
            change_flag = True
            
        change_dict[sheet] = change_flag
        archive[sheet] = df
        
    return archive, change_dict

def rewrite_archive(archive: dict, xlsx_archive_path: str, change_dict: dict = None, verbose: bool = False) -> None:
    
    with pd.ExcelWriter(
        xlsx_archive_path, 
        engine='openpyxl', 
        if_sheet_exists='replace', 
        mode='a'
    ) as writer:
    
        for sheet_name in archive:

            change_flag = True
            if change_dict is not None:
                change_flag = change_dict.get(sheet_name)
                
            if verbose:
                if change_flag:
                    print('Лист {} перезаписывается'.format(sheet_name))
                else:
                    print('Лист {} в порядке'.format(sheet_name))

            if change_flag:
                
                wb = writer.book
                
                try:
                    wb.add_named_style(date_style)
                except ValueError:
                    pass
                
                df = archive[sheet_name]
                df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                sheet = wb[sheet_name]
                for i in range(2, len(df) + 2):
                    cell = sheet[i][0]
                    cell.style = 'date_style'


def move_column(df: pd.DataFrame, colname: str, to_position: int) -> None:
    
    if to_position < 0:
        to_position = len(df.columns) + to_position
        
    df.insert(to_position, colname, df.pop(colname))


def archive_files(folder_path: str, archive_filename: str = None, aux_folder_path: str = None) -> str:
    """
    Архивирует все файлы в директории и сохраняет архив в той же директории.
    
    aux_folder_path: Путь к директории для первичного сохранения архива (по умолчанию - родительская папка folder_path)
    """
    
    aux_folder_path = os.path.dirname(folder_path) if aux_folder_path is None else aux_folder_path
    archive_filename = os.path.basename(aux_folder_path) if archive_filename is None else archive_filename
    
    if os.path.exists(folder_path):

        archive_path = shutil.make_archive(
            os.path.join(aux_folder_path, archive_filename), 
            format='zip', 
            root_dir=folder_path
        )

        future_archive_path = os.path.join(folder_path, archive_filename+'.zip')
        if os.path.isfile(future_archive_path):
            os.remove(future_archive_path)

        archive_path = shutil.move(archive_path, folder_path)
    else:
        archive_path = None
        
    return archive_path

def rearrange_df_uni(
    df: pd.DataFrame, 
    index_colnames: List[str] = ['report_date'],
    new_index_colnames: Dict[str, str] = {},
    new_desc_colname: str = 'feature', 
    new_value_colname: str = 'value'
):
    
    df_ = df.copy()
    
    # все колонки кроме индекса лягут в плоском виде
    df_new = pd.DataFrame()
    df_.set_index(index_colnames, inplace=True)
    for col in df_.columns:
        df_new = pd.concat([df_new, df_[col].rename(new_value_colname)])
        if new_desc_colname not in df_new.columns:
            df_new[new_desc_colname] = None
        df_new[new_desc_colname] = df_new[new_desc_colname].fillna(col)
    df_new.reset_index(inplace=True)

    # распаковка индекса и переименование
    df_new = df_new.assign(
        **pd.DataFrame(df_new['index'].values.tolist(), columns=index_colnames)
    ).drop(columns='index').rename(columns=new_index_colnames)

    # колонки в правильном порядке
    ordered_columns = []
    for col in index_colnames:
        if col in new_index_colnames:
            ordered_columns.append(new_index_colnames[col])
        else:
            ordered_columns.append(col)  
    ordered_columns += [new_desc_colname, new_value_colname]
    
    return df_new[ordered_columns]