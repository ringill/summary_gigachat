# dash/task_manager.py
import logging
import threading
import traceback
import uuid
from datetime import datetime
from typing import Any, Callable, Dict, Optional


class TaskStatus:
    """Статусы задач"""
    PENDING = 'pending'
    RUNNING = 'running'
    COMPLETED = 'completed'
    ERROR = 'error'


class TaskManager:
    """
    Менеджер для управления фоновыми задачами.
    Обеспечивает отслеживание статуса выполнения задач.
    """

    def __init__(self):
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def create_task(self, task_func: Callable, task_type: str, *args, **kwargs) -> str:
        """
        Создает и запускает новую задачу.

        Args:
            task_func: Функция для выполнения
            task_type: Тип задачи (для идентификации)
            *args: Аргументы функции
            **kwargs: Ключевые аргументы функции

        Returns:
            str: UUID идентификатор задачи
        """
        task_id = str(uuid.uuid4())

        with self._lock:
            self.tasks[task_id] = {
                'id': task_id,
                'type': task_type,
                'status': TaskStatus.RUNNING,
                'start_time': datetime.now(),
                'end_time': None,
                'function': task_func,
                'args': args,
                'kwargs': kwargs,
                'error': None,
                'error_traceback': None,
                'thread': None
            }

        # Запускаем задачу в отдельном потоке
        thread = threading.Thread(
            target=self._execute_task,
            args=(task_id,),
            daemon=True
        )
        thread.start()

        with self._lock:
            self.tasks[task_id]['thread'] = thread

        logging.info(f"Задача {task_id} ({task_type}) создана и запущена")
        return task_id

    def _execute_task(self, task_id: str):
        """Внутренний метод для выполнения задачи в отдельном потоке"""
        task = self.tasks.get(task_id)
        if not task:
            return

        try:
            # Выполняем целевую функцию
            task['function'](*task['args'], **task['kwargs'])

            with self._lock:
                self.tasks[task_id]['status'] = TaskStatus.COMPLETED
                self.tasks[task_id]['end_time'] = datetime.now()

            logging.info(f"Задача {task_id} успешно завершена")

        except Exception as e:
            error_traceback = traceback.format_exc()
            with self._lock:
                self.tasks[task_id]['status'] = TaskStatus.ERROR
                self.tasks[task_id]['error'] = str(e)
                self.tasks[task_id]['error_traceback'] = error_traceback
                self.tasks[task_id]['end_time'] = datetime.now()

            logging.error(f"Задача {task_id} завершена с ошибкой: {e}")
            logging.debug(f"Traceback для задачи {task_id}:\n{error_traceback}")

    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Получает статус задачи по ID.

        Args:
            task_id: UUID идентификатор задачи

        Returns:
            Optional[Dict]: Информация о задаче или None если задача не найдена
        """
        task = self.tasks.get(task_id)
        if not task:
            return None

        # Если задача выполняется, проверяем жив ли поток
        if task['status'] == TaskStatus.RUNNING and task['thread']:
            if not task['thread'].is_alive():
                with self._lock:
                    # Если поток умер, но статус не обновлен, помечаем как ошибку
                    if self.tasks[task_id]['status'] == TaskStatus.RUNNING:
                        self.tasks[task_id]['status'] = TaskStatus.ERROR
                        self.tasks[task_id]['error'] = 'Поток завершился неожиданно'
                        self.tasks[task_id]['end_time'] = datetime.now()

        return {
            'id': task['id'],
            'type': task['type'],
            'status': task['status'],
            'start_time': task['start_time'],
            'end_time': task['end_time'],
            'error': task['error'],
            'error_traceback': task['error_traceback']
        }

    def is_task_running(self, task_id: str) -> bool:
        """
        Проверяет, выполняется ли задача.

        Args:
            task_id: UUID идентификатор задачи

        Returns:
            bool: True если задача выполняется
        """
        status = self.get_task_status(task_id)
        return status is not None and status['status'] == TaskStatus.RUNNING

    def is_task_completed(self, task_id: str) -> bool:
        """
        Проверяет, завершена ли задача успешно.

        Args:
            task_id: UUID идентификатор задачи

        Returns:
            bool: True если задача завершена успешно
        """
        status = self.get_task_status(task_id)
        return status is not None and status['status'] == TaskStatus.COMPLETED

    def is_task_failed(self, task_id: str) -> bool:
        """
        Проверяет, завершена ли задача с ошибкой.

        Args:
            task_id: UUID идентификатор задачи

        Returns:
            bool: True если задача завершена с ошибкой
        """
        status = self.get_task_status(task_id)
        return status is not None and status['status'] == TaskStatus.ERROR

    def get_task_result_message(self, task_id: str) -> str:
        """
        Получает сообщение о результате выполнения задачи.

        Args:
            task_id: UUID идентификатор задачи

        Returns:
            str: Сообщение о результате
        """
        status = self.get_task_status(task_id)
        if not status:
            return "Задача не найдена"

        if status['status'] == TaskStatus.RUNNING:
            return f"Задача '{status['type']}' выполняется..."
        elif status['status'] == TaskStatus.COMPLETED:
            duration = status['end_time'] - status['start_time']
            return f"Задача '{status['type']}' завершена успешно! Время выполнения: {duration.total_seconds():.3f} сек"
        elif status['status'] == TaskStatus.ERROR:
            return f"Задача '{status['type']}' завершена с ошибкой: {status['error']}"
        else:
            return f"Неизвестный статус задачи: {status['status']}"

    def cleanup_old_tasks(self, max_age_hours: int = 24):
        """
        Очищает старые завершенные задачи для экономии памяти.

        Args:
            max_age_hours: Максимальный возраст задач в часах
        """
        now = datetime.now()
        tasks_to_remove = []

        with self._lock:
            for task_id, task in self.tasks.items():
                if task['end_time'] and (now - task['end_time']).total_seconds() > max_age_hours * 3600:
                    tasks_to_remove.append(task_id)

            for task_id in tasks_to_remove:
                del self.tasks[task_id]

        if tasks_to_remove:
            logging.info(f"Очищено {len(tasks_to_remove)} старых задач")


# Глобальный экземпляр менеджера задач
task_manager = TaskManager()
