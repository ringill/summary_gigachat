# dash/main.py
import argparse
import logging

import callbacks
import app
from _logging.config import configure_logging
from audit.audit_logger import init_audit_logger
from config import app_config

# Настройка логирования
configure_logging()
logger = logging.getLogger(__name__)

def run_gunicorn(host: str, port: int, workers: int = 1):
    """Запускает приложение через Gunicorn"""
    from gunicorn.app.base import BaseApplication

    class StandaloneApplication(BaseApplication):
        def __init__(self, app, options=None):
            self.application = app
            self.options = options or {}
            super().__init__()

        def load_config(self):
            config = {key: value for key, value in self.options.items()
                     if key in self.cfg.settings and value is not None}
            for key, value in config.items():
                self.cfg.set(key.lower(), value)

        def load(self):
            return self.application

    options = {
        'bind': f'{host}:{port}',
        'workers': workers,
        'worker_class': 'sync',
        'timeout': 300,
        'loglevel': 'info',
        'accesslog': '-',
        'errorlog': '-',
        'preload_app': True,
    }

    StandaloneApplication(app.server, options).run()

def run_dev_server(host: str, port: int):
    """Запускает development сервер"""
    app.app.run(debug=False, host=host, port=port)

# Обрабатываем аргументы командной строки
parser = argparse.ArgumentParser(description='Запуск основного скрипта.')
parser.add_argument('--host', type=str, help='Адрес хоста для Dash приложения.', default='127.0.0.1')
parser.add_argument('--port', type=int, help='Порт для Dash приложения.', default=8082)
parser.add_argument('--tmp_folder', type=str, help='Путь для сохранения промежуточных файлов.', default=None)
parser.add_argument('--gunicorn', action='store_true', help='Запустить через Gunicorn')
parser.add_argument('--workers', type=int, help='Количество workers для Gunicorn', default=1)
args = parser.parse_args()

# Устанавливаем значение в глобальный конфиг
app_config.set_tmp_folder(args.tmp_folder)

# Инициализируем аудит логгер ДО создания приложения
audit_logger = init_audit_logger(
    debug_mode=not args.gunicorn  # Если не gunicorn, то debug mode
)

if __name__ == '__main__':
    logging.info("=====================================================================================")
    logging.info("Старт программы")
    logging.info(f"Путь к данным: {app_config.data_folder}")
    logging.info(f"Путь к версиям моделей: {app_config.default_version_folder}")

    if args.gunicorn:
        logging.info(f'Запускаем Gunicorn сервер на {args.host}:{args.port} с {args.workers} workers')
        logging.info(f"Режим аудита: 'PRODUCTION (отправка в fluent-bit)'")
        run_gunicorn(host=args.host, port=args.port, workers=args.workers)
    else:
        logging.info(f'Запускаем development сервер на {args.host}:{args.port}')
        logging.info(f"Режим аудита: 'DEBUG (логирование)'")
        run_dev_server(host=args.host, port=args.port)
