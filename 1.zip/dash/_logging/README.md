# Модуль логирования (dash/\_logging)

Модуль предоставляет систему логирования для приложения Dash с поддержкой различных форматов вывода и обработчиков.

## Структура модуля

```
dash/_logging/
├── __init__.py
├── config.py
├── formatters.py
├── handlers.py
├── settings.py
└── README.md
```

### \_\_init\_\_.py

**Инициализация модуля** - экспортирует основные классы и функции для работы с логированием.

**Экспортируемые компоненты:**

- `PALMFormatter` - пользовательский форматтер логов
- `FluentBitHandler` - пользовательский обработчик для интеграции с Fluent Bit

### config.py

**Конфигурация логирования** - настройка логгеров, обработчиков и форматтеров.

**Функции:**

- `get_config(settings: Optional[LogSettings] = None) -> dict[str, Any]` - создает конфигурационный словарь для логирования
- `configure_logging() -> dict[str, Any]` - применяет конфигурацию к системе логирования

**Конфигурационные параметры:**

- **Версия схемы**: 1
- **Форматеры**:
  - `json` - форматирование в JSON с использованием PALMFormatter
- **Обработчики**:
  - `console` - вывод в консоль с JSON форматированием
  - `palm_monitoring` - отправка логов в Fluent Bit
- **Логгеры**:
  - `root` - корневой логгер с настраиваемым уровнем логирования
  - `werkzeug` - логгер для фреймворка Werkzeug с уровнем ERROR

**Особенности форматера JSON:**

- Переименование стандартных полей логирования (asctime → timestamp, levelname → level, и т.д.)
- Добавление статических полей (servicename, version, hostname, и т.д.)
- Поддержка кириллицы через `json_ensure_ascii: False`

### formatters.py

**Форматтеры логов** - пользовательские классы форматирования для различных стилей вывода.

**Классы:**

- `PALMFormatter(JsonFormatter)` - пользовательский JSON форматтер для системы логирования PALM

**Особенности PALMFormatter:**

- **Резервированные поля**: Определяет набор зарезервированных полей (`RESERVED_FIELDS`) для структурированного логирования
- **Обработка полей**: Разделяет поля лога на резервированные и дополнительные
- **Добавление метаданных**: Автоматически добавляет префикс `metadata.` к пользовательским полям
- **Расширяемость**: Предоставляет методы для получения пользователя и ID запроса (могут быть переопределены)

**Методы:**

- `process_log_record(log_record)` - обрабатывает запись лога, структурируя поля
- `get_user() -> str` - возвращает идентификатор пользователя (по умолчанию пустая строка)
- `get_request_id() -> str` - возвращает ID запроса (по умолчанию пустая строка)

### handlers.py

**Обработчики логов** - пользовательские обработчики для вывода логов в различные места назначения.

**Классы:**

- `FluentBitHandler(SocketHandler)` - обработчик для отправки логов в Fluent Bit через сокет

**Особенности FluentBitHandler:**

- **Наследование**: Расширяет стандартный `SocketHandler` из библиотеки logging
- **Протокол отправки**: Отправляет логи в виде закодированных JSON сообщений
- **Обработка ошибок**: Включает механизм обработки ошибок через `handleError(record)`

**Методы:**

- `emit(record)` - отправляет форматированную запись лога в Fluent Bit
  - Форматирует запись с помощью назначенного форматтера
  - Кодирует результат в bytes
  - Отправляет через сокет соединение
  - Обрабатывает исключения при отправке

### settings.py

**Настройки логирования** - параметры конфигурации уровней логирования, путей и форматов.

**Классы:**

- `FluentBitSettings(BaseSettings)` - настройки для подключения к Fluent Bit
- `LogSettings(BaseSettings)` - основные настройки логирования приложения

**FluentBitSettings:**

- `host: str` - хост Fluent Bit сервиса (по умолчанию: 'palm-monitoring-client-logger-svc', env: LOG_SERVICE_HOST)
- `port: int` - порт Fluent Bit сервиса (по умолчанию: 24224, env: LOG_SERVICE_PORT)

**LogSettings:**

- `app_name: str` - название приложения (по умолчанию: 'dash-app', env: APP_NAME)
- `app_version: str` - версия приложения (по умолчанию: '1.0.0', env: APP_VERSION)
- `pod_name: str` - имя POD в Kubernetes (по умолчанию: '', env: POD_NAME)
- `pod_namespace: str` - неймспейс POD в Kubernetes (по умолчанию: '', env: POD_NAMESPACE)
- `log_level: str` - уровень логирования (по умолчанию: 'INFO', env: LOG_LEVEL)
- `fluentbit: FluentBitSettings` - настройки Fluent Bit (по умолчанию: экземпляр FluentBitSettings)

**Особенности:**

- Использует Pydantic для валидации настроек
- Поддержка переменных окружения через алиасы
- Иерархическая структура настроек

## Использование

```python
from dash._logging import configure_logging

# Настройка логирования с настройками по умолчанию
configure_logging()

# Или с кастомными настройками
from dash._logging.settings import LogSettings

settings = LogSettings(
    app_name="my-app",
    log_level="DEBUG"
)
configure_logging(settings)
```

**Переменные окружения**

- APP_NAME - название приложения

- APP_VERSION - версия приложения

- POD_NAME - имя POD в Kubernetes

- POD_NAMESPACE - неймспейс POD в Kubernetes

- LOG_LEVEL - уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL)

- LOG_SERVICE_HOST - хост Fluent Bit сервиса

- LOG_SERVICE_PORT - порт Fluent Bit сервиса
