# dash/_logging/config.py
from logging.config import dictConfig
from typing import Any, Optional

from .settings import LogSettings


def get_config(settings: Optional[LogSettings] = None) -> dict[str, Any]:
    if settings is None:
        settings = LogSettings()
    return {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'json': {
                '()': '_logging.formatters.PALMFormatter',
                'format': "%(asctime)s %(levelname)s %(message)s %(exc_info)s %(stack_info)s %(name)s %(process)s %(pathname)s %(lineno)d %(user)s %(requestid)s",
                'static_fields': {
                    'servicename': settings.app_name,
                    'version': settings.app_version,
                    'hostname': settings.pod_name,
                    'metadata.namespace': settings.pod_namespace,
                    'confidential': 'false',
                },
                'rename_fields': {
                    'asctime': 'timestamp',
                    'levelname': 'level',
                    'name': 'component',
                    'exc_info': 'exception',
                    'stack_info': 'stacktrace',
                },
                'json_ensure_ascii': False,  # Для решения проблем с отображением кириллицы
            },
        },
        'handlers': {
            'console': {
                'formatter': 'json',
                'class': 'logging.StreamHandler',
            },
            'palm_monitoring': {
                'formatter': 'json',
                'class': '_logging.handlers.FluentBitHandler',
                'host': settings.fluentbit.host,
                'port': settings.fluentbit.port,
            },
        },
        'loggers': {
            'root': {
                'level': settings.log_level,
                'handlers': ['console', 'palm_monitoring'],
                'propagate': False,
            },
        },
    }


def configure_logging() -> dict[str, Any]:
    config_data = get_config()
    config_data["loggers"]["werkzeug"] = {"level": "ERROR"}
    dictConfig(config_data)
    return config_data
