# dash/_logging/formatters.py
from pythonjsonlogger.json import JsonFormatter

RESERVED_FIELDS = {
    'duration',
    'message',
    'user',
    'level',
    'messagekey',
    'message',
    'exception',
    'stacktrace',
    'timestamp',
    'servicename',
    'component',
    'rest',
    'hostname',
    'version',
    'requestid',
    'confidential',
}


class PALMFormatter(JsonFormatter):
    def process_log_record(self, log_record):
        out, extra = {}, {}
        for k, v in log_record.items():
            if k in RESERVED_FIELDS:
                out[k] = v
            else:
                extra[k] = v
        out.update({
            'user': self.get_user(),
            'requestid': self.get_request_id(),
        })
        for k, v in extra.items():
            if not k.startswith('metadata.'):
                k = f'metadata.{k}'
            out[k] = v
        return {k: v for k, v in out.items() if v is not None}

    def get_user(self) -> str:
        return ''

    def get_request_id(self) -> str:
        return ''
