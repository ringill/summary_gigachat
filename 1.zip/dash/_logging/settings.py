# dash/_logging/settings.py
from pydantic import Field
from pydantic_settings import BaseSettings


class FluentBitSettings(BaseSettings):
    host: str = Field(default='palm-monitoring-client-logger-svc', alias='LOG_SERVICE_HOST')
    port: int = Field(default=24224, alias='LOG_SERVICE_PORT')


class LogSettings(BaseSettings):
    app_name: str = Field(default='dash-app', alias='APP_NAME')
    app_version: str = Field(default='1.0.0', alias='APP_VERSION')
    pod_name: str = Field(default='', alias='POD_NAME')
    pod_namespace: str = Field(default='', alias='POD_NAMESPACE')
    log_level: str = Field(default='INFO', alias='LOG_LEVEL')
    fluentbit: FluentBitSettings = FluentBitSettings()
