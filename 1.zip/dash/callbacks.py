# dash/callbacks.py
import json
import logging
import os
import threading
import queue

import pandas as pd
from datetime import datetime, timedelta

import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate

from ag_grid_tables import (
    fasttrack_dedata_table_columnDefs,
    fasttrack_make_joint_blocks_table,
    fasttrack_make_joint_rec_table,
    fasttrack_make_restricted_blocks_table,
    fasttrack_make_signals_table,
    fasttrack_rec_table_columnDefs,
)

# Наши файлы
from app import app
from audit.audit_logger import get_audit_logger
from config import DataConfig, app_config
from dash_graphs import (  # FastTrack_DE_data_table,; FastTrack_DE_data_aggrid,
    Factor_Features_Table,
    Factor_Level_Table,
    Factor_Reaction_Table_Calibr,
    Factor_Set_Table,
    Feature_Levels_Table,
    MA_Block_Graph,
    MA_Block_Main_Stat_Table,
    MA_Factor_Graph,
    MA_Factor_Main_Stat_Table,
    MA_Model_Graph,
    MA_Model_Main_Stat_Table,
    Main_Factor_Graph,
    Main_Feature_Graph,
    Main_Hist_Graph,
    block_converter,
    empty_graph_template,
    fasttrack_plot_blocks_signals,
)
from data_preparation_RUB import (  # Get_df_folder,
    Trigger,
    csv_from_Factor_Set,
    materials_path,
    to_numeric_df_Factor_set,
)
from data_reader import load_data
from layouts import (  # FastTrack_DE_data_aggrid_filter,
    Factor_Weight_Rows,
    Fast_Track_layout,
    generate_section_banner,
    layout_MA_Model,
    layout_tab_factor,
    layout_tab_factor_set,
    layout_tab_graph,
)
from model_pipeline import run_data_preprocessing, run_model_calculation, run_navigator
from utils import run_save_upload_files, read_queue, calc_approx_progress
from visual_settings import level_desc_num, reaction_column, reaction_desc_num
from enums import CalcState, CalcMessage

status_queue = queue.Queue()

# Основной callback на переключение закладок
# По выбору закладок в основнм Tab определяем что рисуем
@app.callback(
    Output("app-content", "children"),
    [Input("app-tabs", "value")]
)
def layout_tab_content(tab_switch):
    if tab_switch == "tab1":
        return layout_tab_graph()

    elif tab_switch == "tab2":
        return layout_tab_factor()

    elif tab_switch == "tab3":
        return layout_tab_factor_set()

    elif tab_switch == "tab4":
        return layout_MA_Model()

    elif tab_switch == "tab5":
        return Fast_Track_layout()


# Закладка  - Факторы
# Изменение графика фактора при выборе нового фактора
@app.callback(
    [
    Output("Main_Factor_Graph", "figure"),
    Output("Factor_Features_Table_Main","children")
        ],
    [Input("Factor_Dropdown", "value")]
    # prevent_initial_call=True
)

def Select_Factor(factor_name):
    return [Main_Factor_Graph(factor_name),Factor_Features_Table(factor_name)]



# Закладка  - Факторы
# Выбор фичи (сьрочки) в основнной табличке с описанием фичи
# После выбора должен меняться график
@app.callback(
     [
    Output("Main_Feature_Graph", "figure"),
    Output("Factor_Features_Table_Desc", "children"),
    Output("my_output_factor", "children"),
         ],
    [Input("Feature_Table_Main", "selectedRows")],
    # prevent_initial_call=True
)

def Select_Feature(selected):
    if selected:
        feature = selected[0]['features']
        model = selected[0]['model']
        return [Main_Feature_Graph(feature, model),
                Feature_Levels_Table(feature, model),
                f" Фича (фактор)= {feature}  Модель = {model}"]
    else:
        raise PreventUpdate


# Закладка - Триггер
# Смена основного графика с историей ЕТС и графиком рекомендаций после смены переключателей
@app.callback(
    # [
    Output("Main_Hist_Graph", "figure"),
    # Output("main_graph_output", "children")
    # ],
    [
        Input("Switch_Treshold", "value"),
        Input("Switch_Agr", "value"),
        Input("hv_1", "children"),
        # Input("Factor_Dropdown_Main_Hist_Graph", "value"),
        Input("Switch_ЕТС_hist", "value"),
        Input("RI_ftp_curve_part", "value"),
        Input("Switch_Sum_Recomend", "value"),
        Input("main_graph_datapicker", "start_date"),
        Input("main_graph_datapicker", "end_date")


    ],
)
def Main_Graph_Type(Switch_Treshold,
                    Switch_Agr,
                    intermediate_value,
                    # filter_factor,
                    Switch_ЕТС_hist,
                    RI_ftp_curve_part,
                    Switch_Sum,
                    start_date,
                    end_date
                    ):
    return Main_Hist_Graph(Switch_Treshold, Switch_Agr,False,Switch_ЕТС_hist,RI_ftp_curve_part,Switch_Sum,start_date,end_date)




# Закладка - Триггер
# Меняем факторы повышения/снижения ЕТС по наведению мышки на основной график
# Сохраняем hover_data в store: Main_graph_hover_date_store
# Передаём назввание баннегов для блоков "Факторы повышения ЕТС" / "Факторы снижение ЕТС"
@app.callback(
    [
        Output("factor_Up_rows", "children"),
        Output("factor_Down_rows", "children"),
        Output("Main_graph_hover_date_store", "data"),
        Output("factor_Up_banner", "children"),
        Output("factor_Down_banner", "children"),
        # Output('materials_button_date', 'children')
        #     Output("my_output", "children"),
        #     Output('hover-data', 'children'),
    ],
    [
        Input("Main_Hist_Graph", "hoverData"),
        Input("RI_ftp_curve_part", "value"),
    ],
    prevent_initial_call=True
)
def Factor_Decomposition(hoverdata,RI_ftp_curve_part):
    # выкусываем дату из hoverdata
    date_friday = pd.to_datetime(hoverdata['points'][0]['x'], format='%Y-%m-%d')
    hover_date_str = date_friday.strftime("%Y-%m-%d")

    # Формируем текст над блоками с
    if date_friday is not None:
        date_monday = date_friday - timedelta(days=4)
        add_banner =  "( " + str(date_monday.strftime('%Y-%m-%d'))+' - '+str(date_friday.strftime('%Y-%m-%d'))+" )"
    else:
        add_banner = ""

    # Текст надписи под кнопкой с материалами
    status = 'На дату ' + hover_date_str

    return [
        Factor_Weight_Rows('factor_Up_Bar', date_friday, 'up',RI_ftp_curve_part),
        Factor_Weight_Rows('factor_Down_Bar', date_friday, 'down',RI_ftp_curve_part),
        hover_date_str,
        generate_section_banner("Факторы повышения ЕТС "+add_banner,'factors'),
        generate_section_banner("Факторы снижения ЕТС "+add_banner,'factors'),
        # status
    ]



# =================================================================================
# ======================================= Старые callbacks ========================
# =================================================================================







# Закладка "Факторы" - Реакция на выбор фактора.
#  Обновление описательных таблиц
# @app.callback([Output("Factor_Reaction_Table", "children"),
#                Output("Factor_Level_Table", "children")],
#               [Input("Factor_Dropdown", "value")],)
# def Main_Factor_Type(value):
#     return [Factor_Reaction_Table(value),
#             Factor_Level_Table(value)]


## Изменяем вид основного графика
# @app.callback(
#     Output("Switch_Treshold", "disable"),
#    [
#        Input("Switch_Agr", "value")
#    ],
# )
# def Switch_Treshold_Disable(Switch_Agr):
#    return Switch_Agr

# Закладка 1 - Переключалка в режим редактирования
# @app.callback(
#     Output("tab_graph_2", "children"),
#     Input("Switch_Calibration", "value"),
#     State("Main_graph_hover_date_store", "data")
# )
# def Hist_Graph_bottom_change(value,hover_date_str):
#
#     # if value:
#     #     return Hist_Graph_bottom('factors_calibr')
#     # else:
#     #     return Hist_Graph_bottom('factors_details',hover_date_str)
#
#     return Hist_Graph_bottom('factors_details', hover_date_str)

#
# # Тест -  реакция на ввод в input
# @app.callback(
#     [
#         Output(component_id='my-output', component_property='children'),
#         #Output("Main_Hist_Graph", "figure")
#     ],
#     [Input(component_id='my-input', component_property='value')]
# )
# def update_output_div(input_value):
#     text = ""
#     if input_value.isdigit():
#         text = 'Поменяли df'
#         Trigger.df_Factor_Set.loc['Eurobond', 'Breaking_Down_Up'] = int(input_value)
#         Trigger.Generate_FTP_Rec()
#     return [
#         'Output: {}'.format(input_value) + "  df:" + str(Trigger.df_Factor_Set.loc['Eurobond']['Breaking_Down_Up']) + "  text:" + text,
#        # Main_Hist_Graph(False, False)
#     ]


#Реакция на выбор фактора на закладке с калибровокой
@app.callback(

    [
        Output("Factor_Reaction_Table_Calibr", "children"),
        Output("Factor_Level_Table_Calibr", "children"),
        Output("hv_2", "children"),

#        Output("Main_Factor_Graph_Calibr", "figure"),
    ],
    [
        Input("Factor_Dropdown_calibr", "value"),
        # Input("RI_ftp_curve_part", "value")
    ],
    prevent_initial_call=True
)
def Calibr_data(value):
    return [
            Factor_Reaction_Table_Calibr(value),
            Factor_Level_Table(value, mode = 'Calibr'),
            value
            ]



#Меняем таблицы и график в режиме калибровке
@app.callback(
    Output("Main_Factor_Graph_Calibr", "figure"),
    [Input("hv_2", "children"),
    Input("hv_3", "children")]
    ,prevent_initial_call=True
)
def Calibr_data_Figure(hv_2,hv_3):
    ctx = dash.callback_context
    prop_id = ctx.triggered[0]['prop_id']

    if prop_id == 'hv_2.children':
        return Main_Factor_Graph(hv_2, mode='Calibr')
    else:
        return Main_Factor_Graph(hv_3, mode='Calibr')



# Закладка 1 - Кадибровка - Сохраняем изменения в таблице "Реакция на изменение уровней" в блоке Калибровка
@app.callback(
    [
        #Output('factor_set_table_output', 'children'),
        Output("my_output", "children"),
        Output('hover-data', 'children'),
        Output("hv_1", "children"),
        #Output("hv_3", "children")
    ],
    [
        Input("Factor_Dropdown_calibr", "value"),
        Input('factor_reaction_table_calibr', 'active_cell'),
        Input('factor_level_table_calibr', 'active_cell')
    ],

    [
        State('factor_reaction_table_calibr', 'data'),
        State('factor_level_table_calibr', 'data')
    ]
)

# Сохраняем уровни пробития при изменении в таблице в режиме "Калибровки"
def Save_Factor_Calibr_Set(factor_name,
                           active_cell_reaction,active_cell_level,
                           reaction_data,level_data):

    # !!!!!!!!!!! Как работает !!!!!!!!!
    # active_cell_reaction, active_cell_level - данные об активной ячейке в таблице
    # Имеют вид:
    #        {
    #            "row": 0,
    #            "column": 1,
    #            "column_id": "2"
    #        }

    # reaction_data, level_data - текущие данные в таблицке
    # Имеют вид (на примере reaction_data):
    # [
    #     {
    #         "1": "\u0412\u043d\u0438\u0437",
    #         "2": "\u0421\u043d\u0438\u0436\u0435\u043d\u0438\u0435 \u0441\u0442\u0430\u0432\u043e\u043a",
    #         "3": 1,
    #         "4": 0,
    #         "5": 1
    #     },
    #     {
    #         "1": "\u0412\u043d\u0438\u0437",
    #         "2": "\u041f\u043e\u0432\u044b\u0448\u0435\u043d\u0438\u0435 \u0441\u0442\u0430\u0432\u043e\u043a",
    #         "3": 0,
    #         "4": 0,
    #         "5": 0
    #     },
    #     {
    #         "1": "\u0412\u0432\u0435\u0440\u0445",
    #         "2": "\u0421\u043d\u0438\u0436\u0435\u043d\u0438\u0435 \u0441\u0442\u0430\u0432\u043e\u043a",
    #         "3": 0,
    #         "4": 0,
    #         "5": 0
    #     },
    #     {
    #         "1": "\u0412\u0432\u0435\u0440\u0445",
    #         "2": "\u041f\u043e\u0432\u044b\u0448\u0435\u043d\u0438\u0435 \u0441\u0442\u0430\u0432\u043e\u043a",
    #         "3": 0,
    #         "4": 0,
    #         "5": 0
    #     }
    #  ]





    # dash.callback_context - глобальная переменная описания callback
    # https: // dash.plotly.com / advanced - callbacks
    ctx = dash.callback_context

    # Форма для печати. Выгружать надо в html.Pre, не в html.Div
    ctx_msg = json.dumps({
        'triggered': ctx.triggered,
        'states': ctx.states,
        'inputs': ctx.inputs,
        # 'outputs_list': ctx.outputs_list,
        # 'inputs_list': ctx.inputs_list,
        # 'states_list': ctx.states_list,

    }, indent=4)



    # Callback может вызвать и изменение "Factor_Dropdown_calibr.value"
    # Надо проверить, что активны ячейки. После Factor_Dropdown_calibr.value - таблицы перерисовываются и ячейки не активны
    if (active_cell_reaction or active_cell_level) :
        # Считываем как Inputs вызывал callback
        prop_id = ctx.triggered[0]['prop_id']

        if prop_id == 'factor_reaction_table_calibr.active_cell':
            row = ctx.triggered[0]['value']['row']
            factor_set = reaction_desc_num[row]
            # factor_value = ctx.states['factor_reaction_table_calibr.data'][row]["3"]
            factor_value = reaction_data[row]["3"]

            # Бежим по строкам таблицы
            for i, key in enumerate(reaction_column.values()):
                Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name, key[0]] = reaction_data[i]["3"]
                Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name, key[1]] = reaction_data[i]["4"]
                Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name, key[2]] = reaction_data[i]["5"]



            # for i in range(len(reaction_data)):
            #     Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name, reaction_desc_num[i]] = reaction_data[i]["3"]

        elif prop_id == 'factor_level_table_calibr.active_cell':
            row = ctx.triggered[0]['value']['row']
            factor_set = level_desc_num[row]
            # factor_value = ctx.states['factor_level_table_calibr.data'][row]["2"]
            factor_value = level_data[row]["2"]

            measure = Trigger.df_Factor_Set.loc[factor_name]['measure']
            measure_multip = Trigger.df_Factor_Set.loc[factor_name]['measure_multip']

            # Определяем значение множителя
            if measure == 'P':
                factor_value_mult = 0.01 * measure_multip
            else:
                factor_value_mult = 1 * measure_multip


            for i in range(len(level_data)):
                if level_data[i]["2"] is not None:
                    Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name,level_desc_num[i]] = level_data[i]["2"]*factor_value_mult

        if prop_id in ['factor_reaction_table_calibr.active_cell','factor_level_table_calibr.active_cell']:
            Trigger.Generate_FTP_Rec()
            return [#json.dumps({'active_cell_reaction':active_cell_reaction,'active_cell_level':active_cell_level}, indent=4),
                    json.dumps({'reaction_data': reaction_data, 'level_data': level_data},indent=4),
                    ctx_msg,
                    '  Фактор: ' + factor_name + '   Настройка фактора: ' + factor_set + '   Строка(row): ' + str(row) + '   Значенеи(factor_value): ' + str(factor_value),
                    # factor_name
            ]

    return [
            json.dumps(reaction_data, indent=4),
            ctx_msg,
             1,
            #factor_name
    ]




# Factor_Level_Table
# Сохраняем изменения в таблице "Уровни (верхние границы)" на закладке "Факторы"
# @app.callback(
#     [
#         Output("Main_Factor_Graph", "figure"),
#         Output("my_output_factor", "children"),
#         Output('hover_data_factor', 'children'),
#         #Output("hv_3", "children")
#     ],
#     [
#         Input("Factor_Dropdown", "value"),
#         Input("factor_level_table", "active_cell")
#     ],
#
#     [
#          State('factor_level_table', 'data')
#     ],
#     prevent_initial_call=True
#
# )
# def Save_Factor_Calibr_Set(factor_name,
#                            # active_cell_level,
#                            # level_data
#                            ):
#     ctx = dash.callback_context
#
#     # Форма для печати. Выгружать надо в html.Pre, не в html.Div
#     ctx_msg = json.dumps({
#         'triggered': ctx.triggered,
#         'states': ctx.states,
#         'inputs': ctx.inputs,
#         # 'outputs_list': ctx.outputs_list,
#         # 'inputs_list': ctx.inputs_list,
#         # 'states_list': ctx.states_list,
#     }, indent=4)
#
#     prop_id = ctx.triggered[0]['prop_id']
#
#     my_output_factor = 'Ложная тревога '
#
#
#     if active_cell_level and prop_id != 'Factor_Dropdown.value':
#         my_output_factor = 'Меняем для '+factor_name+prop_id
#
#
#
#         measure = Trigger.df_Factor_Set.loc[factor_name]['measure']
#         measure_multip = Trigger.df_Factor_Set.loc[factor_name]['measure_multip']
#
#         # Определяем значение множителя
#         if measure=='P':
#             factor_value_mult = 0.01 * measure_multip
#         else:
#             factor_value_mult = 1 * measure_multip
#
#         for i in range(len(level_data)):
#             if level_data[i]["2"] is not None:
#                 Trigger.df_Factor_Set.loc[Trigger.df_Factor_Set['factor_file'] == factor_name, level_desc_num[i]] = level_data[i]["2"]*factor_value_mult
#
#     return [Main_Factor_Graph(factor_name),
#             my_output_factor,
#             ctx_msg
#             #json.dumps(ctx, indent=4)
#             ]




# Сохраняем изменения в большой таблице на странице "Настройка факторов"
@app.callback(
    [
        Output('download-link', 'href'),
        Output('factor_set_table_output', 'children')
    ],

    [Input('factor_set_table', 'data_timestamp')],
    [State('factor_set_table', 'data')],
    prevent_initial_call=True
)
def update_columns(timestamp, rows):
    ctx = dash.callback_context
    ctx_msg = json.dumps({
        #'states': ctx.states,
        'triggered': ctx.triggered,
        'inputs': ctx.inputs
    }, indent=2)

    df = pd.DataFrame.from_dict(rows)
    df = df.set_index('factor_file')
    df['factor_file'] = df.index
    df = to_numeric_df_Factor_set(df)
    Trigger.df_Factor_Set = df

    # Подготавливаем выгрузку в csv
    csv_string =csv_from_Factor_Set()

    #df['factor_file'] = df.index

    # Переводим колонки в числа


    Trigger.Generate_FTP_Rec()

    return csv_string, ctx_msg

# закладка "Калибровка Факторов"
# кнопка "Вывберите файл"
# реакция на выбор файла для настройки факторов
@app.callback(
    [
        Output('factor_set_table_div', 'children'),
        Output('file_name_factor_set', 'children'),
        #Output('factor_set_table_output', 'children')
    ],
    Input('upload-data', 'contents'),
    State('upload-data', 'filename')
    , prevent_initial_call=True
)
def update_output(contents, file_name):
    #children = "list_of_contents: "+ str(list_of_contents) +" list_of_names: "+ str(list_of_names) +" list_of_dates:"+ str(list_of_dates)

    Trigger.path_Factor_Set = file_name

    # content_type, content_string = contents.split(',')
    # decoded = base64.b64decode(content_string)
    # Trigger.df_Factor_Set = pd.read_csv(
    #     io.StringIO(decoded.decode('utf-8')),
    #     sep=';', encoding='utf8'
    # )

    Trigger.Load_FactorSet()

    Trigger.Generate_FTP_Rec()

    return [Factor_Set_Table(),
            'Текущее имя файла: '+Trigger.path_Factor_Set,
            #file_name
            ]

# Нажатие кнопки "Метериалы изменения" materials_button
@app.callback(
    Output('materials_button_status', 'children'),
    Input('materials_button', 'n_clicks'),
    State("Main_graph_hover_date_store", "data")
    , prevent_initial_call=True
)
def materials_button_click(btn1, hover_date_str):
    if hover_date_str is None:
        status =  'Не выбрана дата на графике!'
    else:

        # Ищем нужную папку
        folder_name = list(df_folder.loc[df_folder['ETC_date_Friday_str'] == hover_date_str]['Dir_Name'])

        if len(folder_name) != 0:
            # Формируем путь
            file_path = os.path.join(materials_path,folder_name[0])
            file_path = os.path.realpath(file_path)
            # Открываем директорию
            os.startfile(file_path)
            status = ''

        else:
            status = 'Не нашли материалов на дату!'


    return status




#==========================================================================
#=========================== Анализ Модели ================================
#==========================================================================







# Анализ таблицы. Обновление таблицы со стастистикой срабатывания модели
@app.callback(
    [
        Output("MA_Model_Main_Stat_id", "children"),
        Output("MA_Block_Main_Stat_id", "children"),
        Output("MA_Model_Graph_id", "figure")
    ],
    [
        Input("MA_Versions_RadioItems_id", "value"),
        Input("MA_Model_Dropdown_id", "value"),
    ],

)
def MA_Model_Table_Stat(version,model):


    return [MA_Model_Main_Stat_Table(version,model),
            MA_Block_Main_Stat_Table(version,model),
            MA_Model_Graph(version=version,
                           MODEL=model
                           )
            ]





# Анализ модели.
# Меняем таблицу с ФАКТОРАМИ в зависимости от строчки в таблицы с БЛОКАМИ
@app.callback(
      [ Output('MA_Factor_Main_Stat_id', 'children'),
        Output("MA_Block_Graph_id", "figure")
        # Output("helper_Pre1", "children"),
        # Output('helper_Div1', 'children'),
        # Output('helper_Div2', 'children'),
    ],
    [
        Input("MA_Table_Block_Main_Stat_id", "active_cell"),
        Input("MA_Versions_RadioItems_id", "value"),
        Input("MA_Model_Dropdown_id", "value"),
    ],

    [
        State('MA_Table_Block_Main_Stat_id', 'data'),
    ],
    prevent_initial_call=True
)
def MA_Factor_Table(active_cell,
                    version,
                    model,
                    table_data):


    if active_cell:

        table_selected_data = Get_Data_Table_Callback(active_cell,table_data)

        block = table_selected_data['selected_row']['segment_name']



        return [MA_Factor_Main_Stat_Table(version,model,block),

                MA_Block_Graph(version=version,
                               MODEL=model,
                               BLOCK=block_converter[block],
                               #                        FACTORS = ['clt_gain_sum']
                               )

                # MA_Factor_Main_Stat_Table('long_up',str(table_selected_data['selected_row']['segment_name'])),
                # "prop_id:    " + table_selected_data['prop_id'],
                # "selected_row:   " + str(table_selected_data['selected_row']['segment_name']),
                # "params:    " + f'version = {version} model = {model} block = {block}',
                # "prop_id:   " + str(table_selected_data['prop_id']),
               ]

    else:
        return[dash.no_update,dash.no_update]






# Анализ модели.
# Меняем ГРАФИК фактора в зависимости, от выбранного ФАКТОРА в таблице
@app.callback(
     [  Output('MA_Factor_Graph_id', 'figure'),
        # Output("ma_my_output_factor", "children"),
        # Output('ma_hover_data_factor', 'children'),
        # Output("ma_help_output", "children"),
        # Output("ma_help_output_2", "children")
    ],
    [
        Input("MA_Table_Factor_Main_Stat_id", "active_cell"),
    # ],
    #
    # [
        State('MA_Table_Factor_Main_Stat_id', 'data'),
    ],


    prevent_initial_call=True
)
def MA_Graph(Factor_active_cell,
             Factor_table_data,
                    ):

    if Factor_active_cell:
        Factor_table_selected_data = Get_Data_Table_Callback(Factor_active_cell,Factor_table_data)

        model = Factor_table_selected_data['selected_row']['model']
        factor = Factor_table_selected_data['selected_row']['factor']
        block = Factor_table_selected_data['selected_row']['block']
        factor_desc = Factor_table_selected_data['selected_row']['desc']

        fig = MA_Factor_Graph(
            version = '2024-12-28 V2.2',
            MODEL = model,
            block = block,
            FACTORS = [factor],
            factor_desc = factor_desc
        )

        if fig is None:
            return [{'data': []}]

        return [fig,

               # "prop_id:    " + Factor_table_selected_data['prop_id'],
               # "selected_row:   " + str(Factor_table_selected_data['selected_row']),
               # "data:    " + f'model = {model} block = {block} factor = {factor}',
               # "prop_id:   " + str(Factor_table_selected_data['prop_id']),
               ]
    else:
        return[dash.no_update]





# Функция возвращает данные по выбранной ячейки в таблице
def Get_Data_Table_Callback(active_cell,table_data):
    # Смотрим на состояние call_back
    # Иногда нужно для того, чтоб понять кто его вызвал
    ctx = dash.callback_context

    # Форма для печати. Выгружать надо в html.Pre, не в html.Div
    ctx_msg = json.dumps({
        'triggered': ctx.triggered,
        'states': ctx.states,
        # 'inputs': ctx.inputs,
        # 'outputs_list': ctx.outputs_list,
        # 'inputs_list': ctx.inputs_list,
        # 'states_list': ctx.states_list,
    }, indent=4)

    # Процесс, который вызвал callback
    prop_id = ctx.triggered[0]['prop_id']

    # logging.info(f"ctx.triggered = {ctx.triggered}  prod_id = {prod_id} ")

    # Получаем данные об выбранной ячейке
    # active_cell
    if active_cell:
        active_cell_msg = f"col = {active_cell['column']} row = {min (active_cell['row'],len(table_data))}  col_id = {active_cell['column_id']}"
    else:
        active_cell_msg = "Нет выбрана ячейка"


    # Данные в таблице
    try:
        selected_row_table_data = table_data[active_cell['row']]
    except:
        selected_row_table_data = str(active_cell)

    # Данные в таблице
    try:
        selected_cell_table_data = table_data[active_cell['row']][active_cell['column_id']]
    except:
        selected_cell_table_data = str(active_cell)


    return_data = {}
    return_data['ctx_msg'] =  ctx_msg
    return_data['active_cell_msg'] = active_cell_msg
    return_data['state_data'] = table_data
    return_data['prop_id'] = prop_id
    return_data['selected_row_num'] = active_cell['row']
    return_data['selected_col_num'] = active_cell['column']
    return_data['selected_column_id'] = active_cell['column_id']
    return_data['selected_row'] = selected_row_table_data
    return_data['selected_cell'] = selected_cell_table_data


    return return_data


# ===================================================================================
# ================================== FastTrack ======================================
# ===================================================================================

# реакция на выбор папки в fast track
# пишем в переменную
@app.callback(
    Output('fasttrack-de-data-title', 'children'),
    Output('fasttrack-de-data-grid', 'rowData'),
    Output('fasttrack-de-data-grid', 'columnDefs'),
    Output('fasttrack-de-data-grid-filter', 'options'),
    Output('fasttrack-de-data-grid-filter', 'disabled'),
    Output('fasttrack-run-status-store', 'data'),
    Input('fasttrack_DE_data_id', 'value'),
    Input('fasttrack-update-button', 'n_clicks'),
    State('fasttrack-run-status-store', 'data'),
    prevent_initial_call=True
)
def Fast_Track_folder_select(folder_name, button_click, status_store_data):
    logging.info(f'Callback Fast_Track_folder_select: Выбрали директорию с данными от DE (folder_name = {folder_name})')

    if not folder_name:
        return ["", [], [], [], True] + [dash.no_update]

    # глобальная конфигурация данных
    data_config = DataConfig(calc_date=folder_name, data_path=app_config.data_folder)
    daily_df = load_data(data_config.schema['factors_daily'])

    if daily_df.empty:
        return ["Данные на выбранную дату отсутствуют", [], [], [], True] + [dash.no_update]

    columnDefs = fasttrack_dedata_table_columnDefs(daily_df=daily_df)
    
    # обновление статуса
    state = status_store_data.get("state")
    if state != CalcState.RUNNING.value:
        status_store_data = {"state": CalcState.IDLE.value, "message": CalcMessage.IDLE.value}

    return  [
        f"Данные витрины на {pd.to_datetime(folder_name, dayfirst=False).date().strftime('%d.%m.%Y')}",
        daily_df.to_dict("records"),
        columnDefs,
        daily_df.columns[1:],
        False,
        status_store_data,
    ]


# Реакция на фильтры для грида
@app.callback(
    Output("fasttrack-de-data-grid", "scrollTo", allow_duplicate=True),
    Output("fasttrack-de-data-grid", "columnDefs", allow_duplicate=True),
    Input("fasttrack-de-data-grid-filter", "value"),
    State("fasttrack-de-data-grid", "scrollTo"),
    State("fasttrack-de-data-grid", "columnDefs"),
    prevent_initial_call=True
)
def FastTrack_DE_scroll_to_row_and_col(
    column,
    scroll_to,
    defs
    ):
    logging.info(f'callback.FastTrack_DE_scroll_to_row_and_col: Настраиваем фильтр для таблицы с витриной от DE (column = {column},  scroll_to = {scroll_to} )')

    scroll_to = scroll_to or {}
    # scroll_to["rowIndex"] = row_index
    scroll_to["column"] = column
    # scroll_to["rowPosition"] = row_position
    scroll_to["columnPosition"] = 'start'

    for col in defs:
        if col["field"] == column:
            col["cellClass"] = "highlight-col"
            col["headerClass"] = "highlight-header"
        else:
            col.pop("cellClass", None)
            col.pop("headerClass", None)

    return scroll_to, defs

# Реакция на рендер таблицы
@app.callback(
    Output("fasttrack-de-data-grid", "scrollTo"),
    Input("fasttrack-de-data-grid", "rowData"),
    State("fasttrack-de-data-grid", "scrollTo"),
    prevent_initial_call=True
)
def FastTrack_DE_scroll_to_end_row(
    rows,
    scroll_to
    ):

    if not rows:
        return dash.no_update

    scroll_to = scroll_to or {}
    scroll_to["rowIndex"] = len(rows) - 1
    scroll_to["position"] = "bottom"

    return scroll_to


# Загрузка файлов c витриной от DE
@app.callback(
    Output('upload_DE_data_result_id', 'children'),
    Input('upload_DE_data_files_id', 'contents'),
    State('upload_DE_data_files_id', 'filename'),
    State('upload_DE_data_files_id', 'last_modified'),
    State('upload_DE_data_date_id', 'date'),
    State('upload_DE_data_date_add_id', 'value'),
    prevent_initial_call=True
)
def Save_DE_data_files(list_of_contents, list_of_names, list_of_dates, date, add_version):
    logging.info(f'callback.Save_DE_data_files: Отправили на загрузку файл (date = {date}  add_version = {add_version} )')

    if add_version is not None:
        save_folder = f'{date}_{add_version}'
    else:
        save_folder = f'{date}'

    save_directory = app_config.DE_data_path

    output_layout = []
    success = True
    try:
        # запускаем общую процедуру сохранения в директорию
        output_layout = run_save_upload_files(list_of_contents, list_of_names, list_of_dates,
                                            save_folder, save_directory)
    except Exception as e:
        success = False
        logging.error(f"Ошибка при запуске общей процедуры сохранения: {e}")
    finally:
        get_audit_logger().audit_other_operation(
            description=f"Импортированы данные из файла через раздел 'Загрузка данных'; date: '{date}', version: '{add_version}'; path '{os.path.join(save_directory, save_folder)}' )",
            status= "SUCCESS" if success == True else "FAIL"
        )

    return html.Div(output_layout)

def full_model_pipeline(calc_date: str):
    global status_queue
    
    # очистка queue
    _ = read_queue(status_queue)

    # глобальная конфигурация данных
    data_config = DataConfig(calc_date=calc_date, data_path=app_config.data_folder)

    t0 = datetime.now().time()
    
    status_queue.put({"state": CalcState.RUNNING.value, "message": CalcMessage.RUNNING.value, "rec_date": calc_date})
    logging.info(f"callback.full_model_pipeline: Запуск модельных расчетов на дату {calc_date} {t0}")
    try:
        # --- Кусок предобработки данных ---
        run_data_preprocessing(data_config=data_config)
        logging.info(f"Данные приведены к понедельному виду {datetime.now().time()}")
        # --- Кусок модельных расчетов ---
        run_model_calculation(data_config=data_config)
        logging.info(f"Результаты модели получены {datetime.now().time()}")
        # --- Кусок создания отчета для навигатора ---
        run_navigator(data_config=data_config)
        logging.info("Отчет по результатам модели сформирован")

        status_queue.put({"state": CalcState.COMPLETED.value, "message": CalcMessage.COMPLETED.value, "rec_date": calc_date})
        logging.info(f"callback.full_model_pipeline: Модельные расчеты на дату {calc_date} завершены {t0} -> {datetime.now().time()}")
    except Exception:
        status_queue.put({"state": CalcState.ERROR.value, "message": CalcMessage.ERROR.value, "rec_date": calc_date})
        logging.error(f"callback.full_model_pipeline: Модельные расчеты на дату {calc_date} завершены с ошибкой", exc_info=True)

# Действие при нажатии на кнопку "Запуск модели" на закладке Fast Track
@app.callback(
    Output('fasttrack-run-btn', 'disabled'),
    Output('fasttrack-run-status-check', 'disabled', allow_duplicate=True),
    Output('fasttrack-run-status-store', 'data', allow_duplicate=True),
    Output('fasttrack-run-progress-store', 'data', allow_duplicate=True),
    Input('fasttrack-run-btn', 'n_clicks'),
    State('fasttrack_DE_data_id', 'value'),
    State('fasttrack-run-status-check', 'disabled'),
    prevent_initial_call=True,
)
def Fast_Track_Run_Model(
    n_clicks,
    #  virtualRowData,
    fasttrack_DE_folder,
    interval_disabled
    ):

    logging.info(f'callback.Fast_Track_Run_Model: callback на запуск модели')

    ctx = dash.callback_context
    trigger_info = ctx.triggered[0]
    n_click_value = trigger_info['value']

    # Игнорируем вызовы при загрузке страницы (n_clicks = 0 или None)
    if not ctx.triggered or n_click_value is None or n_click_value < 1 or fasttrack_DE_folder is None:
        logging.info(f'callback.Fast_Track_Run_Model: callback проигнорирован')
        return [dash.no_update] * 4

    # Папка должна называться как дата! В конфигах прописана жесткая структура, зависящая от даты расчета
    calc_date = fasttrack_DE_folder
    logging.info(f"callback.Fast_Track_Run_Model: {calc_date}")

    # запуск в отдельном потоке
    current_task = threading.Thread(target=full_model_pipeline, args=[calc_date], daemon=True)
    current_task.start()
    
    # основная информация по запуску
    # блокируем кнопку повторного запуска - не ломается ли это при переключении вкладок?
    run_btn_disabled = True
    # запускаем отслеживание прогресса
    status_check_disabled = False
    
    # мгновенное состояние - running
    status_store_data = {"state": CalcState.RUNNING.value, "message": CalcMessage.RUNNING.value, "rec_date": ""}
    # задание стартового значения прогресса
    progress_value = 0
    
    return run_btn_disabled, status_check_disabled, status_store_data, progress_value

# callback для опроса очереди и записи в Store
@app.callback(
    Output('fasttrack-run-status-store', 'data', allow_duplicate=True),
    Input('fasttrack-run-status-check', 'n_intervals'),
    State('fasttrack-run-status-store', 'data'),
    prevent_initial_call=True
)
def fasttrack_update_store(n, store_data):
    global status_queue
    queue_data = read_queue(status_queue)    
    if queue_data:
        return queue_data
    return store_data

# Обновление статуса работы модели
@app.callback(
    Output('fasttrack-run-btn', 'disabled', allow_duplicate=True),
    Output('fasttrack-download-btn', 'color'),
    Output('fasttrack-run-status', 'children', allow_duplicate=True),
    Output('fasttrack-run-status', 'className', allow_duplicate=True),
    Input('fasttrack-run-status-store', 'data'),
    prevent_initial_call=True
)
def fasttrack_status_check(store_data):
    
    state = store_data.get("state")
    message = store_data.get("message", "")
    
    className = "fasttrack-run-status {}"
    
    if state == CalcState.RUNNING.value:
        run_btn_disabled = True
        download_btn_color = 'secondary'
        status_child = html.Div([
            html.Div(className="loader"),
            html.Span(message)
        ])
    elif state == CalcState.COMPLETED.value:
        run_btn_disabled = False
        download_btn_color = 'primary'
        status_child = message
    elif state == CalcState.ERROR.value:
        run_btn_disabled = False
        download_btn_color = 'secondary'
        status_child = message
    elif state == CalcState.IDLE.value:
        run_btn_disabled = False
        download_btn_color = 'secondary'
        status_child = message
    
    className = className.format(state)

    return run_btn_disabled, download_btn_color, status_child, className

# callback для опроса очереди и записи в Store
@app.callback(
    Output('fasttrack-run-progress-store', 'data', allow_duplicate=True),
    Input('fasttrack-run-status-store', 'data'),
    State('fasttrack-run-progress-store', 'data'),
    State('fasttrack-run-status-check', 'interval'),
    prevent_initial_call=True
)
def fasttrack_update_progress_store(status_store_data, progress_store_value, interval):
    
    state = status_store_data.get("state")
    
    if state == CalcState.COMPLETED.value or state == CalcState.ERROR.value:
        return 100
    elif state == CalcState.IDLE.value:
        return 0
    
    progress_value = calc_approx_progress(
        cur_progress=progress_store_value,
        expected_duration=6*60, # 6 мин
        max_progress=95,
        update_freq=interval/1_000
    )
    
    return progress_value    

# Обновление статуса работы модели
@app.callback(
    Output('fasttrack-run-progress', 'value', allow_duplicate=True),
    Output('fasttrack-run-progress', 'label', allow_duplicate=True),
    Output('fasttrack-run-progress', 'striped'),
    Output('fasttrack-run-progress', 'animated'),
    Output('fasttrack-run-progress', 'color'),
    Output('fasttrack-run-status-check', 'disabled', allow_duplicate=True),
    Input('fasttrack-run-progress-store', 'data'),
    State('fasttrack-run-status-store', 'data'),
    prevent_initial_call=True
)
def fasttrack_run_progress(progress_store_value, status_store_data):
    
    state = status_store_data.get("state")
    
    if state == CalcState.RUNNING.value:
        progressbar_val = progress_store_value
        progressbar_label = f"{progress_store_value:.0f}%" if progress_store_value >= 10 else ""
        striped, animated = True, True
        color = "info"
        # обновление включено
        interval_disabled = False
    elif state == CalcState.COMPLETED.value:
        progressbar_val = 100
        progressbar_label = "100%"
        striped, animated = False, False
        color = "success"
        # отключаем обновление
        interval_disabled = True
    elif state == CalcState.ERROR.value:
        progressbar_val = 100
        progressbar_label = ""
        striped, animated = False, False
        color = "danger"
        # отключаем обновление
        interval_disabled = True
    elif state == CalcState.IDLE.value:
        progressbar_val = 0
        progressbar_label = ""
        striped, animated = False, False
        color = "info"
        # отключаем обновление
        interval_disabled = True

    return progressbar_val, progressbar_label, striped, animated, color, interval_disabled

# Всплывающее окно с уведомлением о завершении расчета
@app.callback(
    Output("fasttrack-modal-status-completed", "is_open"),
    Output("fasttrack-modal-status-completed-body", "children"),
    Input("fasttrack-run-status-store", "data"),
    prevent_initial_call=True
)
def fasttrack_completed_modal(status_store_data):
    state = status_store_data.get("state")
    rec_date = status_store_data.get("rec_date")
    
    success_modal_body_msg = f"Получены рекомендации по модели на {rec_date}."
    error_model_body_msg = f"Расчет на {rec_date} завершен с ошибкой."
    
    if state == CalcState.COMPLETED.value:
        return True, success_modal_body_msg
    elif state == CalcState.ERROR.value:
        return True, error_model_body_msg
    
    return False, ""

# Скачивание результатов работы модели
@app.callback(
    Output('fasttrack-download-zip', 'data'),
    Output('fasttrack-modal-no-file', 'is_open'),
    Output('fasttrack-modal-no-date', 'is_open'),
    Input('fasttrack-download-btn', 'n_clicks'),
    State('fasttrack_DE_data_id', 'value'),
    prevent_initial_call=True
)
def fasttrack_download_res(n_clicks, fasttrack_DE_folder):

    if fasttrack_DE_folder is None:
        return None, False, True

    try:
        # глобальная конфигурация данных
        data_config = DataConfig(calc_date=fasttrack_DE_folder, data_path=app_config.data_folder)

        navigator_report_params = data_config.schema['navigator_report'].source_params
        navigator_zip_file = os.path.join(navigator_report_params['path'], navigator_report_params['filename'])

        if os.path.exists(navigator_zip_file):
            get_audit_logger().audit_other_operation(
                description=f"Пользователь скачал результаты работы модели из секции 'Fast Track'",
                status= "SUCCESS"
            )
            return dcc.send_file(navigator_zip_file), False, False

    except Exception as e:
        logging.error(f"Ошибка при скачивании результатов : {e}")
        get_audit_logger().audit_other_operation(
                description=f"Не удалось скачать результаты работы модели из секции 'Fast Track'",
                status= "FAIL"
            )

    return None, True, False

# Реакция на выбор даты витрины - таблица с рекомендациями модели
@app.callback(
    Output('fasttrack-model-rec-grid', 'rowData'),
    Output('fasttrack-model-rec-grid', 'columnDefs'),
    Input('fasttrack_DE_data_id', 'value'),
    # Input('fasttrack-run-status', 'children'),
    prevent_initial_call=True
)
def fasttrack_build_rec_table(
    fasttrack_DE_folder,
    # status_msg
    ):

    if not fasttrack_DE_folder:
        return [], []

    calc_date = fasttrack_DE_folder

    # глобальная конфигурация данных
    data_config = DataConfig(calc_date=calc_date, data_path=app_config.data_folder)

    # загрузка данных
    data_ewi = load_data(data_config.schema["data_ewi"])
    data_ewi_archive = load_data(data_config.schema["total_res_archive"])["data_ewi"]

    if data_ewi.empty or data_ewi_archive.empty:
        return [], []

    # делаем таблицу с текущими и архивными рекомендациями
    joint_tbl = fasttrack_make_joint_rec_table(data_ewi=data_ewi, data_ewi_archive=data_ewi_archive)
    # табличка с сигналами в нужном формате
    signals_tbl = fasttrack_make_signals_table(joint_tbl=joint_tbl, n_weeks=4)

    first_order_version = signals_tbl["version"].iloc[0]
    # типы для столбцов
    columnDefs = fasttrack_rec_table_columnDefs(signals_tbl_columns=signals_tbl.columns, first_order_version=first_order_version)

    return signals_tbl.to_dict("records"), columnDefs

@app.callback(
    Output('fasttrack-block-graph-filter', 'options'),
    Output('fasttrack-block-graph-filter', 'value'),
    Output('fasttrack-block-graph-filter', 'disabled'),
    Input("fasttrack-model-rec-grid", "rowData"),
    prevent_initial_call=True
)
def fasttrack_blocks_dropdown(
    model_rec_rows
    ):

    if not model_rec_rows:
        return [], [], True

    models = sorted(list(set([row["model"] for row in model_rec_rows])))

    return models, models[0], False

@app.callback(
    Output('fasttrack-block-graph', 'figure'),
    Input('fasttrack-block-graph-filter', 'value'),
    Input('fasttrack-block-graph-check', 'value'),
    Input("fasttrack-model-rec-grid", "rowData"),
    State('fasttrack_DE_data_id', 'value'),
    prevent_initial_call=True
)
def fasttrack_blocks_plot(
    selected_model,
    add_pattern,
    model_rec_rows,
    fasttrack_DE_folder
    ):

    if not fasttrack_DE_folder or not selected_model or not model_rec_rows:
        return empty_graph_template()

    calc_date = fasttrack_DE_folder

    # глобальная конфигурация данных
    data_config = DataConfig(calc_date=calc_date, data_path=app_config.data_folder)
    # загрузка данных
    data_ewi = load_data(data_config.schema["data_ewi"])
    blocks_ewi_archive = load_data(data_config.schema["total_res_archive"])["data_3_signals"]

    if blocks_ewi_archive.empty or data_ewi.empty:
        return empty_graph_template()

    comb_ewi_df = fasttrack_make_joint_blocks_table(data_ewi=data_ewi, blocks_ewi_archive=blocks_ewi_archive)
    model_df = fasttrack_make_restricted_blocks_table(comb_ewi_df=comb_ewi_df, model=selected_model, all_dates=data_ewi["report_date"].unique(), n_weeks=10)

    add_pattern = True if add_pattern else False
    fig = fasttrack_plot_blocks_signals(model_df=model_df, add_pattern=add_pattern)

    return fig
