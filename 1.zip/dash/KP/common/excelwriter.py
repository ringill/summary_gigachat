#!/usr/bin/env python
# coding: utf-8

import os
import pandas as pd
import openpyxl as xl



def save_excel_sheet(df, filepath, sheet_name='Sheet1', datetime_format='%d.%m.%Y', date_format='%d.%m.%Y', **kwargs):
    
    if not os.path.exists(filepath):
        with pd.ExcelWriter(filepath, datetime_format=datetime_format, date_format=date_format) as writer:
            df.to_excel(writer, sheet_name=sheet_name, **kwargs)
            
    else:
        with pd.ExcelWriter(
            filepath, 
            engine='openpyxl', 
            if_sheet_exists='replace', 
            mode='a', 
            datetime_format=datetime_format, 
            date_format=date_format
        ) as writer:
            df.to_excel(writer, sheet_name=sheet_name, **kwargs)

def excel_write_table(df: pd.DataFrame, pivot_path, sheet_name, start_row=0, start_col=0):
    
    if not os.path.exists(pivot_path):
        raise ValueError('Pivot file does not exist!')
        
    wb = xl.load_workbook(pivot_path)
    
    if sheet_name not in wb.sheetnames:
        raise ValueError('Sheet not in file')

    sheet = wb[sheet_name]
    
    n_rows, n_cols = df.shape
    data = df.to_numpy()
    cols = df.columns
    
    # Запишем названия столбцов
    # В либе нумерация с 1, поэтому +1
    for j in range(len(cols)):
        sheet.cell(row=start_row+1, column=j+start_col+1).value = cols[j]

    # Запишем новые данные
    for i in range(n_rows):
        for j in range(n_cols):
            sheet.cell(row=i+start_row+2, column=j+start_col+1).value = data[i][j]

    wb.save(pivot_path)
            
def excel_rewrite_table(df: pd.DataFrame, pivot_path, sheet_name):
    
    if not os.path.exists(pivot_path):
        raise ValueError('Pivot file does not exist!')
        
    wb = xl.load_workbook(pivot_path)
    
    if sheet_name not in wb.sheetnames:
        raise ValueError('Sheet not in file')

    sheet = wb[sheet_name] 
    
    n_rows, n_cols = df.shape
    data = df.to_numpy()

    # Оставим заголовки, затрем старые данные
    for col in sheet.iter_cols(min_row=2, max_col=n_cols):
        for cell in col:
            cell.value = None

    # Запишем новые данные
    for i in range(n_rows):
        for j in range(n_cols):
            sheet.cell(row=i+2, column=j+1).value = data[i][j]

    wb.save(pivot_path)
    
def excel_clear_sheet(pivot_path, sheet_name):
    
    if not os.path.exists(pivot_path):
        raise ValueError('Pivot file does not exist!')

    wb = xl.load_workbook(pivot_path)
    
    if sheet_name not in wb.sheetnames:
        raise ValueError('Sheet not in file')

    sheet = wb[sheet_name]

    for col in sheet.iter_cols():
        for cell in col:
            cell.value = None

    wb.save(pivot_path)