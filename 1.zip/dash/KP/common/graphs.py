#!/usr/bin/env python
# coding: utf-8

import os
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import logging
# from Model_analysis.validation_v2 import get_runs
from ..Model_analysis.validation_v2 import get_runs

# import plotly.express as px
# fig = px.colors.qualitative.swatches()
# fig.show()


save_params_dict = dict(height=900, width=1800, title_y=0.91, title_x=0.045)
show_params_dict = dict(height=650, width=1000, title_y=0.88, title_x=0.08)


def find_outliers_IQR(series, n_IQR=3):
    
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    
    lower = Q1 - n_IQR * IQR
    upper = Q3 + n_IQR * IQR
    
    outliers = series.loc[(series < lower) | (series > upper)].index
    
    return outliers

def find_outliers_threshold(series, threshold=50):
    return series.loc[abs(series) > threshold].index


def update_layout(fig, height, width, title_text, title_y, title_x):
    fig.update_layout(
        height=height, 
        width=width,
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1
        ),
        title=dict(
            text=title_text,
            yanchor='bottom',
            y=title_y,
            xanchor='left',
            x=title_x
        )
    )
    
def get_target_periods(target_series: pd.Series):
    
    runs = get_runs(target_series)
    series_start_index = runs[:, 1].cumsum()
    runs = np.append(runs, series_start_index.reshape(len(series_start_index), 1), axis=1)

    target_end_indices = runs[runs[:, 0] == 1][:, 2] # не включительно
    target_start_indices = target_end_indices - runs[runs[:, 0] == 1][:, 1]

    start_n = len(target_start_indices)
    end_n = len(target_end_indices)

    target_periods = list(zip(target_start_indices, target_end_indices))
    
    return target_periods
    
def plot_features(features, starts, windows, factors_dict, ylevel_dict, rlevel_dict, model_name,
                  features_df, data_df, target_df, 
                  save=True, show=False, save_path=None):
    
    for start in starts:
        for window in windows:
            for feature in features:
                
                factor = factors_dict.get(feature)
                
                ylevel = ylevel_dict.get(feature)
                rlevel = rlevel_dict.get(feature)

                feature_df = pd.merge(
                    features_df[['report_date', feature]], 
                    data_df[['report_date', factor]], 
                    on='report_date'
                )
                feature_df = pd.merge(
                    feature_df, 
                    target_df, 
                    left_on='report_date', 
                    right_on='end_date'
                ).drop(columns=['end_date'])

                target_new = '_'.join(['target', f's{start}', f'w{window}'])
                date_new = target_new+'_date'

                fig = go.Figure().set_subplots(
                    rows=2, cols=1, 
                #     subplot_titles=[factor, feature], 
                    shared_xaxes=True,
                #     vertical_spacing=0.15,
                    vertical_spacing=0.01
                )

                # История фактора
                fig.add_trace(go.Scatter(
                    x=feature_df['report_date'],
                    y=feature_df[factor],
                    name=factor,
                    line_color='#FF7F0E'
                ),
                             row=1, col=1)
                # История фичи
                fig.add_trace(go.Scatter(
                    x=feature_df['report_date'],
                    y=feature_df[feature],
                    name=feature,
                    line_color='#636EFA'
                ),
                             row=2, col=1)
                
                # Желтый и красный уровни
                fig.add_hline(ylevel, row=2, col=1, line_color='#FFF59D')
                fig.add_hline(rlevel, row=2, col=1, line_color='#DC3912')
      

                # Добавляем периоды таргета
                start_dates_series = feature_df.loc[
                    feature_df[target_new].groupby(feature_df[date_new]).idxmax(), 
                    'report_date'
                ]
                max_index = len(feature_df) - 1
                for i, start_date in list(zip(start_dates_series.index, start_dates_series)):
                    x1_i = min(i + window - 1, max_index)
                    fig.add_vrect(
                        x0=start_date, 
                        x1=feature_df.iloc[x1_i]['report_date'], 
                        fillcolor='gray', 
                        opacity=0.5,
                        line_width=0
                    )
                    
                # # Добавляем периоды таргета
                # start_dates_series = feature_df.loc[
                #     feature_df[target_new].groupby(feature_df[date_new]).idxmax(), 
                #     'report_date'
                # ]
                # max_index = len(feature_df) - 1
                # for i, start_date in list(zip(start_dates_series.index, start_dates_series)):
                #     x1_i = min(i + 4 - 1, max_index)
                #     fig.add_vrect(
                #         x0=start_date, 
                #         x1=feature_df.iloc[x1_i]['report_date'], 
                #         fillcolor='gray', 
                #         opacity=0.5,
                #         line_width=0
                #     )

                if save:
                    # Красивая легенда и название (для страницы)
                    height, width, title_y, title_x = save_params_dict.values()
                    update_layout(fig, height=height, width=width, title_text=model_name, title_y=title_y, title_x=title_x)
                    img_save_path = os.path.join(save_path, 'images', model_name)
                    os.makedirs(img_save_path, exist_ok=True)
                    fig.write_html(os.path.join(img_save_path, f's{start}_w{window}_'+feature.replace('*', '')+'.html'))

                if show:
                    # Красивая легенда и название (для консоли)
                    height, width, title_y, title_x = show_params_dict.values()
                    update_layout(fig, height=height, width=width, title_text=model_name, title_y=title_y, title_x=title_x)
                    fig.show()
                    
                    
def plot_factor_w_taget(df: pd.DataFrame, factor: str, main_datecol: str, models: list, window=4, img_save_path='', save=False):
    
    position_dict = dict(zip(models, [[0, 0], [1, 0], [0, 1], [1, 1]]))
    
    fig = go.Figure().set_subplots(
        rows=2, cols=2, 
        subplot_titles=models, 
    #     shared_xaxes=True,
        shared_yaxes=True,
        vertical_spacing=0.1,
        horizontal_spacing=0.02
    )

    fig.add_trace(go.Scatter(
        x=df[main_datecol],
        y=df[factor],
        name=factor,
        line_color='#FF7F0E', 
        showlegend=False
            ),
                 row='all', col='all')

    for model in models:

        target_name = '_'.join([model, 'model'])
        date_name = f'{target_name}_date'

        row, col = position_dict.get(model)

        # Добавляем периоды таргета
        start_dates_series = df.loc[
            df[target_name].groupby(df[date_name]).idxmax(), 
            main_datecol
        ]
        max_index = len(df) - 1
        for i, start_date in list(zip(start_dates_series.index, start_dates_series)):
            x1_i = min(i + window - 1, max_index)
            fig.add_vrect(
                x0=start_date, 
                x1=df.iloc[x1_i][main_datecol], 
                fillcolor='gray', 
                opacity=0.5,
                line_width=0,
                row=row, 
                col=col
            )

    if save:
        # Красивая легенда и название (для страницы)
        height, width, title_y, title_x = save_params_dict.values()
        update_layout(fig, height=height, width=width, title_text=factor, title_y=title_y, title_x=title_x)
        os.makedirs(img_save_path, exist_ok=True)
        fig.write_html(os.path.join(img_save_path, factor+'.html'))

    height, width, title_y, title_x = show_params_dict.values()
    update_layout(fig, height=height, width=width, title_text=factor, title_y=title_y, title_x=title_x)
    fig.show()
    
    
def plot_features_no_outliers(features, start, window, factors_dict, ylevel_dict, rlevel_dict, model_name,
                  features_df, data_df,
                  save=True, show=False, img_save_path=None):
    
    for feature in features:

        factor = factors_dict.get(feature)

        ylevel = ylevel_dict.get(feature)
        rlevel = rlevel_dict.get(feature)

        feature_df = pd.merge(
            features_df[['report_date', feature]], 
            data_df[['report_date', factor]], 
            on='report_date'
        )
        feature_df = pd.merge(
            feature_df, 
            target_df, 
            left_on='report_date', 
            right_on='end_date'
        ).drop(columns=['end_date'])

        target_new = '_'.join(['target', f's{start}', f'w{window}'])
        date_new = target_new+'_date'
        
        outliers = find_outliers_threshold(feature_df[feature], threshold=50)
        outliers_df = feature_df.iloc[outliers]
        feature_df = feature_df.drop(outliers, axis=0)

        fig = go.Figure().set_subplots(
            rows=2, cols=1, 
        #     subplot_titles=[factor, feature], 
            shared_xaxes=True,
        #     vertical_spacing=0.15,
            vertical_spacing=0.01
        )

        # История фактора
        fig.add_trace(go.Scatter(
            x=feature_df['report_date'],
            y=feature_df[factor],
            name=factor,
            line_color='#FF7F0E'
        ),
                     row=1, col=1)
        # История фичи
        fig.add_trace(go.Scatter(
            x=feature_df['report_date'],
            y=feature_df[feature],
            name=feature,
            line_color='#636EFA'
        ),
                     row=2, col=1)
        
        # Выбросы
        for outlier_index in outliers:
            outlier_slice = outliers_df.loc[outlier_index]
            fig.add_vline(
                outlier_slice['report_date'].timestamp() * 1000, 
                annotation_text=f'{outlier_slice[feature]/1_000_000_000:.0f}B',
                annotation_position='top right',
                line_dash = 'dash',
                row=2, col=1 
            )

        # Желтый и красный уровни
        fig.add_hline(ylevel, row=2, col=1, line_color='#FFF59D')
        fig.add_hline(rlevel, row=2, col=1, line_color='#DC3912')

        # Добавляем периоды таргета
        start_dates_series = feature_df.loc[
            feature_df[target_new].groupby(feature_df[date_new]).idxmax(), 
            'report_date'
        ]
        for i, start_date in list(zip(start_dates_series.index, start_dates_series)):
            x1_i = i + window - 1
            fig.add_vrect(
                x0=start_date, 
                x1=feature_df.iloc[x1_i]['report_date'], 
                fillcolor='gray', 
                opacity=0.5,
                line_width=0
            )

        if save:
            # Красивая легенда и название (для страницы)
            height, width, title_y, title_x = save_params_dict.values()
            update_layout(fig, height=height, width=width, title_text=model_name, title_y=title_y, title_x=title_x)
            os.makedirs(img_save_path, exist_ok=True)
            fig.write_html(os.path.join(img_save_path, f's{start}_w{window}_'+feature.replace('*', '')+'.html'))

        if show:
            # Красивая легенда и название (для консоли)
            height, width, title_y, title_x = show_params_dict.values()
            update_layout(fig, height=height, width=width, title_text=model_name, title_y=title_y, title_x=title_x)
            fig.show()
            
def plot_factors_with_features(
    factors: list,
    features_types: dict,
    factors_df: pd.DataFrame,
    add_windows = False,
    features_levels: dict = None,
    features_directions: dict = None,
    title_text = None,
    show = True,
    save = False, 
    save_path = '',
    pct_name = 'picture1',
    verbose = False,
):
    
    factors_colors = ['#EB663B', 'purple', '#E377C2', '#00B5F7', '#FECB52']
    features_colors = ['#3366CC', 'green', '#B82E2E', '#8C564B', '#9467BD', '#17BECF']

    fig = go.Figure().set_subplots(
        rows=2, cols=1, 
        shared_xaxes=True,
        vertical_spacing=0.01
    )

    j=0
    for i, factor in enumerate(factors):

        factors_df_slice = factors_df.loc[(factors_df['factor'] == factor)].sort_values('report_date')

        # История фактора
        fig.add_trace(go.Scatter(
            x=factors_df_slice['report_date'],
            y=factors_df_slice['factor_hist'],
            name=factor,
            line_color=factors_colors[i]
        ),
                      row=1, col=1)


        for feature_type in features_types.get(factor):

            feature_type_slice = factors_df_slice.loc[(factors_df_slice['feature_type'] == feature_type)]
            
            feature_title = f'{factor} {feature_type}'
            # Добавим направление
            if features_directions is not None:
                direction = features_directions.get(factor).get(feature_type)
                feature_title += f' ({direction})'

            # История фичи
            fig.add_trace(go.Scatter(
                x=feature_type_slice['report_date'],
                y=feature_type_slice['feature_hist'],
                name=feature_title,
                line_color=features_colors[j]
            ),
                         row=2, col=1)
            
            # Уровень фичи
            if features_levels is not None:
                rlevel = features_levels.get(factor).get(feature_type)
                fig.add_hline(
                    rlevel, 
                    row=2, col=1, 
                    line_color=features_colors[j], 
                    line=dict(dash='dash')
                )

            j+=1
            
        # Можно добавить окна горения фактора
        if add_windows:
            assert 'Signal' in factors_df_slice.columns
            
            df_for_windows = factors_df_slice.drop_duplicates(subset=['report_date', 'factor'], ignore_index=True)
            signal_windows = get_target_periods(df_for_windows['Signal'])
            
            for start_idx, end_idx in signal_windows:
                
                start_date = df_for_windows.iloc[int(start_idx)]['report_date']
                end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']
                
                fig.add_vrect(
                    x0=start_date, 
                    x1=end_date, 
                    fillcolor=factors_colors[i], 
                    opacity=0.3,
                    line_width=0,
                    row=1, col=1
                )


    # для таргета сгодится любой фактор-фича
    df_for_target = feature_type_slice.reset_index(drop=True)
    target_periods = get_target_periods(df_for_target['target'])

    for start_idx, end_idx in target_periods:

        start_date = df_for_target.iloc[int(start_idx)]['report_date']
        end_date = df_for_target.iloc[int(end_idx) - 1]['report_date']
        
        if verbose:
            logging.info("{} - {}".format(start_date.date(), end_date.date()))

        fig.add_vrect(
            x0=start_date, 
            x1=end_date, 
            fillcolor='gray', 
            opacity=0.5,
            line_width=0
        )

        
    if save:
        # Красивая легенда и название (для страницы)
        height, width, title_y, title_x = save_params_dict.values()
        update_layout(fig, height=height, width=width, title_text=title_text, title_y=0.93, title_x=title_x)
        
        os.makedirs(save_path, exist_ok=True)
        fig.write_html(os.path.join(save_path, pct_name.replace('*', '')+'.html'))

    if show:
        # Красивая легенда и название (для консоли)
        update_layout(
            fig, 
            height=show_params_dict['height'], 
            width=show_params_dict['width'], 
            title_text=title_text, 
            title_y=0.92, 
            title_x=0.08
        )
        fig.show()
        
        
def plot_factors_with_features_v1(
    factors: list,
    factors_df: pd.DataFrame,
    target_df: pd.DataFrame,
    features_types: dict = None,
    add_windows = False,
    features_levels: dict = None,
    features_directions: dict = None,
    title_text = None,
    show = True,
    save = False, 
    save_path = '',
    pct_name = 'picture1',
    verbose = False,
):
    
    assert all([col in factors_df.columns for col in ['report_date', 'factor', 'factor_hist']])
    
    factors_colors = ['#EB663B', 'purple', '#E377C2', '#00B5F7', '#FECB52']
    features_colors = ['#3366CC', 'green', '#B82E2E', '#8C564B', '#9467BD', '#17BECF']

    fig = go.Figure().set_subplots(
        rows=2, cols=1, 
        shared_xaxes=True,
        vertical_spacing=0.01
    )

    j=0
    for i, factor in enumerate(factors):

        factors_df_slice = factors_df.loc[(factors_df['factor'] == factor)].sort_values('report_date')

        # История фактора
        fig.add_trace(go.Scatter(
            x=factors_df_slice['report_date'],
            y=factors_df_slice['factor_hist'],
            name=factor,
            line_color=factors_colors[i]
        ),
                      row=1, col=1)

        if features_types is not None:
            
            assert all([col in factors_df_slice.columns for col in ['feature_type', 'feature_hist']])
            
            for feature_type in features_types.get(factor):

                feature_type_slice = factors_df_slice.loc[(factors_df_slice['feature_type'] == feature_type)]

                feature_title = f'{factor} {feature_type}'
                # Добавим направление
                if features_directions is not None:
                    direction = features_directions.get(factor).get(feature_type)
                    feature_title += f' ({direction})'

                # История фичи
                fig.add_trace(go.Scatter(
                    x=feature_type_slice['report_date'],
                    y=feature_type_slice['feature_hist'],
                    name=feature_title,
                    line_color=features_colors[j]
                ),
                             row=2, col=1)

                # Уровень фичи
                if features_levels is not None:
                    rlevel = features_levels.get(factor).get(feature_type)
                    fig.add_hline(
                        rlevel, 
                        row=2, col=1, 
                        line_color=features_colors[j], 
                        line=dict(dash='dash')
                    )

                j+=1
            
        # Можно добавить окна горения фактора
        if add_windows:
            assert 'Signal' in factors_df_slice.columns
            
            df_for_windows = factors_df_slice.drop_duplicates(subset=['report_date', 'factor'], ignore_index=True)
            signal_windows = get_target_periods(df_for_windows['Signal'])
            
            for start_idx, end_idx in signal_windows:
                
                start_date = df_for_windows.iloc[int(start_idx)]['report_date']
                end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']
                
                fig.add_vrect(
                    x0=start_date, 
                    x1=end_date, 
                    fillcolor=factors_colors[i], 
                    opacity=0.3,
                    line_width=0,
                    row=1, col=1
                )

    # Старая логика ломалась, если данные по фактору были неполные; так безопаснее, но надо передавать target_df
    df_for_target = target_df.loc[
        (target_df['end_date'] >= factors_df['report_date'].min()) & (target_df['end_date'] <= factors_df['report_date'].max())
    ].reset_index(drop=True)
    target_periods = get_target_periods(df_for_target['target'])

    for start_idx, end_idx in target_periods:

        start_date = df_for_target.iloc[int(start_idx)]['end_date']
        end_date = df_for_target.iloc[int(end_idx) - 1]['end_date']
        
        if verbose:
            logging.info("{} - {}".format(start_date.date(), end_date.date()))

        fig.add_vrect(
            x0=start_date, 
            x1=end_date, 
            fillcolor='gray', 
            opacity=0.5,
            line_width=0
        )

        
    if save:
        # Красивая легенда и название (для страницы)
        height, width, title_y, title_x = save_params_dict.values()
        update_layout(fig, height=height, width=width, title_text=title_text, title_y=0.93, title_x=title_x)
        
        os.makedirs(save_path, exist_ok=True)
        fig.write_html(os.path.join(save_path, pct_name.replace('*', '')+'.html'))

    if show:
        # Красивая легенда и название (для консоли)
        update_layout(
            fig, 
            height=show_params_dict['height'], 
            width=show_params_dict['width'], 
            title_text=title_text, 
            title_y=0.92, 
            title_x=0.08
        )
        fig.show()
        
def plt_add_target_windows(fig, df_for_target, color='gray', opacity=0.5, verbose=False) -> None:

    assert all([col in df_for_target.columns for col in ['target', 'end_date']])
    
    target_periods = get_target_periods(df_for_target['target'])
    for start_idx, end_idx in target_periods:

        start_date = df_for_target.iloc[int(start_idx)]['end_date']
        end_date = df_for_target.iloc[int(end_idx) - 1]['end_date']

        if verbose:
            logging.info("{} - {}".format(start_date.date(), end_date.date()))

        fig.add_vrect(
            x0=start_date, 
            x1=end_date, 
            fillcolor=color, 
            opacity=opacity,
            line_width=0,
            layer="below"
        )
        
def plot_model_ewi(
    model_df: pd.DataFrame,
    target_df: pd.DataFrame,
    rlevel: float,
    add_windows = False,
    title_text = None,
    show = True,
    save = False, 
    save_path = '',
    pct_name = 'picture1',
    verbose = False
) -> None:

    factors_colors = ['purple', '#E377C2', '#00B5F7', '#FECB52']
    
    model_df_slice = model_df.sort_values('report_date').copy()

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x = model_df_slice['report_date'],
        y = model_df_slice['ewi'],
        line_color=factors_colors[0]
    ))


    fig.add_hline(
        rlevel, 
        line_color=factors_colors[0], 
        line=dict(dash='dash')
    )

    if add_windows:
        assert 'signal' in model_df_slice.columns

        df_for_windows = model_df_slice.reset_index(drop=True)
        signal_windows = get_target_periods(df_for_windows['signal'])

        for start_idx, end_idx in signal_windows:

            start_date = df_for_windows.iloc[int(start_idx)]['report_date']
            end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

            fig.add_vrect(
                x0=start_date, 
                x1=end_date, 
                fillcolor=factors_colors[1], 
                opacity=0.3,
                line_width=0,
                row=1, col=1
            )


    C1 = (target_df['end_date'] >= model_df_slice['report_date'].min())
    C2 = (target_df['end_date'] <= model_df_slice['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)

    plt_add_target_windows(fig, df_for_target, verbose=verbose)

    if save:
        # Красивая легенда и название (для страницы)
        height, width, title_y, title_x = save_params_dict.values()
        update_layout(fig, height=height, width=width, title_text=title_text, title_y=0.93, title_x=title_x)

        os.makedirs(save_path, exist_ok=True)
        fig.write_html(os.path.join(save_path, pct_name.replace('*', '')+'.html'))

    if show:
        # Красивая легенда и название (для консоли)
        update_layout(
            fig, 
            height=show_params_dict['height'], 
            width=show_params_dict['width'], 
            title_text=title_text, 
            title_y=0.92, 
            title_x=0.08
        )
        fig.show()
        
def plot_block_ewi(
    block_df: pd.DataFrame,
    target_df: pd.DataFrame,
    rlevel: float,
    add_windows = False,
    title_text = None,
    show = True,
    save = False, 
    save_path = '',
    pct_name = 'picture1',
    verbose = False
) -> None:

    factors_colors = ['purple', '#E377C2', '#00B5F7', '#FECB52']
    
    block_df_slice = block_df.sort_values('report_date').copy()

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x = block_df_slice['report_date'],
        y = block_df_slice['ewi'],
        line_color=factors_colors[0]
    ))


    fig.add_hline(
        rlevel, 
        line_color=factors_colors[0], 
        line=dict(dash='dash')
    )

    if add_windows:
        assert 'signal' in block_df_slice.columns

        df_for_windows = block_df_slice.reset_index(drop=True)
        signal_windows = get_target_periods(df_for_windows['signal'])

        for start_idx, end_idx in signal_windows:

            start_date = df_for_windows.iloc[int(start_idx)]['report_date']
            end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

            fig.add_vrect(
                x0=start_date, 
                x1=end_date, 
                fillcolor=factors_colors[1], 
                opacity=0.3,
                line_width=0,
                row=1, col=1
            )


    C1 = (target_df['end_date'] >= block_df_slice['report_date'].min())
    C2 = (target_df['end_date'] <= block_df_slice['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)

    plt_add_target_windows(fig, df_for_target, verbose=verbose)

    if save:
        # Красивая легенда и название (для страницы)
        height, width, title_y, title_x = save_params_dict.values()
        update_layout(fig, height=height, width=width, title_text=title_text, title_y=0.93, title_x=title_x)

        os.makedirs(save_path, exist_ok=True)
        fig.write_html(os.path.join(save_path, pct_name.replace('*', '')+'.html'))

    if show:
        # Красивая легенда и название (для консоли)
        update_layout(
            fig, 
            height=show_params_dict['height'], 
            width=show_params_dict['width'], 
            title_text=title_text, 
            title_y=0.92, 
            title_x=0.08
        )
        fig.show()