#!/usr/bin/env python
# coding: utf-8

import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta, FR
import os
import logging

def get_target_paths():
    target_dir = r'X:\102_FTP_IB_Unit\01_FTP_Unit\11_ALM projects\17_Триггеры по БСМ\02_Триггер ЕТС RUB\02_Таргеты (изменения ЕТС)'

    # Input
    excel_target_path = os.path.join(target_dir, 'Таргет.xlsx')
    # Output
    csv_target_path = os.path.join(target_dir, 'Target.csv')

    return excel_target_path, csv_target_path

def update_target(excel_target_path, csv_target_path='Target.csv', last_date='excel', save=True, verbose=True):
    
    assert last_date in ['excel', 'today']

    # Загружаем файл
    target_df = pd.read_excel(excel_target_path, skiprows=2)

    start_date = '2016-01-01'
    # Последняя дата из excel
    end_date = target_df['Date'].iloc[-1].date().strftime('%Y-%m-%d')
    
    if verbose:
        logging.info('Последняя дата в excel: ', end_date)
    
    if last_date == 'today':
        end_date = datetime.today().strftime('%Y-%m-%d')

    # Даты для таргета
    target_dates_df = pd.DataFrame()
    target_dates_df['start_date'] = pd.date_range(start=start_date, end=datetime.today(), freq='7D') 
    target_dates_df['end_date'] = target_dates_df['start_date'].shift(-1).fillna(end_date)
    # Если дата начала равна дате окончания, дропнем
    target_dates_df = target_dates_df.loc[target_dates_df['start_date'] != target_dates_df['end_date']]

    target_df_aux = pd.DataFrame()
    # Делаем данные на каждый день
    target_df_aux['Date'] = pd.date_range(start=start_date, end=end_date, freq='D')
    # Ищем дату следующей пятницы
    target_df_aux['week_friday'] = target_df_aux['Date'].apply(lambda x: x + relativedelta(weekday=FR(1)))
    target_df_aux = target_df_aux.merge(
        target_df,
        on='Date', how='left'
    ).fillna(0)
    target_df_aux = target_df_aux.merge(target_dates_df, left_on='week_friday', right_on='end_date', how='left').ffill()
    
    # Явно указываем числовые столбцы
    numeric_columns = ['Unnamed: 10'] 
    # Преобразуем все числовые столбцы, игнорируя ошибки
    for col in numeric_columns:
        target_df_aux[col] = pd.to_numeric(target_df_aux[col], errors='coerce')    
    # Затем заполняем пропуски
    target_df_aux[numeric_columns] = target_df_aux[numeric_columns].fillna(0)

    # Если было больше одного изменения за неделю, суммируем
    target_df_aux = target_df_aux.drop(columns=['Date', 'week_friday']).groupby(['start_date', 'end_date'], as_index=False).sum()

    # Make targets binary again
    TARGET_COLS = ['short_down_target', 'short_up_target', 'long_down_target', 'long_up_target']
    target_df_aux[TARGET_COLS] = target_df_aux[TARGET_COLS].clip(upper=1)

    if save:
        target_df_aux.to_csv(csv_target_path, index=False)
    
    return target_df_aux

if __name__ == "__main__":
    excel_target_path, csv_target_path = get_target_paths()
    update_target(excel_target_path, csv_target_path)
    logging.info('Target.csv сформирован')