import os
from typing import Dict
import pandas as pd

from .validation_v2 import calc_stats, calc_model_metrics, calc_factors_metrics, create_mega_df, move_column
from .prepare_data_v2 import make_target, make_res_df, make_model_df
from .valsaver_v2 import save_factors_val, save_model_val


beta = 2
start = 1
window = 4


class ModelReport:
    pass


def make_model_report(total_dict: Dict[str, pd.DataFrame], save_path: str = '', save: bool = True) -> ModelReport:

    all_F_metrics_df = pd.DataFrame()
    all_F_events_df = pd.DataFrame()
    all_F_classification_df = pd.DataFrame()
    all_F_pred_dates_df = pd.DataFrame()
    all_F_pred_dates_df_gr = pd.DataFrame()

    F_info_df = pd.DataFrame()
    F_stats_df = pd.DataFrame()

    all_M_metrics_df = pd.DataFrame()
    all_M_events_df = pd.DataFrame()
    all_M_classification_df = pd.DataFrame()
    all_M_pred_dates_df = pd.DataFrame()
    all_M_pred_dates_df_gr = pd.DataFrame()

    M_stats_df = pd.DataFrame()

    targets_df = total_dict['targets']

    model_block = 'TOTAL'
    ALL_MODELS = total_dict['features']['model'].unique()

    for model in ALL_MODELS:

        # Рассовываем по фреймам
        df1 = total_dict['features'].loc[(total_dict['features']['model'] == model) & (total_dict['features']['block'] == model_block)]
        flag_df = total_dict['data_3_signals'].loc[(total_dict['data_3_signals']['model'] == model) & (total_dict['data_3_signals']['block'] == model_block)]
        ewi_df = total_dict['data_ewi'].loc[(total_dict['data_ewi']['model'] == model) & (total_dict['data_ewi']['block'] == model_block)]

        # Создание итоговых фреймов
        target_df = make_target(targets_df, model)
        res_df = make_res_df(target_df, flag_df)
        model_df = make_model_df(ewi_df, target_df)

        # Создание info_df
        info_df = df1.sort_values(
            'coefs', ascending=False, ignore_index=True
        )[
            ['segment_name', 'coefs', 'segment', 'model']
        ].rename(columns={'segment': 'block'})
        # Табличка со статистиками по блокам
        stats_df = calc_stats(res_df, model=model, input_factor_colname='factor', output_factor_colname='block')
        # Табличка со статистиками по модели в целом
        model_stats_df = calc_stats(
            model_df, model=model, factors=['total'], data_colname='signal', 
            input_factor_colname=None, output_factor_colname='target'
        )

        # Метрики по модели
        model_metrics_df, model_events_df, model_classification_df, model_pred_dates_df, model_pred_dates_df_gr \
        = calc_model_metrics(model_df, model)

        # Метрики по блокам
        metrics_df, events_df, mini_classification_df, classification_df, pred_dates_df, pred_dates_df_gr \
        = calc_factors_metrics(res_df, model, output_factor_colname='block')

        all_M_metrics_df = pd.concat([all_M_metrics_df, model_metrics_df])
        all_M_events_df = pd.concat([all_M_events_df, model_events_df])
        all_M_classification_df = pd.concat([all_M_classification_df, model_classification_df])
        all_M_pred_dates_df = pd.concat([all_M_pred_dates_df, model_pred_dates_df])
        all_M_pred_dates_df_gr = pd.concat([all_M_pred_dates_df_gr, model_pred_dates_df_gr])
        
        M_stats_df = pd.concat([M_stats_df, model_stats_df])

        F_info_df = pd.concat([F_info_df, info_df])
        F_stats_df = pd.concat([F_stats_df, stats_df])

        all_F_metrics_df = pd.concat([all_F_metrics_df, metrics_df])
        all_F_events_df = pd.concat([all_F_events_df, events_df])
        all_F_classification_df = pd.concat([all_F_classification_df, classification_df])
        all_F_pred_dates_df = pd.concat([all_F_pred_dates_df, pred_dates_df])
        all_F_pred_dates_df_gr = pd.concat([all_F_pred_dates_df_gr, pred_dates_df_gr])
        
        
    F_mega_df = create_mega_df(F_info_df, F_stats_df, all_F_events_df, all_F_classification_df, merge_on=['block'])
    move_column(F_mega_df, colname='model', to_position=0)
    move_column(F_mega_df, colname='block', to_position=-1)


    model_report = ModelReport()
    model_report.F_info_df = F_info_df
    model_report.F_mega_df = F_mega_df


    if save:

        save_factors_val(
            save_path,
            stats_df=F_stats_df, 
            metrics_df=all_F_metrics_df, 
            events_df=all_F_events_df, 
            classification_df=all_F_classification_df, 
            pred_dates_df=all_F_pred_dates_df, 
            pred_dates_df_gr=all_F_pred_dates_df_gr, 
            F_mega_df=F_mega_df,
            filename='Blocks_summary.xlsx'
        )

        save_model_val(
            save_path=save_path, 
            model_stats_df=M_stats_df, 
            model_metrics_df=all_M_metrics_df, 
            model_events_df=all_M_events_df, 
            model_classification_df=all_M_classification_df, 
            model_pred_dates_df=all_M_pred_dates_df, 
            model_pred_dates_df_gr=all_M_pred_dates_df_gr,
            filename='Model_summary.xlsx'
        )

    return model_report

def make_factors_report(total_dict: Dict[str, pd.DataFrame], model_report: ModelReport, save_path: str = '', save: bool = True) -> None:

    all_F_metrics_df = pd.DataFrame()
    all_F_events_df = pd.DataFrame()
    all_F_mini_classification_df = pd.DataFrame()
    all_F_classification_df = pd.DataFrame()
    all_F_pred_dates_df = pd.DataFrame()
    all_F_pred_dates_df_gr = pd.DataFrame()

    F_info_df = pd.DataFrame()
    F_stats_df = pd.DataFrame()

    targets_df = total_dict['targets']
    blocks_info_df = model_report.F_info_df

    ALL_MODELS = total_dict['features']['model'].unique()

    for model in ALL_MODELS:
        
        MODEL_BLOCKS = total_dict['features'].loc[total_dict['features']['model'] == model, 'block'].unique()
        MODEL_BLOCKS = [block for block in MODEL_BLOCKS if block != 'TOTAL']

        for model_block in MODEL_BLOCKS:

            # Рассовываем по фреймам
            df1 = total_dict['features'].loc[(total_dict['features']['model'] == model) & (total_dict['features']['block'] == model_block)]
            flag_df = total_dict['data_3_signals'].loc[(total_dict['data_3_signals']['model'] == model) & (total_dict['data_3_signals']['block'] == model_block)]

            # Создание итоговых фреймов
            target_df = make_target(targets_df, model)
            res_df = make_res_df(target_df, flag_df)

            # Создание info_df
            info_df = df1.drop_duplicates(
                subset=['factor', 'coefs']
            ).sort_values(
                'coefs', ascending=False, ignore_index=True
            )[
                ['factor', 'coefs', 'directions', 'desc', 'segment', 'model']
            ].copy()
            info_df['block'] = model_block
            info_df = pd.merge(
                info_df, 
                blocks_info_df.rename(columns={
                    'block': 'segment',
                    'coefs': 'block_coef'
                }), 
                how='left', 
                on=['model', 'segment']
            )

            # Табличка со статистиками по блокам
            stats_df = calc_stats(
                res_df, model=model, block=model_block, input_factor_colname='factor', output_factor_colname='factor'
            )

            # Метрики по факторам
            metrics_df, events_df, mini_classification_df, classification_df, pred_dates_df, pred_dates_df_gr \
            = calc_factors_metrics(res_df, model, block=model_block, output_factor_colname='factor')

            F_info_df = pd.concat([F_info_df, info_df])
            F_stats_df = pd.concat([F_stats_df, stats_df])

            all_F_metrics_df = pd.concat([all_F_metrics_df, metrics_df])
            all_F_events_df = pd.concat([all_F_events_df, events_df])
            all_F_classification_df = pd.concat([all_F_classification_df, classification_df])
            all_F_pred_dates_df = pd.concat([all_F_pred_dates_df, pred_dates_df])
            all_F_pred_dates_df_gr = pd.concat([all_F_pred_dates_df_gr, pred_dates_df_gr])
            
    F_mega_df = create_mega_df(F_info_df, F_stats_df, all_F_events_df, all_F_classification_df, merge_on=['block', 'factor'])

    F_mega_df.sort_values(by=['model', 'block_coef', 'block', 'coefs', 'factor'], ascending=False, inplace=True)
    move_column(F_mega_df, colname='model', to_position=0)
    move_column(F_mega_df, colname='block', to_position=1)
    move_column(F_mega_df, colname='block_coef', to_position=2)
    move_column(F_mega_df, colname='factor', to_position=3)
    F_mega_df.drop(columns=['segment', 'segment_name'], inplace=True, errors='ignore')

    if save:

        save_factors_val(
            save_path,
            df1=F_info_df,
            stats_df=F_stats_df, 
            metrics_df=all_F_metrics_df, 
            events_df=all_F_events_df, 
            classification_df=all_F_classification_df, 
            pred_dates_df=all_F_pred_dates_df, 
            pred_dates_df_gr=all_F_pred_dates_df_gr, 
            F_mega_df=F_mega_df,
            filename='Factors_summary.xlsx'
        )


def make_reports(total_dict: Dict[str, pd.DataFrame], subfolder_path: str = '', save: bool = True) -> None:

    model_stats_path = os.path.join(subfolder_path, 'model_stats')
    stats_cond = not os.path.exists(model_stats_path) or len(os.listdir(model_stats_path)) == 0

    if stats_cond:
        model_report = make_model_report(total_dict=total_dict, save_path=model_stats_path, save=save)
        make_factors_report(total_dict=total_dict, model_report=model_report, save_path=model_stats_path, save=save)