#!/usr/bin/env python
# coding: utf-8

import numpy as np
import pandas as pd
import itertools


def move_column(df, colname, to_position):
    
    if to_position < 0:
        to_position = len(df.columns) + to_position
        
    df.insert(to_position, colname, df.pop(colname))
    
def make_target_window(target, start=1, window=4):
    
    target_new = 0
    
    b0 = start
    window_end = window + start - 1
    
    while b0 <= window_end:
        target_new += target.shift(-b0, fill_value=0)
        b0 += 1
        
    target_new = target_new.clip(upper=1)
    
    return target_new

def confusion_matrix(df, hist_target, model_target):
    
    assert hist_target in df.columns and model_target in df.columns
    
    positive = df.loc[df[hist_target] == 1]
    negative = df.loc[df[hist_target] == 0]

    TP = sum(positive[model_target] == 1)
    FP = sum(negative[model_target] == 1)
    TN = sum(negative[model_target] == 0)
    FN = sum(positive[model_target] == 0)
    
    return TP, FP, TN, FN

def TP_FN_dates(df, hist_target, model_target):
    
    assert hist_target in df.columns and model_target in df.columns
    
    TP_events = df.loc[(df[hist_target] == 1) & (df[model_target] == 1)].index
    FN_events = df.loc[(df[hist_target] == 1) & (df[model_target] == 0)].index

    return TP_events, FN_events

def calc_classification_metrics(TP, FP, FN, beta=1):
    
    try:
        precision = TP / (TP + FP)
    except ZeroDivisionError:
        precision = None
        
    try:
        recall = TP / (TP + FN)
    except ZeroDivisionError:
        recall = None
        
    f1 = calc_F_score(TP, FP, FN, beta=1)
    f_beta = calc_F_score(TP, FP, FN, beta=beta)
    
    return [precision, recall, f1, f_beta]

def calc_F_score(TP, FP, FN, beta=1):
    """
    if beta == 1, returns f1-score, else f_beta-score
    """
    
    try:
        f_beta = (1 + beta ** 2) * TP / ((1 + beta ** 2) * TP + FP + beta ** 2 * FN)
    except ZeroDivisionError:
        f_beta = None
    
    return f_beta

def calc_model_metrics(model_df, model, start=1, window=4, beta=2):
    
    # Максимальный сигнал за окно
    # Для start != 1 переделать
    model_df['signal_in_window'] = model_df['signal'].rolling(window=window, closed='left').max().fillna(0)

    # Разметка confusion matrix
    TP, FP, TN, FN = confusion_matrix(model_df, hist_target='target', model_target='signal')

    # Даты изменений ставок (угаданные и нет)
    TP_events, FN_events = TP_FN_dates(model_df, hist_target='event', model_target='signal_in_window')

    n_TP_events = len(TP_events)
    n_FN_events = len(FN_events)
    n_events = n_TP_events + n_FN_events

    ####################################################################################

    # Метрики качества классификации
    precision, recall, f1, f_beta = calc_classification_metrics(TP, FP, FN, beta=beta)

    # Метрики confusion matrix (TP, FP, TN, FN)
    metrics_data = np.array([TP, FP, TN, FN, len(model_df)])
    metrics_colnames = ['TP', 'FP', 'TN', 'FN', 'N']
    metrics_df = pd.DataFrame(
        data=metrics_data.reshape(1, metrics_data.shape[0]), 
        columns=metrics_colnames,
    #     index=[i]
    )
    metrics_df['model'] = model

    # Метрики TP, FN по событиям изменения ставок
    events_data = np.array([n_TP_events, n_FN_events, n_events])
    events_colnames = ['N_TP событий', 'N_FN событий', 'N событий']
    events_df = pd.DataFrame(
        data=events_data.reshape(1, events_data.shape[0]), 
        columns=events_colnames,
    #     index=[i] # порядковый номер в цикле
    )
    events_df['model'] = model

    # Метрики качества классификации (precision, recall, F1-score, F_beta)
    classification_df = pd.DataFrame(
        [[precision, recall, f1, f_beta]],
        columns=['precision', 'recall', 'F1', 'Fbeta'],
    #     index=[i] # порядковый номер в цикле
    )
    classification_df['model'] = model

    # Дата события и индикатор попадания (бинарный)
    pred_dates_df = pd.DataFrame(index=model_df.index)
    pred_dates_df.loc[TP_events, 'TP'] = 1
    pred_dates_df.loc[FN_events, 'FN'] = 1

    pred_dates_df.dropna(how='all', axis=0, inplace=True)
    pred_dates_df.fillna(0, inplace=True)
    pred_dates_df = pred_dates_df.reset_index().rename(columns={'report_date': 'date'})

    pred_dates_df['model'] = model

    # Метрики по годам
    year_metrics_dict = {}

    for year in model_df.year.unique():
        year_df = model_df.loc[model_df['year'] == year]

        TP, FP, _, FN = confusion_matrix(year_df, hist_target='target', model_target='signal')
        precision, recall, f1, f_beta = calc_classification_metrics(TP, FP, FN, beta=beta)

        metrics_array = [
            precision, recall, f1, f_beta
        ]

        year_metrics_dict[year] = metrics_array

    year_metrics_df = pd.DataFrame(year_metrics_dict).T.fillna(0)
    year_metrics_df.reset_index(inplace=True)
    year_metrics_df.columns = ['year', 'precision', 'recall', 'F1', 'Fbeta']

    # Свод по годам 
    pred_dates_df_gr = pred_dates_df.copy()
    pred_dates_df_gr['year'] = pred_dates_df_gr['date'].map(lambda x: x.year)
    pred_dates_df_gr = pred_dates_df_gr.merge(year_metrics_df, on='year', how='outer')
    pred_dates_df_gr.fillna(0, inplace=True)
    pred_dates_df.reset_index(drop=True, inplace=True)

    pred_dates_df_gr = pred_dates_df_gr.groupby(['year'], as_index=False).agg({
        'TP': 'sum',
        'FN': 'sum',
        'precision': 'mean',
        'recall': 'mean',
        'F1': 'mean',
        'Fbeta': 'mean'
    })
    pred_dates_df_gr['model'] = model

    return metrics_df, events_df, classification_df, pred_dates_df, pred_dates_df_gr

def calc_factors_metrics(res_df, model, block=None, start=1, window=4, beta=2, output_factor_colname='factor'):

    all_metrics_df = pd.DataFrame()
    all_events_df = pd.DataFrame()
    all_mini_classification_df = pd.DataFrame()
    all_classification_df = pd.DataFrame()
    all_pred_dates_df = pd.DataFrame()
    all_pred_dates_df_gr = pd.DataFrame()

    factors = res_df['factor'].unique()

    i=0
    for factor in factors:

        factor_df = res_df.loc[res_df['factor'] == factor].copy()

        # Максимальный сигнал за окно
        # Для start != 1 переделать
        factor_df['signal_in_window'] = factor_df['Signal'].rolling(window=window, closed='left').max().fillna(0)

        # Разметка confusion matrix
        TP, FP, TN, FN = confusion_matrix(factor_df, hist_target='target', model_target='Signal')

        # Даты изменений ставок (угаданные и нет)
        TP_events, FN_events = TP_FN_dates(factor_df, hist_target='event', model_target='signal_in_window')

        n_TP_events = len(TP_events)
        n_FN_events = len(FN_events)
        n_events = n_TP_events + n_FN_events

        # Метрики качества классификации
        precision, recall, f1, f_beta = calc_classification_metrics(TP, FP, FN, beta=beta)

        # Метрики confusion matrix (TP, FP, TN, FN)
        metrics_data = np.array([TP, FP, TN, FN, len(factor_df)])
        metrics_colnames = ['TP', 'FP', 'TN', 'FN', 'N']
        metrics_df = pd.DataFrame(
            data=metrics_data.reshape(1, metrics_data.shape[0]), 
            columns=metrics_colnames,
            index=[i] # порядковый номер в цикле
        )
        # ID
        metrics_df[output_factor_colname] = factor
        metrics_df['model'] = model
        if block is not None:
            metrics_df['block'] = block
        all_metrics_df = pd.concat([all_metrics_df, metrics_df])

        # Метрики TP, FN по событиям изменения ставок
        events_data = np.array([n_TP_events, n_FN_events, n_events])
        events_colnames = ['N_TP событий', 'N_FN событий', 'N событий']
        events_df = pd.DataFrame(
            data=events_data.reshape(1, events_data.shape[0]), 
            columns=events_colnames,
            index=[i] # порядковый номер в цикле
        )
        # ID
        events_df[output_factor_colname] = factor
        events_df['model'] = model
        if block is not None:
            events_df['block'] = block
        all_events_df = pd.concat([all_events_df, events_df])

        # Метрики качества классификации (precision, recall, F1-score, F_beta)
        classification_df = pd.DataFrame(
            [[precision, recall, f1, f_beta]],
            columns=['precision', 'recall', 'F1', 'Fbeta'],
            index=[i] # порядковый номер в цикле
        )
        # ID
        classification_df[output_factor_colname] = factor
        classification_df['model'] = model
        if block is not None:
            classification_df['block'] = block
        all_classification_df = pd.concat([all_classification_df, classification_df])

        # Дата события и индикатор попадания (бинарный)
        pred_dates_df = pd.DataFrame(index=factor_df.index)
        pred_dates_df.loc[TP_events, 'TP'] = 1
        pred_dates_df.loc[FN_events, 'FN'] = 1

        pred_dates_df.dropna(how='all', axis=0, inplace=True)
        pred_dates_df.fillna(0, inplace=True)
        pred_dates_df = pred_dates_df.reset_index().rename(columns={'report_date': 'date'})
        # ID
        pred_dates_df[output_factor_colname] = factor
        pred_dates_df['model'] = model
        if block is not None:
            pred_dates_df['block'] = block
        all_pred_dates_df = pd.concat([all_pred_dates_df, pred_dates_df])

        i+=1

    all_pred_dates_df.reset_index(drop=True, inplace=True)

    all_pred_dates_df_gr = all_pred_dates_df.copy()
    all_pred_dates_df_gr['year'] = all_pred_dates_df_gr['date'].dt.year
    all_pred_dates_df_gr = all_pred_dates_df_gr.groupby([output_factor_colname, 'year'], as_index=False).sum()
    all_pred_dates_df_gr['model'] = model
    if block is not None:
        all_pred_dates_df_gr['block'] = block
    
    return all_metrics_df, all_events_df, all_mini_classification_df, all_classification_df, all_pred_dates_df, \
            all_pred_dates_df_gr

def get_runs(l):
    return np.array([[x, sum(1 for x in r)] for x, r in itertools.groupby(l)])

def calc_stats(
    res_df, 
    model: str, 
    factors: list = None, 
    block: str = None,
    data_colname='Signal',
    input_factor_colname='factor',
    output_factor_colname='factor' 
):
    """
    Args:
        res_df (pd.DataFrame): фрейм с данными по сигналам
        model (str): тип модели
        factors (list): список факторов, по которому итерируемся (если None, итерируемся по значениям из input_factor_colname)
        data_colname (str): название столбца с сигналами 0/1
        input_factor_colname (str): название столбца с факторами для итерации. если None, итерации не происходит
        output_factor_colname (str): название столбца с факторами, по которым была итерация
    """

    if factors is None:
        factors = res_df[input_factor_colname].unique()

    stats = []
    for factor in factors:
        
        if input_factor_colname is not None:
            assert input_factor_colname in res_df.columns
            factor_df = res_df.loc[res_df[input_factor_colname] == factor]
        else:
            factor_df = res_df

        stats_share = (factor_df[data_colname].value_counts() / factor_df.shape[0]).values

        runs_01 = get_runs(factor_df[data_colname])
        run = runs_01[runs_01[:, 0] == 1][:, 1]
        if len(run) > 0:
            stats_run = np.array([np.min(run), np.median(run), np.max(run), len(run)])
        else:
            stats_run = np.zeros(4)

        stats.append(np.append(stats_share, stats_run))


    stats = pd.DataFrame(stats).fillna(0)
    stats.columns = [
        'Доля 0', 'Доля 1', 'Мин. длина серии', 'Медиан. длина серии', 'Макс. длина серии', 'Кол-во серий'
    ]
    
    stats[output_factor_colname] = factors
    stats['model'] = model
    if block is not None:
        stats['block'] = block
    
    return stats

def create_mega_df(F_info_df, F_stats_df, all_F_events_df, all_F_classification_df, merge_on:list=['block']):
    
    F_mega_df = pd.merge(
        F_info_df, 
        F_stats_df[['Доля 1', 'Макс. длина серии', 'model']+merge_on], 
        on=merge_on+['model']
    )

    F_mega_df = pd.merge(
        F_mega_df, 
        all_F_events_df, 
        on=merge_on+['model']
    )

    F_mega_df = pd.merge(
        F_mega_df, 
        all_F_classification_df, 
        on=merge_on+['model']
    )
    
    return F_mega_df