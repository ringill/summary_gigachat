#!/usr/bin/env python
# coding: utf-8

import os
import pandas as pd
import numpy as np
import logging

# for tqdm import tqdm
from tqdm.notebook import tqdm

from .validation_v2 import make_target_window


def load_data(data_path, model_name, sheet_name, add='', verbose=True):
    file = model_name+add+'.xlsx'
    model_dict = pd.read_excel(os.path.join(data_path, file), sheet_name=sheet_name)
    if verbose:
        logging.info(file)
    return model_dict

def load_model(
    data_path,
    model,
    sheets_list=['features', 'data_1_agg', 'data_2_modif'],
    blocks_list=['KFL','KUL','ALM','MARKET','SFL','DUL'], 
    model_add='KSmodel_v1',
    verbose=False
):
    
    model_name = '_'.join([model, model_add]) if model_add else model
    
    sheets_dfs = dict(zip(sheets_list, [pd.DataFrame() for _ in sheets_list]))
    for sheet in sheets_dfs:
        for model_block in blocks_list:
            block_sheet_df = load_data(
                data_path=data_path, model_name=model_name, add='_'+model_block,
                sheet_name=sheet, verbose=verbose
            )
            block_sheet_df['block'] = model_block
            
            sheet_df = sheets_dfs.get(sheet)
            sheet_df = pd.concat([sheet_df, block_sheet_df], ignore_index=True)
            sheets_dfs.update({sheet: sheet_df})
    
    return sheets_dfs

def load_models(
    data_path,
    models_list,
    sheets_list=['features', 'data_1_agg', 'data_2_modif'],
    blocks_list=['KFL','KUL','ALM','MARKET','SFL','DUL'], 
    model_add='KSmodel_v1',
    verbose=False,
    progressbar=True
):

    sheets_dfs = dict(zip(sheets_list, [pd.DataFrame() for _ in sheets_list]))
    
    if progressbar:
        progress_bar = tqdm(total=len(models_list) * len(sheets_list) * len(blocks_list))
    
    for sheet in sheets_dfs:
        for model in models_list:
            model_name = '_'.join([model, model_add]) if model_add else model
            for model_block in blocks_list:
  
                block_sheet_df = load_data(
                    data_path=data_path, model_name=model_name, add='_'+model_block,
                    sheet_name=sheet, verbose=verbose
                )
                block_sheet_df['model'] = model
                block_sheet_df['block'] = model_block

                sheet_df = sheets_dfs.get(sheet)
                sheet_df = pd.concat([sheet_df, block_sheet_df], ignore_index=True)
                sheets_dfs.update({sheet: sheet_df})
                
                if progressbar:
                    progress_bar.update(1)
          
    if progressbar:
        progress_bar.close()

    return sheets_dfs

def make_target(targets_df, model, start=1, window=4):
    
    target_df = targets_df[['end_date', model+'_target']].rename(columns={(model+'_target'): 'event'}).copy()
    target_df['target'] = make_target_window(target_df['event'], window=window, start=start)
    
    return target_df

def make_res_df(target_df, flag_df):
    
    res_df = pd.merge(flag_df, target_df, left_on='report_date', right_on='end_date').drop(columns=['end_date'])
    res_df.set_index('report_date', inplace=True)
    
    return res_df

def make_model_df(ewi_df, target_df):
    
    model_df = ewi_df.merge(target_df, left_on='report_date', right_on='end_date', how='inner').drop(columns='end_date')
    model_df.set_index('report_date', inplace=True)
    model_df['year'] = model_df.index.map(lambda x: x.year)
    
    model_df.drop(columns=['model'], inplace=True, errors='ignore')
    
    return model_df

def find_features_types(factors, factors_df):
    
    features_types = {}
    for factor in factors:
        features_types_p = np.sort(factors_df.loc[(factors_df['factor'] == factor), 'feature_type'].unique())
        features_types.update({factor: features_types_p})
        
    return features_types

def find_features_levels(factors, info_df):
    
    features_levels = {}
    for factor in factors:
        features_levels.update({factor: {}})
        factor_info = info_df.loc[info_df['factor'] == factor]
        for feature_type in np.sort(factor_info['sub_type'].unique()):
            threshold = factor_info.loc[factor_info['sub_type'] == feature_type, 'treshold_val'].values[0]
            features_levels[factor].update({feature_type: threshold})
            
    return features_levels

def find_features_directions(factors, info_df):
    
    features_directions = {}
    for factor in factors:
        features_directions.update({factor: {}})
        factor_info = info_df.loc[info_df['factor'] == factor]
        for feature_type in np.sort(factor_info['sub_type'].unique()):
            direction = factor_info.loc[factor_info['sub_type'] == feature_type, 'directions'].values[0]
            features_directions[factor].update({feature_type: direction})
            
    return features_directions