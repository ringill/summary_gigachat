#!/usr/bin/env python
# coding: utf-8

import os
# import sys

# sys.path.append('../')

from ..common.excelwriter import save_excel_sheet, excel_rewrite_table

    
def save_factors_val(
    save_path, 
    df1=None, 
    stats_df=None, 
    metrics_df=None, 
    events_df=None, 
    classification_df=None, 
    pred_dates_df=None, 
    pred_dates_df_gr=None, 
    F_mega_df=None,
    filename='Factors_summary.xlsx'
):
    
    os.makedirs(save_path, exist_ok=True)
    filepath = os.path.join(save_path, filename)

    if F_mega_df is not None:
        save_excel_sheet(F_mega_df, filepath, sheet_name='pivot', index=False)
    if df1 is not None:
        save_excel_sheet(df1, filepath, sheet_name='info', index=False)
    if stats_df is not None:
        save_excel_sheet(stats_df, filepath, sheet_name='stats', index=False)
    if metrics_df is not None:
        save_excel_sheet(metrics_df, filepath, sheet_name='metrics_by_window', index=False)
    if events_df is not None:
        save_excel_sheet(events_df, filepath, sheet_name='metrics_by_events', index=False)
    if classification_df is not None:
        save_excel_sheet(classification_df, filepath, sheet_name='scores', index=False)
    if pred_dates_df is not None:
        save_excel_sheet(pred_dates_df, filepath, sheet_name='metrics_by_dates', index=False)
    if pred_dates_df_gr is not None:
        save_excel_sheet(pred_dates_df_gr, filepath, sheet_name='metrics_by_years', index=False)
    

def save_model_val(
    save_path, 
    model_stats_df=None, 
    model_metrics_df=None, 
    model_events_df=None, 
    model_classification_df=None, 
    model_pred_dates_df=None, 
    model_pred_dates_df_gr=None,
    filename='Model_summary.xlsx'
):
    
    os.makedirs(save_path, exist_ok=True)
    filepath = os.path.join(save_path, filename)

    if model_stats_df is not None:
        save_excel_sheet(model_stats_df, filepath, sheet_name='model_stats', index=False)
    if model_metrics_df is not None:
        save_excel_sheet(model_metrics_df, filepath, sheet_name='metrics_by_window', index=False)
    if model_events_df is not None:
        save_excel_sheet(model_events_df, filepath, sheet_name='metrics_by_events', index=False)
    if model_classification_df is not None:
        save_excel_sheet(model_classification_df, filepath, sheet_name='scores', index=False)
    if model_pred_dates_df is not None:
        save_excel_sheet(model_pred_dates_df, filepath, sheet_name='metrics_by_dates', index=False)
    if model_pred_dates_df_gr is not None:
        save_excel_sheet(model_pred_dates_df_gr, filepath, sheet_name='metrics_by_years', index=False)

    
# def save_val_to_pivot(
#     pivot_path, 
#     df1, stats_df, metrics_df, events_df, mini_classification_df, classification_df, pred_dates_df, pred_dates_df_gr,
#     model_pred_dates_df_gr, targets_df
# ):

#     save_excel_sheet(df1, pivot_path, sheet_name='features_info', index=False)
#     save_excel_sheet(stats_df, pivot_path, sheet_name='features_stats', index=True)
#     save_excel_sheet(metrics_df, pivot_path, sheet_name='metrics_by_window', index=False)
#     save_excel_sheet(events_df, pivot_path, sheet_name='metrics_by_events', index=False)
#     save_excel_sheet(mini_classification_df, pivot_path, sheet_name='corrected_scores', index=False)
#     save_excel_sheet(classification_df, pivot_path, sheet_name='all_scores', index=False)
#     save_excel_sheet(pred_dates_df, pivot_path, sheet_name='metrics_by_dates', index=False)
#     save_excel_sheet(pred_dates_df, pivot_path, sheet_name='metrics_by_dates_2', index=False)
#     save_excel_sheet(pred_dates_df_gr, pivot_path, sheet_name='metrics_by_years', index=False)
#     save_excel_sheet(model_pred_dates_df_gr, pivot_path, sheet_name='model_metrics_by_year', index=False)
#     save_excel_sheet(targets_df, pivot_path, sheet_name='Таргет', index=False)

def save_val_to_pivot(
    pivot_path, 
    F_info_df, F_stats_df, all_F_metrics_df, all_F_events_df, all_F_mini_classification_df, all_F_classification_df, 
    all_F_pred_dates_df, all_F_pred_dates_df_gr,
    all_M_pred_dates_df_gr, all_M_pred_dates_df, targets_df
):

    excel_rewrite_table(F_info_df, pivot_path, 'features_info')
    excel_rewrite_table(F_stats_df, pivot_path, 'features_stats')
    excel_rewrite_table(all_F_metrics_df, pivot_path, 'metrics_by_window')
    excel_rewrite_table(all_F_events_df, pivot_path, 'metrics_by_events')
    excel_rewrite_table(all_F_mini_classification_df, pivot_path, 'corrected_scores')
    excel_rewrite_table(all_F_classification_df, pivot_path, 'all_scores')
    excel_rewrite_table(all_F_pred_dates_df, pivot_path, 'metrics_by_dates')
    excel_rewrite_table(all_F_pred_dates_df, pivot_path, 'metrics_by_dates (2)')
    excel_rewrite_table(all_F_pred_dates_df_gr, pivot_path, 'metrics_by_years')
    excel_rewrite_table(all_M_pred_dates_df_gr, pivot_path, 'model_metrics_by_year')
    excel_rewrite_table(all_M_pred_dates_df, pivot_path, 'model_metrics_by_dates')
    excel_rewrite_table(targets_df, pivot_path, 'Таргет')