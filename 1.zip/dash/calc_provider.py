# dash/calc_provider.py
import logging
import os
import time

from config import app_config
from data_preparation_Model_Analize import create_csv_files, load_data_init_format
from KP.Model_analysis.analyze_models import make_reports


def main_processing():
    """Функция создания аналитических отчетов"""
    logging.info('Начинаем создание аналитических отчетов')

    # Проверяем существование папки
    if not os.path.exists(app_config.default_version_folder):
        error_msg = f"Папка {app_config.default_version_folder} не существует"
        logging.error(error_msg)
        raise FileNotFoundError(error_msg)

    folders = os.listdir(app_config.default_version_folder)

    # Проверяем, что папка не пуста
    if not folders:
        error_msg = f"Папка {app_config.default_version_folder} пуста"
        logging.error(error_msg)
        raise ValueError(error_msg)

    for subfolder in folders:
        logging.info(f'Обработка папки: {subfolder}')
        subfolder_path = os.path.join(app_config.default_version_folder, subfolder)

        # Проверяем существование подпапки
        if not os.path.isdir(subfolder_path):
            logging.warning(f"Пропускаем {subfolder} - это не папка")
            continue

        total_dict = load_data_init_format(subfolder_path=subfolder_path, verbose=False)
        create_csv_files(total_dict=total_dict, subfolder_path=subfolder_path)
        make_reports(total_dict=total_dict, subfolder_path=subfolder_path)

        logging.info(f'Папка {subfolder} обработана')

    logging.info('Создание аналитических отчетов завершено')


def prepare_data():
    """Функция подготовки данных для модели"""
    logging.info("Запущена подготовка данных")
    logging.info("Загрузка данных...")
    time.sleep(2)
    logging.info("Обработка данных...")
    time.sleep(3)
    logging.info("Подготовка данных завершена")


def run_model():
    """Функция запуска модели"""
    logging.info("Запуск модели")
    logging.info("Инициализация модели...")
    time.sleep(2)
    logging.info("Запуск модели...")
    time.sleep(4)
    logging.info("Оценка результатов...")
    time.sleep(1)
    logging.info("Выполнение завершено")
