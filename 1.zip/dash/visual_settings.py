Color_ETC_Up = '#FF7F0E' #'rgb(25,192,0)'
Color_ETC_Down =  '#2CA02C' #'rgb(169,209,142)'

# Цвета уровней пробития
Color_Red_Level = 'rgba(200,30,0,0.4)'
Color_Yellow_Level = 'rgba(212,171,6,0.4)'
Color_Green_Level = 'rgba(27,161,0,0.4)'


Color_Red_Level = 'red'
Color_Yellow_Level = 'yellow'
# Color_Green_Level = '#63C132'

Color_Factor = '#0092FA'


level_desc = {  # 'Level_Red_2': 'Красный',
    'Level_Yellow_2': 'Жёлтый',
    'Level_Green': 'Зелёный',
    'Level_Yellow_1': 'Жёлтый',
    'Level_Red_1': 'Красный'
}
level_desc_num = {
    0:'Level_Yellow_2',
    1:'Level_Green',
    2:'Level_Yellow_1',
    3:'Level_Red_1'
}

reaction_desc = {'Breaking_Down_Down': ['Вниз️', 'Снижение всей ЕТС'],
                 'Breaking_Down_Up': ['Вниз', 'Поднятие всей ЕТС'],
                 'Breaking_Up_Down': ['Вверх', 'Снижение всей ЕТС'],
                 'Breaking_Up_Up': ['Вверх', 'Поднятие всей ЕТС'],

                 'Breaking_Down_Short_Down': ['Вниз', 'Снижение коротких ЕТС'],
                 'Breaking_Down_Short_Up': ['Вниз', 'Поднятие коротких ЕТС'],
                 'Breaking_Up_Short_Down': ['Вверх', 'Снижение коротких ЕТС'],
                 'Breaking_Up_Short_Up': ['Вверх', 'Поднятие коротких ЕТС'],

                 'Breaking_Down_Long_Down': ['Вниз', 'Снижение длинных ЕТС'],
                 'Breaking_Down_Long_Up': ['Вниз', 'Поднятие длинных ЕТС'],
                 'Breaking_Up_Long_Down': ['Вверх', 'Снижение длинных ЕТС'],
                 'Breaking_Up_Long_Up': ['Вверх', 'Поднятие длинных ЕТС']
                 }

# Задаём колонки отвечающие за реакцию
reaction_column = {'Down_Down': ['Breaking_Down_Down', 'Breaking_Down_Short_Down', 'Breaking_Down_Long_Down'],
                   'Down_Up': ['Breaking_Down_Up', 'Breaking_Down_Short_Up', 'Breaking_Down_Long_Up'],
                   'Up_Down': ['Breaking_Up_Down', 'Breaking_Up_Short_Down', 'Breaking_Up_Long_Down'],
                   'Up_Up': ['Breaking_Up_Up', 'Breaking_Up_Short_Up', 'Breaking_Up_Long_Up']}
# задаем текст
column_text = {'Down_Down': ['Вниз', 'Снижение ставок'],
               'Down_Up': ['Вниз', 'Повышение ставок'],
               'Up_Down': ['Вверх', 'Снижение ставок'],
               'Up_Up': ['Вверх', 'Повышение ставок']}

reaction_desc_num = {0:'Breaking_Down_Down',
                     1:'Breaking_Down_Up',
                     2:'Breaking_Up_Down',
                     3:'Breaking_Up_Up'}