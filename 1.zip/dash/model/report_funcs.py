import pandas as pd
from typing import Optional, Dict

from .model_funcs import get_dict_th


def make_factor_great_again(indicator, df):
    '''
    ok, нужна в return_list_features и return_list_data2modif и return_list_data3signals и 
    '''
    indicator = indicator[4:]
    if indicator[-4:] == '_abs':
        return str(indicator[:-4]) + '_ABS'
    elif indicator in df['feature'].unique():
        if 'volatility' in indicator:
            return str(df[df['feature']==indicator]['corresponding_factor'].values[0]) + '_NEW'
        elif 'delta' in indicator:
            if '_rolling_mean_' in indicator:
                return str(df[df['feature']==indicator]['corresponding_factor'].values[0]) + '_NEW'
            else:
                return str(df[df['feature']==indicator]['corresponding_factor'].values[0]) + '_NEW'
        elif 'logarithm' in indicator:
            return str(df[df['feature']==indicator]['corresponding_factor'].values[0]) + '_NEW'
    else:
        return str(indicator) + '_OLD'

def make_factor_great_again_v2(indicator: str, df: pd.DataFrame) -> str:
    '''
    ok, нужна в return_list_features и return_list_data2modif и return_list_data3signals и 
    '''
    
    new_feat_trigger_words = ['volatility', 'delta', 'logarithm']
    
    indicator = indicator.replace('IND_', '')
    
    if indicator.endswith('_abs'):
        factor_name = '_'.join([indicator[:-4], 'ABS'])
    elif any([word in indicator for word in new_feat_trigger_words]):
        factor_from_df = df.loc[df['feature']==indicator, 'corresponding_factor'].values[0]
        if isinstance(factor_from_df, float):
            # на самом деле, это проверка на nan типа float
            factor_name = '_'.join([indicator, 'OLD'])
        else:
            factor_name = '_'.join([factor_from_df, 'NEW'])
    else:
        factor_name = '_'.join([indicator, 'OLD'])
        
    return factor_name

def return_list_ewi_threshold(total_treshold, model, tresholds, total_flg=False, segment = 'kfl'):
    '''
    ok, функция нужна - лист 'ewi_threshold' 
    total_treshold - порог модели  [long_down, long_up, short_down, short_up] (model_tresholds[model])
    model - модель  [long_down, long_up, short_down, short_up]
    tresholds - пороги для сегментов(
    ******************)
    tresholds= {k: v for k, v in zip(list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'model_params.xlsx')['feature_name']), 
    list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'model_params.xlsx')['treshold']))}
    ******************)
    '''

    if total_flg:
        df_list_ewi_threshold= pd.DataFrame(columns={})
        df_list_ewi_threshold['ewi_labels'] = ['red']
        df_list_ewi_threshold['ewi_threshold_val'] = total_treshold
        df_list_ewi_threshold['model'] = model
    else:
        df_list_ewi_threshold= pd.DataFrame(columns={})
        df_list_ewi_threshold['ewi_labels'] = ['red']
        df_list_ewi_threshold['ewi_threshold_val'] = tresholds[str(segment)+'_total']
        df_list_ewi_threshold['model'] = model
    return df_list_ewi_threshold


def return_list_features(df_total_info, model, segment= 'kfl',segment_name = 'КФЛ', report_sfl=True):
    '''
    
    ok, функция нужна - лист 'features' для всех кроме сфл и тотал
    вызывается в функции return_list_features_sfl_new( она нужна для лист 'features' СФЛ)
    
    target_path - путь к пространству, где лежат файлы по моделям (target_path = '/home/jovyan/etc_system/ETC_system_v2025/etc_run/')
    datasets_path - путь к пространству с датасетами(входящие изменяемые параметры и мастер-файлы( '/home/jovyan/etc_system/ETC_system_v2025/etc run/datasets/')
    model - модель [long_down, long_up, short_down, short_up]
    block_data - файл со всеми пороговыми значениями и параметрами
    ********
    ready_blocks = ['kul', 'kfl', 'alm', 'dul', 'sfl', 'market']
    tot_dataset = pd.DataFrame()
    for selected_name in ready_blocks:
        block_data =  pd.read_excel(target_path + str(model) +'/'+'datasets_th_and_weight'+'/'+'tec_version_th_'+str(selected_name)+'.xlsx')
        tot_dataset = pd.concat([tot_dataset,block_data])
    block_data=tot_dataset.copy()  
    block_data['feature_name'] = ['IND_'+i for i in block_data['feature']]
    ********
    '''
    prob_info = df_total_info[~df_total_info['section'].isin(['sfl_model','total_model'])][['model','feature','prob']].copy()
    prob_info = prob_info[prob_info['model']==model][['feature','prob']]
    for t in prob_info.feature:
        prob_info.loc[prob_info.feature==t,'feature_name']='IND_'+str(t)
    if report_sfl:
        weight_dataset= df_total_info[(df_total_info.model == model)&(df_total_info['section'] == 'sfl_model')].copy()
        block_ind = weight_dataset.feature_name.unique()
        g = []
        for i in block_ind:
            if 'share_vfl' in i:
                g.append(i)
        block_ind = g
    else:
        bdf =  df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)][['feature_name','weight','section','subsection','feature','info']]
        bdf['section'] = segment
        weight_dataset = bdf.copy()
        block_ind = weight_dataset.feature_name.unique()
        
    threshold_up_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','nstd' )
    threshold_down_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','nstd' )
    
    threshold_up_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','reg' )
    threshold_down_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','reg' )

    threshold_up_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','new' )
    threshold_down_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','new' )

    std_features =  ['IND_'+i for i in list(threshold_up_std.keys()) + list(threshold_down_std.keys())]
    reg_features =  ['IND_'+i for i in list(threshold_up_reg.keys()) + list(threshold_down_reg.keys())]
    new_features =  ['IND_'+i for i in list(threshold_up_new.keys()) + list(threshold_down_new.keys())]

    # important_features_clean = pd.read_excel(datasets_path+ 'important_features_clean.xlsx')
    df_list_features = pd.DataFrame()
    for data in block_ind:
        vol_df_list_features = pd.DataFrame()
        if data in std_features:
            vol_df_list_features['feature'] = [data]
            vol_df_list_features['factor'] = make_factor_great_again_v2(data, df_total_info)
            vol_df_list_features['factor_origin'] = data[4:]
            vol_df_list_features['directions'] = prob_info[prob_info['feature_name'] == data].prob.values[0]
            if prob_info[prob_info['feature_name'] == data].prob.values[0] == 'up':
                vol_df_list_features['treshold_val'] = threshold_up_std[vol_df_list_features['factor_origin'].values[0]]
            else:
                vol_df_list_features['treshold_val'] = threshold_down_std[vol_df_list_features['factor_origin'].values[0]]
            vol_df_list_features['coefs'] = weight_dataset[weight_dataset['feature_name'] == data].weight.values[0]
            vol_df_list_features['desc'] = weight_dataset[weight_dataset['feature_name'] == data]['info'].values[0]
            vol_df_list_features['model'] = model
            vol_df_list_features['segment'] = str(segment) + '_total'
            vol_df_list_features['type'] = 'old'
            vol_df_list_features['sub_type'] = 'NSTD'
            vol_df_list_features['segment_name'] = segment_name

            df_list_features = pd.concat([df_list_features, vol_df_list_features])
        
        if data in reg_features:
            vol_df_list_features['feature'] = [data]
            vol_df_list_features['factor'] = make_factor_great_again_v2(data, df_total_info)
            vol_df_list_features['factor_origin'] = data[4:]

            vol_df_list_features['directions'] = prob_info[prob_info['feature_name'] == data].prob.values[0]
            if prob_info[prob_info['feature_name'] == data].prob.values[0] == 'up':
                vol_df_list_features['treshold_val'] = threshold_up_reg[vol_df_list_features['factor_origin'].values[0]]
            else:
                vol_df_list_features['treshold_val'] = threshold_down_reg[vol_df_list_features['factor_origin'].values[0]]
            vol_df_list_features['coefs'] = weight_dataset[weight_dataset['feature_name'] == data].weight.values[0]
            vol_df_list_features['desc'] = weight_dataset[weight_dataset['feature_name'] == data]['info'].values[0]
            vol_df_list_features['model'] = model
            vol_df_list_features['segment'] = str(segment) + '_total'
            vol_df_list_features['type'] = 'old'
            vol_df_list_features['sub_type'] = 'REG'
            vol_df_list_features['segment_name'] = segment_name

            df_list_features = pd.concat([df_list_features, vol_df_list_features])
            
        if data in new_features:
            vol_df_list_features['feature'] = [data]
            vol_df_list_features['factor'] = make_factor_great_again_v2(data, df_total_info)
            if '_abs' in data:
                vol_df_list_features['factor_origin'] = data[4:-4]
            else:
                for feat in df_total_info['feature'].unique():
                    if data[4:] == feat:
                        vol_df_list_features['factor_origin'] = df_total_info[df_total_info['feature']==feat]['corresponding_factor'].values[0]
            #vol_df_list_features['factor_origin'] = data[4:]
            vol_df_list_features['directions'] = prob_info[prob_info['feature_name'] == data].prob.values[0]
            if prob_info[prob_info['feature_name'] == data].prob.values[0] == 'up':
                vol_df_list_features['treshold_val'] = threshold_up_new[vol_df_list_features['feature'].values[0][4:]]
            else:
                vol_df_list_features['treshold_val'] = threshold_down_new[vol_df_list_features['feature'].values[0][4:]]
            vol_df_list_features['coefs'] = weight_dataset[weight_dataset['feature_name'] == data].weight.values[0]
            vol_df_list_features['desc'] = weight_dataset[weight_dataset['feature_name'] == data]['info'].values[0]
            vol_df_list_features['model'] = model
            vol_df_list_features['segment'] = str(segment) + '_total'  
            if data[-4:] == '_abs':
                vol_df_list_features['type'] = 'abs'
                vol_df_list_features['sub_type'] = 'ABS'
            else:
                vol_df_list_features['type'] = 'new'
                vol_df_list_features['sub_type'] = 'NEW'
            vol_df_list_features['segment_name'] = segment_name    
            
            df_list_features = pd.concat([df_list_features, vol_df_list_features])    
            
    return df_list_features


def return_list_result(df_ind_reg_work, model, tresholds, total_treshold, total_flg=False, segment='kfl'):
    '''
    ok, функция нужна - лист data_ewi
    
    df_ind_reg_work - сводный датафрейм с фичами и индикаторами фичей, блоков, общей модели
    model  - модель [long_down, long_up, short_down, short_up]
    tresholds - пороги для сегментов(
    ******************
    tresholds= {k: v for k, v in zip(list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'model_params.xlsx')['feature_name']), 
    list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'model_params.xlsx')['treshold']))}
    ******************)
    total_treshold - порог модели  [long_down, long_up, short_down, short_up] (model_tresholds[model])
    total_flg - True для TOTAL, для блоков False
    '''

    if total_flg:
        df_list_result = df_ind_reg_work[['DATE','total']].copy()
        df_list_result = df_list_result.rename(columns={'DATE':'report_date',
                                  'total':'ewi',
                                  })
        df_list_result['signal'] = 0
        df_list_result.loc[df_list_result['ewi'] >= total_treshold,'signal']=1
        
    else:    
        df_list_result = df_ind_reg_work[['DATE',str(segment)+'_total']].copy()
        df_list_result = df_list_result.rename(columns={'DATE':'report_date',
                                      str(segment)+'_total':'ewi',
                                      })
        df_list_result['signal'] = 0
        df_list_result.loc[df_list_result['ewi'] >= tresholds[str(segment)+'_total'],'signal']=1
    df_list_result['model'] = model
    return df_list_result


def return_list_features_res_mod(df_features_info_total, model):
    '''
    ok , функция нужна - лист features для total модели
    df_features_info_total - датафрейм (гп версии модели)
        --------------------------------------------------------------------
            feature_name	   weight	  info	        segment	  treshold
        0	IND_kul_total	    0.22	   КЮЛ	       kul_total	0.57
        1	IND_kfl_total	    0.15	   КФЛ	       kfl_total	0.54
        2	IND_sfl_total	    0.23	   CФЛ	       sfl_total	0.51
        3	IND_dul_total	    0.11	   ДЮЛ	       dul_total	0.60
        4	IND_alm_total	    0.19   Метрики ALM     alm_total	0.63
        5	IND_market_total	0.11	  Рынок  	  market_total	0.56
        --------------------------------------------------------------------
    
    '''
    df_list_features = pd.DataFrame()
    df_list_features['block'] = df_features_info_total['feature_name']
    df_list_features['directions'] = 'up'
    df_list_features['yellow_val'] = 0.01
    df_list_features['red_val'] = df_features_info_total['treshold']
    df_list_features['coefs'] = df_features_info_total['weight']
    df_list_features['segment'] = df_features_info_total['segment']
    df_list_features['model'] = model
    df_list_features['segment_name'] = df_features_info_total['info']

    return df_list_features

def return_list_features_res_mod_v2(df_features_info_total, model):
    '''
    ok , функция нужна - лист features для total модели
    df_features_info_total - датафрейм (гп версии модели)
        --------------------------------------------------------------------
            feature_name	   weight	  info	        segment	  treshold
        0	IND_kul_total	    0.22	   КЮЛ	       kul_total	0.57
        1	IND_kfl_total	    0.15	   КФЛ	       kfl_total	0.54
        2	IND_sfl_total	    0.23	   CФЛ	       sfl_total	0.51
        3	IND_dul_total	    0.11	   ДЮЛ	       dul_total	0.60
        4	IND_alm_total	    0.19   Метрики ALM     alm_total	0.63
        5	IND_market_total	0.11	  Рынок  	  market_total	0.56
        --------------------------------------------------------------------
    
    '''
    df_list_features = pd.DataFrame(
        columns=[
            'feature', 'factor', 'factor_origin', 'directions', 
            'treshold_val', 'coefs', 'desc', 'model', 'segment',
            'type', 'sub_type', 'segment_name'
        ]
    )
    df_list_features['feature'] = df_features_info_total['feature_name']
    df_list_features['factor'] = df_features_info_total['segment']
    df_list_features['factor_origin'] = df_features_info_total['segment']
    df_list_features['directions'] = 'up'
    df_list_features['treshold_val'] = df_features_info_total['treshold']
    df_list_features['coefs'] = df_features_info_total['weight']
    df_list_features['desc'] = df_features_info_total['info']
    df_list_features['model'] = model
    df_list_features['segment'] = df_features_info_total['segment']
    df_list_features['type'] = None
    df_list_features['sub_type'] = None
    df_list_features['segment_name'] = df_features_info_total['info']

    return df_list_features

def return_list_data2modif(segment,  model, df_total_info, df_wf, df_r, df_n):
    '''
    ok, функция нужна - лист data_2_modif
    segment - блок ['kfl', 'sfl', 'kul', 'dul', 'market', 'alm']
    target_path - путь к пространству, где лежат файлы по моделям (target_path = '/home/jovyan/etc_system/ETC_system_v2025/etc_run/')
    model - модель [long_down, long_up, short_down, short_up]
    df_wf - датафрейм, продкут расчета фичей регрессии, содержит ['DATE',data + '_LOESS','B_I_'+data]
    df_r - датафрейм, продкут расчета фичей nstd, содержит ['DATE','NSD_I_'+data]
    df_n - датафрейм, продкут расчета фичей New,содержит ['DATE', data]
    important_features_clean = один из мастер-файлов (important_features_clean = pd.read_excel(datasets_path+ 'important_features_clean.xlsx'), 
                    где datasets_path- путь к пространству с датасетами(входящие изменяемые параметры и мастер-файлы( '/home/jovyan/etc_system/ETC_system_v2025/etc run/datasets/') )

    block_data - файл со всеми пороговыми значениями и параметрами
    ********
    ready_blocks = ['kul', 'kfl', 'alm', 'dul', 'sfl', 'market']
    tot_dataset = pd.DataFrame()
    for selected_name in ready_blocks:
        block_data =  pd.read_excel(target_path + str(model) +'/'+'datasets_th_and_weight'+'/'+'tec_version_th_'+str(selected_name)+'.xlsx')
        tot_dataset = pd.concat([tot_dataset,block_data])
    block_data=tot_dataset.copy()  
    block_data['feature_name'] = ['IND_'+i for i in block_data['feature']]
    ********
    '''
    bdf = df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)].copy()
    bdf['section'] = segment
    weight_dataset = bdf.copy()
    block_ind = weight_dataset.feature_name.unique()
    df_list_data2modif = pd.DataFrame()

    
    threshold_up_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','nstd' )
    threshold_down_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','nstd' )
    
    threshold_up_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','reg' )
    threshold_down_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','reg' )

    threshold_up_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','new' )
    threshold_down_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','new' )

    std_features =  ['IND_'+i for i in list(threshold_up_std.keys()) + list(threshold_down_std.keys())]
    reg_features =  ['IND_'+i for i in list(threshold_up_reg.keys()) + list(threshold_down_reg.keys())]
    new_features =  ['IND_'+i for i in list(threshold_up_new.keys()) + list(threshold_down_new.keys())]
    new_ind = new_features
    for feat in block_ind:
                if feat in std_features: 
                    data = feat[4:]
                    vol_df_list_data2modif = df_r[['DATE','NSD_I_'+data]].copy()
                    vol_df_list_data2modif = vol_df_list_data2modif.rename(columns={'DATE':'report_date',
                                                                          'NSD_I_'+data:'Value'})
                    vol_df_list_data2modif['factor'] = make_factor_great_again_v2(feat,df_total_info)
                    vol_df_list_data2modif['feature_type'] = 'NSTD'
                    df_list_data2modif = pd.concat([df_list_data2modif,vol_df_list_data2modif])

                if feat in reg_features:
                    data = feat[4:]
                    vol_df_list_data2modif = df_wf[['DATE','B_I_'+data]].copy()
                    vol_df_list_data2modif = vol_df_list_data2modif.rename(columns={'DATE':'report_date',
                                                                          'B_I_'+data:'Value'})
                    vol_df_list_data2modif['factor'] = make_factor_great_again_v2(feat, df_total_info)
                    vol_df_list_data2modif['feature_type'] = 'REG'
                    df_list_data2modif = pd.concat([df_list_data2modif,vol_df_list_data2modif])

                if feat in new_ind:
                    factor = feat[4:]
                    data = feat[4:]
    
                    vol_df_list_data2modif = df_n[['DATE', data]].copy()
                    vol_df_list_data2modif = vol_df_list_data2modif.rename(columns={'DATE':'report_date',
                                                                          data:'Value'})
                    if data[-4:] == '_abs':
                        vol_df_list_data2modif['feature_type'] = 'ABS'
                        vol_df_list_data2modif['factor'] = make_factor_great_again_v2(feat,df_total_info)
        
                    else:
                        vol_df_list_data2modif['feature_type'] = 'NEW'
                        vol_df_list_data2modif['factor'] = make_factor_great_again_v2(feat, df_total_info)


                    df_list_data2modif = pd.concat([df_list_data2modif,vol_df_list_data2modif])

    df_list_data2modif = df_list_data2modif.sort_values(['report_date'])

    return df_list_data2modif

def return_list_data3signals(segment, model, df_total_info, flag_data, df_wf, df_r, df_n):
    '''
    ok, функция нужна - лист data_3_signals, data_4_signals_decomp
    segment - блок ['kfl', 'sfl', 'kul', 'dul', 'market', 'alm']
    target_path - путь к пространству, где лежат файлы по моделям (target_path = '/home/jovyan/etc_system/ETC_system_v2025/etc_run/')
    model - модель [long_down, long_up, short_down, short_up]
    df_wf - датафрейм, продкут расчета фичей регрессии, содержит ['DATE',data + '_LOESS','B_I_'+data]
    df_r - датафрейм, продкут расчета фичей nstd, содержит ['DATE','NSD_I_'+data]
    df_n - датафрейм, продкут расчета фичей New,содержит ['DATE', data]
    important_features_clean = один из мастер-файлов (important_features_clean = pd.read_excel(datasets_path+ 'important_features_clean.xlsx'), 
                    где datasets_path- путь к пространству с датасетами(входящие изменяемые параметры и мастер-файлы( '/home/jovyan/etc_system/ETC_system_v2025/etc run/datasets/') )

    block_data - файл со всеми пороговыми значениями и параметрами
    ********
    ready_blocks = ['kul', 'kfl', 'alm', 'dul', 'sfl', 'market']
    tot_dataset = pd.DataFrame()
    for selected_name in ready_blocks:
        block_data =  pd.read_excel(target_path + str(model) +'/'+'datasets_th_and_weight'+'/'+'tec_version_th_'+str(selected_name)+'.xlsx')
        tot_dataset = pd.concat([tot_dataset,block_data])
    block_data=tot_dataset.copy()  
    block_data['feature_name'] = ['IND_'+i for i in block_data['feature']]
    flag_data - название листа
    '''
    bdf = df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)][['feature_name','weight','section','subsection','feature','info']]
    bdf['section'] = segment
    weight_dataset = bdf.copy()
 
    block_ind = weight_dataset.feature_name.unique()
    df_list_data3signals = pd.DataFrame()

        
    threshold_up_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','nstd' )
    threshold_down_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','nstd' )
    
    threshold_up_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','reg' )
    threshold_down_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','reg' )

    threshold_up_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','new' )
    threshold_down_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','new' )

    std_features =  ['IND_'+i for i in list(threshold_up_std.keys()) + list(threshold_down_std.keys())]
    reg_features =  ['IND_'+i for i in list(threshold_up_reg.keys()) + list(threshold_down_reg.keys())]
    new_features =  ['IND_'+i for i in list(threshold_up_new.keys()) + list(threshold_down_new.keys())]
    new_ind = new_features
    
    for feat in block_ind:
                if feat in std_features: 
                    data = feat
                    vol_df_list_data3signals = df_r[['DATE',data]].copy()
                    vol_df_list_data3signals = vol_df_list_data3signals.rename(columns={'DATE':'report_date',
                                                                          data:'Signal'})
                    vol_df_list_data3signals['factor'] = make_factor_great_again_v2(feat, df_total_info)
                    vol_df_list_data3signals['feature_type'] = 'NSTD'
                    df_list_data3signals = pd.concat([df_list_data3signals,vol_df_list_data3signals])

                if feat in reg_features:
                    data = feat
                    vol_df_list_data3signals = df_wf[['DATE',data]].copy()
                    vol_df_list_data3signals = vol_df_list_data3signals.rename(columns={'DATE':'report_date',
                                                                          data:'Signal'})
                    vol_df_list_data3signals['factor'] = make_factor_great_again_v2(feat, df_total_info)
                    vol_df_list_data3signals['feature_type'] = 'REG'
                    df_list_data3signals = pd.concat([df_list_data3signals,vol_df_list_data3signals])

                if feat in new_ind:
                    factor = feat[4:]
                    data = feat
                    vol_df_list_data3signals = df_n[['DATE', data]].copy()
                    vol_df_list_data3signals = vol_df_list_data3signals.rename(columns={'DATE':'report_date',
                                                                          data:'Signal'})
                    if data[-4:] == '_abs':
                        vol_df_list_data3signals['feature_type'] = 'ABS'
                        vol_df_list_data3signals['factor'] = make_factor_great_again_v2(feat, df_total_info)
                    else:
                        vol_df_list_data3signals['feature_type'] = 'NEW'
                        vol_df_list_data3signals['factor'] =make_factor_great_again_v2(feat, df_total_info)


                    df_list_data3signals = pd.concat([df_list_data3signals,vol_df_list_data3signals])

    df_list_data3signals = df_list_data3signals.sort_values(['report_date'])

    if flag_data == 'data_3':
        df_list_data3signals['Signal'] = df_list_data3signals['Signal'].fillna(0)
        df_list_data3signals = df_list_data3signals.groupby(['report_date','factor']).agg({'Signal':'max'}).reset_index()
        df_list_data3signals = df_list_data3signals[['report_date','Signal','factor']]

    return df_list_data3signals


def return_list_features_sfl_new(df_total_info, model, df_features_info_total, names_dict_sfl ):
    '''
    ok, актуальная функция от Тимофея для листа features в СФЛ
    df_features_info_total - датафрейм (гп cфл в версии модели = all_about_sfl)
        --------------------------------------------------------------------
                segment	             treshold	feature_name	      weight	  info
            0	mass_total	            0.47	IND_mass_total	        0.06	ВФЛ - MASS
            1	sb1_total	            0.49	IND_sb1_total	        0.06	ВФЛ - SB1
            2	pb_total	            0.41	IND_pb_total	        0.19	ВФЛ - PB
            3	sbp_total	            0.34	IND_sbp_total	        0.16	ВФЛ - SBP
            4	current_term_total	    0.48	IND_current_term_total	0.15	ВФЛ - TOTAL_VOL
            5	uprav_total            	0.61	IND_uprav_total         0.13	ВФЛ - UPRAV
            6	sohran_popoln_total  	0.41	IND_sohran_popoln_total	0.19	ВФЛ - SOHRAN_POPOLN
            7	share_vfl	            0.05	IND_share_vfl	        0.06	ВФЛ - Доля рынка
        --------------------------------------------------------------------
    names_dict_sfl - словарь с неймингом сфл( names_dict_sfl = {k: v for k, v in zip(list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'sfl_info_th_w_featname.xlsx')['feature_name'])
       ------------------------------------------
        {'IND_mass_total': 'ВФЛ - MASS',
         'IND_sb1_total': 'ВФЛ - SB1',
         'IND_pb_total': 'ВФЛ - PB',
         'IND_sbp_total': 'ВФЛ - SBP',
         'IND_current_term_total': 'ВФЛ - TOTAL_VOL',
         'IND_uprav_total': 'ВФЛ - UPRAV',
         'IND_sohran_popoln_total': 'ВФЛ - SOHRAN_POPOLN',
         'IND_share_vfl': 'ВФЛ - Доля рынка'}
       ----------------------------------------
    list(pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'sfl_info_th_w_featname.xlsx')['info']))})
    model - модель [long_down, long_up, short_down, short_up]
    '''
    df_list_features = pd.DataFrame()
    df_features_info_total = df_features_info_total[df_features_info_total['segment']!='share_vfl']
    df_list_features['feature'] = df_features_info_total['feature_name']
    df_list_features['factor'] = df_features_info_total['segment']
    df_list_features['directions'] = 'up'
    df_list_features['treshold_val'] = df_features_info_total['treshold']
    df_list_features['coefs'] = df_features_info_total['weight']
    df_list_features['desc'] = df_list_features['feature'].map(lambda x: names_dict_sfl[x])
    df_list_features['segment'] = 'sfl_total'
    df_list_features['model'] = model
    df_list_features['type'] = 'agg'
    df_list_features['sub_type'] = 'AGG'
    df_list_features['segment_name'] = 'СФЛ'
    df_list_features_sfl = return_list_features(df_total_info = df_total_info, model = model, 
                                               segment= 'sfl',segment_name = 'СФЛ',
                                                report_sfl=True)
    df_list_features = pd.concat([df_list_features,df_list_features_sfl])
    df_list_features['factor_origin'] = df_list_features['factor']
    df_list_features.loc[df_list_features['feature'].str.contains('share_vfl'),'factor_origin'] = 'share_vfl'
    df_list_features.loc[df_list_features['feature'].str.contains('share_vfl'),'factor'] = 'share_vfl'
    
    # factor_origin = df_list_features[['factor_origin']]
    # df_list_features.drop(columns={'factor_origin'},inplace=True)
    # df_list_features.insert(2, 'factor_origin', factor_origin)

    return df_list_features[['feature','factor','factor_origin','directions','treshold_val','coefs','desc','model','segment','type','sub_type','segment_name']]


def return_list_data4signalsdecomp_sfl_new(flag_data, feat_list, df_total_info, df_n,df_r,df_wf, res, model):

    '''
    ok, актуальная функция от Тимофея для листов data_2_modif, data_3_signals, data_4_signals_decomp в СФЛ и total
    flag_data - [data_2','data_3','data_4'] - указывает на нужный лист
    feat_list - фичи СФЛ [list(all_about_sfl.feature_name)] или фичи тотал list(df_features_info_total.feature_name)
    *******************
    all_about_sfl =  pd.read_excel(target_path + str(model)+'/'+'datasets_th_and_weight'+'/'+'sfl_info_th_w_featname.xlsx')
    ********************
    block_data - файл со всеми пороговыми значениями и параметрами
    ********
    ready_blocks = ['kul', 'kfl', 'alm', 'dul', 'sfl', 'market']
    tot_dataset = pd.DataFrame()
    for selected_name in ready_blocks:
        block_data =  pd.read_excel(target_path + str(model) +'/'+'datasets_th_and_weight'+'/'+'tec_version_th_'+str(selected_name)+'.xlsx')
        tot_dataset = pd.concat([tot_dataset,block_data])
    block_data=tot_dataset.copy()  
    block_data['feature_name'] = ['IND_'+i for i in block_data['feature']]
    
    df_wf - датафрейм, продкут расчета фичей регрессии, содержит ['DATE',data + '_LOESS','B_I_'+data]
    df_r - датафрейм, продкут расчета фичей nstd, содержит ['DATE','NSD_I_'+data]
    df_n - датафрейм, продкут расчета фичей New,содержит ['DATE', data]
    
    res - датасет со всеми результатами модели (индикаторы, блоки, модель, еtc.)
    important_features_clean = один из мастер-файлов (important_features_clean = pd.read_excel(datasets_path+ 'important_features_clean.xlsx'), 
                    где datasets_path- путь к пространству с датасетами(входящие изменяемые параметры и мастер-файлы( '/home/jovyan/etc_system/ETC_system_v2025/etc run/datasets/') )
    '''
    segment = 'sfl'
    df_list_data3signals = pd.DataFrame()
    threshold_up_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','nstd' )
    threshold_down_std = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','nstd' )
    
    threshold_up_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','reg' )
    threshold_down_reg = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','reg' )

    threshold_up_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'up','new' )
    threshold_down_new = get_dict_th(df_total_info[(df_total_info['model']==model)&(df_total_info['section']==segment)], 'down','new' )

    std_features =  ['IND_'+i for i in list(threshold_up_std.keys()) + list(threshold_down_std.keys())]
    reg_features =  ['IND_'+i for i in list(threshold_up_reg.keys()) + list(threshold_down_reg.keys())]
    new_features =  ['IND_'+i for i in list(threshold_up_new.keys()) + list(threshold_down_new.keys())]
    new_ind = new_features
    for data in feat_list:
        factor = data
        data_origin = data
        if 'share_vfl' in data:
            if data in new_ind:
                if flag_data == 'data_2': 
                    data_origin = data[4:] 
                vol_df_list_data3signals = df_n[['DATE',data_origin]].sort_values('DATE').copy()
                if '_abs' in factor:
                    vol_df_list_data3signals['feature_type'] = 'ABS'
                else:
                    vol_df_list_data3signals['feature_type'] = 'NEW'
            if data in std_features:
                if flag_data == 'data_2': 
                    data_origin = 'NSD_I_'+data[4:] 
                vol_df_list_data3signals = df_r[['DATE',data_origin]].sort_values('DATE').copy()
                vol_df_list_data3signals['feature_type'] = 'NSTD'
                vol_df_list_data3signals.rename(columns={data_origin:'sfl'},inplace=True)
            if data in reg_features: 
                if flag_data == 'data_2': 
                    data_origin = 'B_I_'+data[4:] 
                vol_df_list_data3signals_help = df_wf[['DATE',data_origin]].sort_values('DATE').copy()
                vol_df_list_data3signals_help['feature_type'] = 'REG'
                vol_df_list_data3signals_help.rename(columns={data_origin:'sfl'},inplace=True)
                if data in std_features: # если есть обе фичи (стд и рег), то соединяем датафреймы
                    vol_df_list_data3signals = pd.concat([vol_df_list_data3signals,vol_df_list_data3signals_help])
                    vol_df_list_data3signals = vol_df_list_data3signals.sort_values('DATE')
            vol_df_list_data3signals['factor'] = make_factor_great_again_v2(factor, df_total_info)
        else:
            if flag_data == 'data_2': 
                data_origin = data[4:] 
            vol_df_list_data3signals = res[['DATE',data_origin]].sort_values('DATE').copy()
            vol_df_list_data3signals['factor'] = factor[4:]
            vol_df_list_data3signals['feature_type'] = 'AGG'
        if 'share_vfl' in data:
            data_origin = 'sfl'
        vol_df_list_data3signals = vol_df_list_data3signals.rename(columns={'DATE':'report_date',
                                                             data_origin:'Signal'})
        df_list_data3signals = pd.concat([df_list_data3signals,vol_df_list_data3signals])
    df_list_data3signals = df_list_data3signals[['report_date','Signal','factor','feature_type']]
    if flag_data == 'data_2':
        df_list_data3signals.rename(columns={'Signal':'Value'},inplace=True)
    if flag_data == 'data_3':    
        df_list_data3signals['Signal'] = df_list_data3signals['Signal'].apply(lambda x: 1 if x >= 0.001  else 0)
        df_list_data3signals = df_list_data3signals.groupby(['report_date','factor']).agg({'Signal':'max'}).reset_index()
        df_list_data3signals = df_list_data3signals[['report_date','Signal','factor']].sort_values(['factor','report_date'])
    if flag_data == 'data_4': 
        df_list_data3signals['Signal'] = df_list_data3signals['Signal'].apply(lambda x: 1 if x >= 0.001  else 0)
        
    return df_list_data3signals


def get_segment_report(
        model: str,
        segment: str,
        segment_name: str,
        total_treshold: float, 
        tresholds: dict, 
        df_total_info: pd.DataFrame,
        df_wf: pd.DataFrame,
        df_r: pd.DataFrame,
        df_n: pd.DataFrame,
        df_ind_reg_work: pd.DataFrame,
        res: pd.DataFrame, 
        all_about_sfl: pd.DataFrame = pd.DataFrame(),
        names_dict_sfl: dict = dict(),
        df_features_info_total: pd.DataFrame = pd.DataFrame()
    ) -> Dict[str, Optional[pd.DataFrame]]:
        
        if segment not in ['sfl', 'total']:
            ##features
            df_list_features = return_list_features(
                df_total_info = df_total_info, 
                model = model, 
                segment= segment,
                segment_name = segment_name,
                report_sfl=False
            )
            ##ewi_threshold
            list_ewi_threshold = return_list_ewi_threshold(
                total_treshold = total_treshold, 
                model = model, 
                tresholds = tresholds, 
                total_flg=False, 
                segment = segment
            )
            ##data_2_modif
            df_list_data2modif = return_list_data2modif(
                segment = segment,  
                model=model, 
                df_total_info = df_total_info, 
                df_wf = df_wf, 
                df_r = df_r, 
                df_n = df_n
            )
            ##data_3_signals
            df_list_data3signals = return_list_data3signals(
                segment=segment, 
                model=model, 
                df_total_info = df_total_info, 
                flag_data = 'data_3',  
                df_wf = df_wf, 
                df_r = df_r, 
                df_n = df_n
            )
            ##data_4_signals_decomp 
            df_list_data4signalsdecomp = return_list_data3signals(
                segment=segment, 
                model=model, 
                df_total_info = df_total_info,  
                flag_data = 'data_4',  
                df_wf = df_wf, 
                df_r = df_r, 
                df_n = df_n
            )
            ##data_ewi
            df_list_result = return_list_result(
                df_ind_reg_work =df_ind_reg_work, 
                model = model, 
                tresholds = tresholds, 
                total_treshold = total_treshold, 
                total_flg=False, 
                segment=segment
            )
        elif segment == 'sfl':
            ##features
            df_list_features = return_list_features_sfl_new(
                df_total_info = df_total_info, 
                model = model, 
                df_features_info_total = all_about_sfl, 
                names_dict_sfl = names_dict_sfl
            ) #+
            ##ewi_threshold
            list_ewi_threshold = return_list_ewi_threshold(
                total_treshold = total_treshold, 
                model = model, 
                tresholds = tresholds, 
                total_flg=False, 
                segment = segment
            )#+
            ##data_2_modif
            df_list_data2modif = return_list_data4signalsdecomp_sfl_new(
                flag_data = 'data_2', 
                feat_list = list(all_about_sfl.feature_name),
                df_total_info = df_total_info , 
                df_n = df_n, 
                df_r = df_r, 
                df_wf = df_wf, 
                res = res, 
                model=model
            )
            ##data_3_signals
            df_list_data3signals = return_list_data4signalsdecomp_sfl_new(
                flag_data = 'data_3', 
                feat_list = list(all_about_sfl.feature_name), 
                df_total_info = df_total_info , 
                df_n = df_n, 
                df_r = df_r, 
                df_wf = df_wf,
                res = res, 
                model=model
            )
            ##data_4_signals_decomp
            df_list_data4signalsdecomp = return_list_data4signalsdecomp_sfl_new(
                flag_data = 'data_4', 
                feat_list = list(all_about_sfl.feature_name), 
                df_total_info = df_total_info , 
                df_n = df_n, 
                df_r = df_r, 
                df_wf = df_wf,
                res = res, 
                model=model
            )
            ##data_ewi
            df_list_result = return_list_result(
                df_ind_reg_work =df_ind_reg_work , 
                model = model, 
                tresholds = tresholds, 
                total_treshold = total_treshold, 
                total_flg=False, 
                segment='sfl'
            )
        elif segment == 'total':
            ##features
            # df_list_features = return_list_features_res_mod(
            #     df_features_info_total = df_features_info_total, 
            #     model = model 
            # )
            df_list_features = return_list_features_res_mod_v2(
                df_features_info_total = df_features_info_total, 
                model = model 
            )
            ##ewi_threshold
            list_ewi_threshold = return_list_ewi_threshold(
                total_treshold = total_treshold, 
                model = model, 
                tresholds = tresholds, 
                total_flg=True, 
                segment = segment
            )#+

            ##data_2_modif
            df_list_data2modif = return_list_data4signalsdecomp_sfl_new(
                flag_data = 'data_2', 
                feat_list = list(df_features_info_total.feature_name), 
                df_total_info = df_total_info , 
                df_n = df_n, 
                df_r = df_r, 
                df_wf = df_wf, 
                res = res,
                model=model
            )
            ##data_3_signals
            df_list_data3signals = return_list_data4signalsdecomp_sfl_new(
                flag_data = 'data_3', 
                feat_list = list(df_features_info_total.feature_name),
                df_total_info = df_total_info , 
                df_n = df_n, 
                df_r = df_r, 
                df_wf = df_wf, 
                res = res,
                model=model
            )
            df_list_data4signalsdecomp = None
            ##data_ewi
            df_list_result = return_list_result(
                df_ind_reg_work =df_ind_reg_work , 
                model = model, 
                tresholds = tresholds, 
                total_treshold = total_treshold, 
                total_flg=True
            )
            
        report = {
            'features_info': df_list_features,
            'ewi_threshold': list_ewi_threshold,
            'data_2_modif': df_list_data2modif,
            'data_3_signals': df_list_data3signals,
            'data_4_signals_decomp': df_list_data4signalsdecomp,
            'data_ewi': df_list_result
        }
        
        return report