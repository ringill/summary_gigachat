import warnings
warnings.simplefilter(action='ignore', category=RuntimeWarning)

import pandas as pd
import numpy as np
import math

'''
функции RUN
'''

def MA_I( data, T, dataset):
    '''
    
    dataset - датасет
    data - ряд
    T - параметр окна

    вспомогательная функция MA_I

                   текущее значение - MA_I
        NSD_I = -------------------------    
                          SD_I
        
        количество стандартных отклонений == стандартизированное отклонение текущего значения от скользящего среднего
        > насколько экстремальным (необычным) является текущее значение в сравнении с ближайшей историей
                        
        MA_I - среднее
        SD_I - дисперсионный коэф нормировки
    '''
    arr = []
    for t in range(len(dataset[data])):
        if t <= T:
            arr.append(dataset[data][0:t+1].sum()/(t+1))
        else:
            arr.append(dataset[data][t-T:t+1].sum()/(T+1))
    dataset['MA_I_'+data] = arr

def SD_I_calc(P, t, T):
    '''
    вспомогательная функция для SD_I

                   текущее значение - MA_I
        NSD_I = -------------------------    
                          SD_I
        
        количество стандартных отклонений == стандартизированное отклонение текущего значения от скользящего среднего
        > насколько экстремальным (необычным) является текущее значение в сравнении с ближайшей историей
                        
        MA_I - среднее
        SD_I - дисперсионный коэф нормировки

        
    '''
    if t <= T:
        first = sum(list(map(lambda x: x**2, P[0:t+1])))/(t+1)
        second = (sum(P[0:t+1])/(t+1))**2
        res = math.sqrt(abs(first-second)*((t+2)/(t+1)))
    else:
        first = sum(list(map(lambda x: x**2, P[t-T:t+1])))/(T+1)
        second = (sum(P[t-T:t+1])/(T+1))**2
        res = math.sqrt(abs(first-second)*((T+1)/T))
    return res

def SD_I( data, T, dataset):
    '''
    dataset - датасет
    data - ряд
    T - параметр окна

      вспомогательная функция SD_I

                   текущее значение - MA_I
        NSD_I = -------------------------    
                          SD_I
        
        количество стандартных отклонений == стандартизированное отклонение текущего значения от скользящего среднего
        > насколько экстремальным (необычным) является текущее значение в сравнении с ближайшей историей
                        
        MA_I - среднее
        SD_I - дисперсионный коэф нормировки

        
    '''
    arr1 = []
    for t in range(len(dataset[data])):
        P = list(dataset[data])
        arr1.append(SD_I_calc(P, t, T))
    dataset['SD_I_'+data] = arr1

def NSD_I( data, dataset ):
    '''
    dataset - датасет
    data - ряд

    
               текущее значение - MA_I
        NSD_I = -------------------------    
                          SD_I
        
        количество стандартных отклонений == стандартизированное отклонение текущего значения от скользящего среднего
        > насколько экстремальным (необычным) является текущее значение в сравнении с ближайшей историей
                        
        MA_I - среднее
        SD_I - дисперсионный коэф нормировки


    '''
    # TODO добавить обработку случая деления на ноль для предсказуемости и избавления от предупреждений (вылезает RuntimeWarning)
    arr = []
    for i in range(len(dataset)):
        # случай очень постоянных значений, где даже малые изменения параметра вызывают загорание фичи
        if dataset.iloc[i]['SD_I_'+data]/dataset.iloc[i]['MA_I_'+data] < 0.05:
            arr.append((dataset.iloc[i][data] - dataset.iloc[i]
                       ['MA_I_'+data])/(4*dataset.iloc[i]['SD_I_'+data]))
        else:
            arr.append((dataset.iloc[i][data] - dataset.iloc[i]
                       ['MA_I_'+data])/(dataset.iloc[i]['SD_I_'+data]))
    dataset['NSD_I_'+data] = arr


def B_I( T, data, dataset):
    '''
    dataset - датасет
    data - ряд
   
                ковариация 
        B_I = ----------------
                 дисперия 
        
        коэффициент наклона линейной регрессии на скользящем окне == средняя скорость изменения величины в единицу времени
        > оценка тренда
        > оценка скорости изменения
    '''
    T = int(T)
    arr = [0]*T
    for t in range(T, len(dataset[data+'_LOESS'])):
        t_arr = [i for i in range(t-T, t+1)]
        score = np.cov(dataset[data+'_LOESS'][t-T:t+1], t_arr)[0][1] / np.var(t_arr)
        arr.append(score)
    dataset['B_I_'+data] = arr
    
def get_dict_th(datafr, probitie, type_w):
    '''
    возвращает пороговые значения
    datafr - датасет
    probitie - пробитие: 'up' или 'down'
    type_w - тип ряда :'nstd' или 'reg' или 'new'
    '''
    part_df = datafr[(datafr.prob==probitie)&(datafr.type==type_w)]
    return dict(zip(list(part_df.feature), list(part_df['treshold'])))

def get_dict_T(datafr, probitie,type_w):
    '''
    возвращает окна 
    datafr - датасет
    probitie - пробитие: 'up' или 'down'
    type_w - тип ряда :'nstd' или 'reg'
    '''
    part_df = datafr[(datafr.prob==probitie)&(datafr.type==type_w)]

    keys = list(part_df.feature)
    values = list(part_df['T'])
    
    return {k: v for k, v in zip(keys, values)}


def descriptor_tables(table_to_desc):
    '''
    техническая функция, нужна для составления пояснений к таблицам с метриками в функции model_th_metric
    для вызова в функции model_th_metric необходимо указать  need_desc=True


    либо просто вызвать функцию:
    descriptor_tables(table_to_desc = 'model_th_metric_output1')
    descriptor_tables(table_to_desc = 'model_th_metric_output2')
    descriptor_tables(table_to_desc = 'model_th_metric_output3')
    
    '''
    if table_to_desc =='model_th_metric_output1':
        print('''\nout1 - таблица со всеми Событиями
------------------------------------------------------------------------------------------------
        · real_date - дата фактического события (поднятие/снижение длинного/короткого конца)
        · year - год
        · CRIS - перечисление событий
        · Predicted - флаг 0/1 - было ли предугаданно событие
        · Количество_срабатываний - сколько раз индикатор сигнализировал о событии на окне 4 недели до
        · min_дата_срабатывания - дата, в которую индикатор впервые просигнализировал о событии на окне 4 недели до
        · дней_до_события - разница в днях между min_дата_срабатывания и real_date - насколько сигнал опередил событие 
        \n
        ''')
    elif table_to_desc =='model_th_metric_output2':
        print('''\nout2 - таблица с различными метриками для выбранного порога
------------------------------------------------------------------------------------------------
    •под Событием предполагаю Поднятие или Снижение (1 оригинального таргета, от которого потом построили WILL_CRISIS (четыре 1 до фактической таргетной точки) - таргет модели)
----------------------------------------------------------------------------------------------
    · 'Количество_предугаданных_событий' - количество событий, которое удается предупредить при таком пороговом значении
    · 'Количество_пропущенных_событий' - количество событий, которое не удается предупредить при таком пороговом значении
    · 'сред_дней_до_события' - среднее значение расстояния в днях между первым срабатыван/ием и наступлением события при выбранном пороге
------------------------------------------------------------------------------------------------
    •под Срабатыванием предполагаю переход модельного индикатора в 1 (превышение порогового значения) 
------------------------------------------------------------------------------------------------
    · 'сред_количество_сраб_на_событие' - среднее количество срабатываний (min 0, max 4), предупреждающих события 
    · 'Верных_срабатываний' - количество срабатываний, совпадающих с таргетом модели(TP)
    · 'Ложных_срабатываний' - количество срабатываний, не совпадающих с таргетом модели(FP)
    · 'Пропущенных_значений'- количество точек таргета модели, в которых не было срабатываний(FN) 
    · 'Верных_точек'- количество точек (дат), когда срабатывание/не срабатывание совпадает с таргетом модели (TP + TN)
    · 'Ошибочных_точек'- количество точек (дат), когда срабатывание/не срабатывание не совпадает с таргетом модели (FP + FN)
        \n
        ''')
    elif table_to_desc =='model_th_metric_output3':
        print('''\nout3 - таблица с метриками, агрегированнными по годам
------------------------------------------------------------------------------------------------
       · year - год
       · Предсказанных_событий - количество событий в году, которые удалось спрогнозировать
       · Общее_количество_срабатываний - количество случаев, когда индикатор переходил порог
       · Общее_количество_событий - количество событий в году
       · Точек_таргета - количество точек, в которых таргет модели == 1
       · Попаданий_в_таргет -количество точек, в которых срабатывания совпадают с таргетом модели
       · Непопаданий_в_таргет - количество точек, в которых срабатывания нет, но таргет модели 1
       · Ложных_срабатываний - количество точек, в которых есть срабатывание, но таргет модели 0
        \n
        ''')

def model_th_metric(target_path , model, th, df_ind_reg_work, section = '', need_desc=False):
    '''
    функция нужна для более оптимального поиска пороговых значений
    возвращает 3 таблицы, можно вызвать их дескриптор (need_desc=True)
    target_path - путь к файлу с таргетом
    model - модель - 'long_up', 'long_down', 'short_up', 'short_down'
    th - пороговое значение
    section - блок: по умолчанию ''- для верхнеуровневой модели
                    'kul','kfl','dul','sfl','market','alm' - блоки
    need_desc - дескриптор полученных таблиц
    '''

    if need_desc:
        descriptor_tables(table_to_desc = 'model_th_metric_output1')
        descriptor_tables(table_to_desc = 'model_th_metric_output2')
        descriptor_tables(table_to_desc = 'model_th_metric_output3')
        
    path = target_path + str(model) + '/'
    model_target = pd.read_excel(path+'target_'+str(model)+'.xlsx')
    real_target = pd.read_excel(path+str(model)+'_target_one.xlsx')

    model_target['report_date'] = pd.to_datetime(model_target['report_date'])
    model_target = model_target.rename(columns={'report_date':'DATE','target':'WILL_CRISIS'})
    real_target = real_target.rename(columns={'date':"DATE"})
    real_target['DATE'] = pd.to_datetime(real_target['DATE'])
    model_target['DATE'] = pd.to_datetime(model_target['DATE'])
    real_target['week'] = real_target.DATE.dt.isocalendar().week
    model_target['week'] = model_target.DATE.dt.isocalendar().week
    real_target['year'] = real_target.DATE.dt.year
    model_target['year'] = model_target.DATE.dt.year

    model_target = model_target.merge(real_target.rename(columns={'DATE':'real_date'}), how='left')

    model_target = model_target[model_target.DATE>'2017-01-01'].reset_index(drop=True)
    model_target[str(model)+'_target'] = model_target[str(model)+'_target'].fillna(0)

    model_target.real_date.fillna(method ='bfill', inplace=True)
    model_target['dn_bef'] = model_target['DATE']-model_target['real_date']

    if section=='':
        rob = df_ind_reg_work[['DATE','WILL_CRISIS','total']].merge(model_target)
        rob['red'] = 0
        rob.loc[rob.total>=th, 'red'] = 1
    else: 
        rob = df_ind_reg_work[['DATE','WILL_CRISIS',str(section)+'_total']].merge(model_target)
        rob['red'] = 0
        rob.loc[rob[str(section)+'_total']>=th, 'red'] = 1
   
    help_tb = rob[rob[str(model)+'_target']==1]
    help_tb = help_tb.reset_index(drop=True).reset_index().rename(columns={'index':'counter'})
    for u in help_tb['counter']:
        help_tb.loc[help_tb['counter']==u,'CRIS'] = 'Событие_'+str(u)
    rob = rob.merge(help_tb, how='left')    
    rob['CRIS'] = rob['CRIS'].fillna('Stab')
    rob = rob.rename(columns={'Unnamed: 0':'cnt'})
    for i in rob.CRIS:
        if i == 'Stab':
            continue
        else:
            v = rob[rob.CRIS==i].cnt.values[0]
            rob.loc[rob.CRIS==i,'Количество_срабатываний'] = sum(rob[(rob.cnt>=v-4)&(rob.cnt<v)].red)
            if sum(rob[(rob.cnt>=v-4)&(rob.cnt<v)].red)>0:
                rob.loc[rob.CRIS==i,'min_дата_срабатывания'] = min(rob[(rob.cnt>=v-4)&(rob.cnt<v)].DATE)

    output_1 = rob[~(rob.CRIS=='Stab')]
    output_1['Predicted'] = 0
    if len(output_1[output_1['Количество_срабатываний']>0])==0:
        return None
    output_1.loc[output_1['Количество_срабатываний']>0,'дней_до_события'] = output_1['min_дата_срабатывания'] - output_1['real_date']
    output_1.loc[output_1['Количество_срабатываний']>0,'Predicted'] = 1
    output_1_n = output_1[['real_date', 'year', 'CRIS','Predicted','Количество_срабатываний', 'min_дата_срабатывания', 'дней_до_события' ]]
    
    output_2 = pd.DataFrame(output_1[output_1['Predicted']>0][['дней_до_события','Количество_срабатываний']].mean()).T
    output_2 = pd.DataFrame(output_1.groupby('Predicted', as_index=False).agg({'дней_до_события':'mean',
                                                                   'Количество_срабатываний':'mean',
                                                                   'CRIS':lambda x:x.nunique()})).rename(columns={'дней_до_события':'сред_дней_до_события',
                                                                                                                  'Количество_срабатываний':'сред_количество_сраб_на_событие',
                                                                                                                  'CRIS':'Количество_предугаданных_событий'})
    output_2 = output_2[output_2.Predicted==1]
    output_2['Порог']  = th
    output_2['Верных_срабатываний']  = len(rob[(rob['WILL_CRISIS']==1)&(rob['red']==1)])
    output_2['Верных_точек']  = len(rob[(rob['WILL_CRISIS']==1)&(rob['red']==1)])+len(rob[(rob['WILL_CRISIS']==0)&(rob['red']==0)])
    output_2['Ошибочных_точек']  = len(rob[(rob['WILL_CRISIS']==1)&(rob['red']==0)])+len(rob[(rob['WILL_CRISIS']==0)&(rob['red']==1)])
    
    output_2['Ложных_срабатываний']  = len(rob[(rob['WILL_CRISIS']==0)&(rob['red']==1)])
    output_2['Пропущенных_значений']  = len(rob[(rob['WILL_CRISIS']==1)&(rob['red']==0)])
    output_2['Количество_пропущенных_событий']  = len(output_1) - output_2['Количество_предугаданных_событий']
    output_2_n = output_2[['Порог', 'Количество_предугаданных_событий', 'Количество_пропущенных_событий', 'сред_дней_до_события','сред_количество_сраб_на_событие',
                          'Верных_срабатываний', 'Ложных_срабатываний', 'Пропущенных_значений','Верных_точек','Ошибочных_точек']]


    output_3 = output_1.groupby('year', as_index = False).agg({'Predicted':'sum',
                                                   'Количество_срабатываний':'sum',
                                                   'CRIS':'count'}).rename(columns={'Predicted':'Предсказанных_событий',
                                                                                   'Количество_срабатываний':'Общее_количество_срабатываний',
                                                                                  'CRIS':'Общее_количество_событий'})

    output_3 = output_3.merge(rob.groupby('year', as_index = False).agg({"WILL_CRISIS":'sum'}).rename(columns={"WILL_CRISIS":'Точек_таргета'}),how='left')
    output_3 = output_3.merge(rob[(rob['WILL_CRISIS']==1)&(rob['red']==1)].groupby('year', as_index = False).agg({'red':'sum'}).rename(columns={'red':'Попаданий_в_таргет'}),how='left').fillna(0)
    output_3 = output_3.merge(rob[(rob['WILL_CRISIS']==1)&(rob['red']==0)].groupby('year', as_index = False).agg({'WILL_CRISIS':'sum'}).rename(columns={'WILL_CRISIS':'Непопаданий_в_таргет'}),how='left').fillna(0)
    output_3 = output_3.merge(rob[(rob['WILL_CRISIS']==0)&(rob['red']==1)].groupby('year', as_index = False).agg({'red':'sum'}).rename(columns={'red':'Ложных_срабатываний'}),how='left').fillna(0)

    return output_1_n, output_2_n, output_3


def NSR_metric(df, target_path , model, treshold, target,df_ind_reg_work, section = '', total_th = 0):
    '''
    вспомогательная функция, необходимая для получений таблицы метрик для пороговых значений в функции get_metics_for_all_th
    
    df - датафрейм, содержащий total - знаение модели, до перехода в индикатор, дату, таргет
    target_path - путь к файлу с таргетом
    model - параметр типа модели ["long_up", 'long_down", "short_up", 'short_down"], берется как гиперпараметр
    treshold - передаваемое пороговое значение(от 0 до 1)
    target = 'WILL_CRISIS', если будет ренейминг, нужно поменять
    df_ind_reg_work - тот же df
    section - если '' (по умолчанию) - метрики общей модели, если ['kul', 'dul', 'market', 'alm', 'sfl', 'kfl'] - метрики по выбранному блоку
    '''

    if section=='':
        th = total_th
    else:
        th=tresholds[str(section)+'_total']
        
    path = target_path + str(model) + '/'
    model_target = pd.read_excel(path+'target_'+str(model)+'.xlsx')
    real_target = pd.read_excel(path+str(model)+'_target_one.xlsx')

    model_target['report_date'] = pd.to_datetime(model_target['report_date'])
    model_target = model_target.rename(columns={'report_date':'DATE','target':'WILL_CRISIS'})
    real_target = real_target.rename(columns={'date':"DATE"})
    real_target['DATE'] = pd.to_datetime(real_target['DATE'])
    model_target['DATE'] = pd.to_datetime(model_target['DATE'])
    real_target['week'] = real_target.DATE.dt.isocalendar().week
    model_target['week'] = model_target.DATE.dt.isocalendar().week
    real_target['year'] = real_target.DATE.dt.year
    model_target['year'] = model_target.DATE.dt.year

    model_target = model_target.merge(real_target.rename(columns={'DATE':'real_date'}), how='left')

    model_target = model_target[model_target.DATE>'2017-01-01'].reset_index(drop=True)
    # model_target = model_target.drop('Unnamed: 0', axis=1)
    model_target[str(model)+'_target'] = model_target[str(model)+'_target'].fillna(0)
    
    if section=='':
        rob = df_ind_reg_work[['DATE','WILL_CRISIS','total']].merge(model_target)
        rob['red'] = 0
        rob.loc[rob.total>=th, 'red'] = 1
    else:
        rob = df_ind_reg_work[['DATE','WILL_CRISIS',str(section)+'_total']].merge(model_target)
        rob['red'] = 0
        rob.loc[rob[str(section)+'_total']>=th, 'red'] = 1
    
    help_tb = rob[rob[str(model)+'_target']==1]
    help_tb = help_tb.reset_index(drop=True).reset_index().rename(columns={'index':'counter'})
    for u in help_tb['counter']:
        help_tb.loc[help_tb['counter']==u,'CRIS'] = 'Событие_'+str(u)
    rob = rob.merge(help_tb, how='left')    
    rob['CRIS'] = rob['CRIS'].fillna('Stab')
    cris_table = rob.copy()
    volattb = pd.DataFrame(columns={})
    df['RES_trsh_'+str(treshold)] = 0
    if section=='':
        df.loc[df['total']>=treshold, 'RES_trsh_'+str(treshold)] = 1
    else:
        df.loc[df[str(section)+'_total']>=treshold, 'RES_trsh_'+str(treshold)] = 1
    
    count_true_predict = len(df[(df['RES_trsh_'+str(treshold)]==1)&(df[target]==1)])
    count_false_predict = len(df[(df['RES_trsh_'+str(treshold)]==1)&(df[target]==0)])
    
    count_true_result = count_true_predict + len(df[(df['RES_trsh_'+str(treshold)]==0)&(df[target]==0)])
    count_false_result = count_false_predict + len(df[(df['RES_trsh_'+str(treshold)]==0)&(df[target]==1)])
    NSR_metric = count_false_predict/count_true_result
    
    vct = cris_table.merge(df[['DATE','RES_trsh_'+str(treshold)]])
    rvct = vct[vct['CRIS']!='Stab'].groupby('CRIS', as_index=False).agg({'RES_trsh_'+str(treshold):'sum'}).rename(columns={'RES_trsh_'+str(treshold):'count_w'})
    rvct['pr'] = 0
    rvct.loc[rvct['count_w']>0,'pr'] = 1
    fvct = vct[vct['CRIS']=='Stab'].groupby('CRIS', as_index=False).agg({'RES_trsh_'+str(treshold):'sum'}).rename(columns={'RES_trsh_'+str(treshold):'erpr'})

    volattb['treshold'] = [treshold]
    volattb['count_true_predict'] = [count_true_predict]
    volattb['count_false_predict'] = [count_false_predict]
    volattb['count_true_result'] = [count_true_result]
    volattb['count_false_result'] = [count_false_result]
    volattb['NSR_metric'] = [NSR_metric]
    volattb['true_cr'] = [len(rvct[rvct['pr']==1])]
    volattb['false_cr'] = [fvct['erpr'].values[0]]
    
    return volattb
    
def get_metics_for_all_th(df, target_path, model_tresholds, model, section='', target = 'WILL_CRISIS', ):

    '''
     функция, создающая таблицу метрик для пороговых значений 
     df - датафрейм, содержащий total - знаение модели, до перехода в индикатор, дату, таргет
     target_path  - путь к файлу с таргетом
     model - параметр типа модели ["long_up", 'long_down", "short_up", 'short_down"], берется как гиперпараметр
     section - если '' (по умолчанию) - метрики общей модели, если ['kul', 'dul', 'market', 'alm', 'sfl', 'kfl'] - метрики по выбранному блоку
     target = 'WILL_CRISIS', если будет ренейминг, нужно поменять'
    '''
    total_th = model_tresholds[model]
    metics_df = pd.DataFrame(columns={})
    tresholds_arr = np.arange(0,1.01,0.01)
    for trshld in tresholds_arr:
        metics_df = pd.concat([metics_df,NSR_metric(df, target_path = target_path, model = model, treshold = trshld, target = target, section=section, df_ind_reg_work=df, total_th = total_th )])
    return metics_df


def test_total_timeon(df_ind_reg_work, section = '', total_th = 0 ):
    '''
    df_ind_reg_work - датафрейм, содержащий total - знаение модели, до перехода в индикатор, дату, таргет
    section  - если '' (по умолчанию) - метрики общей модели, если ['kul', 'dul', 'market', 'alm', 'sfl', 'kfl'] - метрики по выбранному блоку
    '''
    
    r = df_ind_reg_work.copy()#[df_ind_reg_work['DATE']>'2020-01-01'
    r['red_work_o'] = 0
    if section == '':
        th = total_th
        r.loc[r['total']>th,'red_work_o'] =r['total']
        total_on =  len(r[r['red_work_o']>0])/len(r['total'])
        total_cor_on =  len(r[(r['red_work_o']>0)&(r['WILL_CRISIS']>0)])/len(r[r['red_work_o']>0]['total'])    
    else:
        th = tresholds[str(section)+'_total']
        r.loc[r[str(section)+'_total']>th,'red_work_o'] =r[str(section)+'_total']
        total_on =  len(r[r['red_work_o']>0])/len(r[str(section)+'_total'])
        total_cor_on =  len(r[(r['red_work_o']>0)&(r['WILL_CRISIS']>0)])/len(r[r['red_work_o']>0][str(section)+'_total'])
    statdf = pd.DataFrame(columns={})
    statdf['Порог'] = [th]
    statdf['Срабатываний'] = len(r[r['red_work_o']>0])
    statdf['Верных_срабатываний'] = len(r[(r['red_work_o']>0)&(r['WILL_CRISIS']>0)])
    statdf['Время_горения'] = total_on
    statdf['Время_срабатывания'] = total_cor_on    
    return statdf

def NSRatio(df):
    a, b, c, d = 0, 0, 0, 0
    W_C = df['WILL_CRISIS']
    Porog = df['POROG'+str(i)]
    a = np.sum(W_C * Porog)
    b = np.sum(Porog- W_C*Porog)
    c = np.sum(W_C - W_C*Porog)
    d = np.sum(1 + W_C*Porog-W_C-Porog)
    return a, b, c, d
    # if b + d == 0 or a == 0:
    #     score = 1
    # elif a + c == 0:
    #     score = 0
    # else:
    #     score =(b/(b+d))/(a/(a+c))
    # NSR_p1 = 0.5* score 

def work_week_bef(seg, dater, df_work, tresholds):
    '''
    вспомогательная функция в output_prez(), передает информацию, работал ли блок накануне
    seg - передавать не нужно, уже есть в вспомогательной таблице (['kul', 'dul', 'market', 'alm', 'sfl', 'kfl'])
    dater - дата от который считаются срабатывания
    '''
    date=pd.to_datetime(dater)
    sums = 0 
    while df_work[df_work.DATE==date][seg].values[0]>=tresholds[seg]:
        sums+=1
        date = date-pd.DateOffset(days=7)
    return int(sums)
    
def output_prez(date_reviz, prezentout, df_work, tresholds):
    '''
    date_reviz - актуальная дата, относительно нее будет построена динамика входящих блоков и итоговой модели
    '''
    date_reviz = pd.to_datetime(date_reviz)
    outp = prezentout.copy()
    for segm in outp.segment:
        outp.loc[outp.segment == segm, 'Недель сраб'] =int(work_week_bef(seg = segm, dater = date_reviz, df_work=df_work, tresholds=tresholds))
        if df_work[df_work.DATE==date_reviz][segm].values[0] < df_work[df_work.DATE==date_reviz-pd.DateOffset(days=7)][segm].values[0]:
            outp.loc[outp.segment == segm, 'Динамика'] = '↘'
        elif df_work[df_work.DATE==date_reviz][segm].values[0] == df_work[df_work.DATE==date_reviz-pd.DateOffset(days=7)][segm].values[0]:
            outp.loc[outp.segment == segm, 'Динамика'] = '—'
        else:
            outp.loc[outp.segment == segm, 'Динамика'] = '↗'
        outp.loc[outp.segment == segm, 'Порог'] =tresholds[segm]
        outp.loc[outp.segment == segm, 'Значение'] =df_work[df_work.DATE==date_reviz][segm].values[0]
    
    return outp.sort_values('Вес', ascending=False)[['Блок', 'Значение', 'Порог', 'Динамика', 'Недель сраб']]
def renamer_col(df):
    '''
    переименовать колонки, чтобы записать в excel в приятном виде
    '''
    
    for column in df.columns:
        df=df.rename(columns={column:column.replace('_',' ')})
    return df