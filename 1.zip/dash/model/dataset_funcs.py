# dash/model/dataset_funcs.py
import warnings

warnings.simplefilter(action='ignore', category=FutureWarning)

import datetime
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from dateutil.relativedelta import FR, relativedelta


# функции перехода к недельным данным
class Weekly_aggregator:
    def __init__(self, daily_df: pd.DataFrame, aggregation_types: pd.DataFrame, window_size: int):

        self.daily_df = self.convert_types(daily_df)
        # self.target = target
        # self.type_up = type_up
        self.aggregation_types = aggregation_types
        self.window_size = window_size
        # self.weekly_target = self.get_weekly_target(target=target)

        self.daily_df['dw'] = self.daily_df["dtdate"].dt.dayofweek
        # self.daily_df = self.daily_df.fillna(method='ffill') # это делали в 185 строчке

    def get_weekly_df(self):

        weekly_df = pd.DataFrame()
        weekly_df["report_date"] = self.daily_df[self.daily_df.dw==self.window_size].dtdate

        self.feat_wout_avg = []
        for feature in self.daily_df.columns:
            if feature not in self.aggregation_types.feature.unique():
                continue
            elif self.aggregation_types[self.aggregation_types.feature==feature].method.values[0] == "Последнее доступное значение":
                self.feat_wout_avg.append(feature)
            elif self.aggregation_types[self.aggregation_types.feature==feature].method.values[0] == "Простое среднее":
                if self.aggregation_types[self.aggregation_types.feature==feature].holiday.values[0]:
                    #df_temp = self.daily_df[~self.daily_df.dw.isin([5,6])][["dtdate", feature]] # было раньше: учитывали только сб и вск
                    df_temp = self.daily_df[["dtdate", feature,'weekend']]
                    df_temp = df_temp.rename(columns={"dtdate": "report_date"})
                    df_temp.loc[df_temp['weekend']==0, feature] = None
                    df_temp[feature] = df_temp[feature].rolling(7, min_periods=1).apply(lambda x: np.mean(x))
                    df_temp[feature] = df_temp[feature].fillna(method='ffill')
                    weekly_df = weekly_df.merge(df_temp[["report_date", feature]], how='inner', on="report_date")
                else:
                    df_temp = self.daily_df[["dtdate", feature]]
                    df_temp = df_temp.rename(columns={"dtdate": "report_date"})
                    df_temp[feature] = df_temp[feature].rolling(7).apply(lambda x: np.mean(x))
                    weekly_df = weekly_df.merge(df_temp[["report_date", feature]], how='inner', on="report_date")
            elif self.aggregation_types[self.aggregation_types.feature==feature].method.values[0] == "Средневзвешенное":
                if self.aggregation_types[self.aggregation_types.feature==feature].holiday.values[0]:
                    weight_feature = self.aggregation_types[self.aggregation_types.feature==feature].weight_feature.values[0]
                    #df_temp = self.daily_df[~self.daily_df.dw.isin([5,6])][["dtdate", feature, weight_feature]]
                    df_temp = self.daily_df[["dtdate", feature,weight_feature,'weekend']]
                    df_temp = df_temp.rename(columns={"dtdate": "report_date"})
                    df_temp[[feature, weight_feature]] = df_temp[[feature, weight_feature]].astype(float)
                    df_temp.loc[df_temp['weekend']==0, feature] = None
                    df_temp.loc[df_temp['weekend']==0, weight_feature] = None
                    df_temp["mul"] = df_temp[feature] * df_temp[weight_feature]
                    #df_temp[feature] = df_temp.rolling(7, min_periods=1).weighted_average(weight_feature).values старая функция
                    df_temp[feature] = df_temp['mul'].rolling(7, min_periods=1).apply(lambda x: np.sum(x))/df_temp[weight_feature].rolling(7, min_periods=1).apply(lambda x: np.sum(x))
                    df_temp[feature] = df_temp[feature].fillna(method='ffill')
                    weekly_df = weekly_df.merge(df_temp[["report_date", feature]], how='inner', on="report_date")
                else:
                    weight_feature = self.aggregation_types[self.aggregation_types.feature==feature].weight_feature.values[0]
                    df_temp = self.daily_df[["dtdate", feature, weight_feature]]
                    df_temp = df_temp.rename(columns={"dtdate": "report_date"})
                    df_temp[[feature, weight_feature]] = df_temp[[feature, weight_feature]].astype(float)
                    df_temp["mul"] = df_temp[feature] * df_temp[weight_feature]
                    #df_temp[feature] = df_temp.rolling(7).weighted_average(weight_feature).values старая функция
                    df_temp[feature] = df_temp['mul'].rolling(7).apply(lambda x: np.sum(x))/df_temp[weight_feature].rolling(7).apply(lambda x: np.sum(x))
                    weekly_df = weekly_df.merge(df_temp[["report_date", feature]], how='inner', on="report_date")
        weekly_df = weekly_df.merge(self.daily_df[["dtdate"]+self.feat_wout_avg], how="inner", left_on="report_date", right_on="dtdate")
        weekly_df = weekly_df.drop(columns=["dtdate"])
        # weekly_df = weekly_df.merge(self.weekly_target[["report_date", "target"]], how="inner", on="report_date")
        return weekly_df

    def get_weekly_target(self, target: pd.DataFrame) -> pd.DataFrame:

        target = target.copy()
        target["report_date"] = pd.to_datetime(target["report_date"])
        target = target.sort_values("report_date")
        target['dw'] = target["report_date"].dt.dayofweek

        weekly_target = target.copy()
        weekly_target['future_target'] = weekly_target['target'].rolling(7 * self.window_size).sum().shift(-7 * self.window_size)
        weekly_target = weekly_target[weekly_target['dw'] == self.window_size].copy()

        if self.type_up == 'up':
            weekly_target['target'] = weekly_target['future_target'].apply(lambda x: 1 if x > 0 else 0)
        else:
            weekly_target['target'] = weekly_target['future_target'].apply(lambda x: 1 if x < 0 else 0)

        return weekly_target

    def convert_types(self, daily_df: pd.DataFrame) -> pd.DataFrame:
        daily_df = daily_df.copy()
        features_list = daily_df.drop(columns=["dtdate", "weekend"], errors='ignore').columns.tolist()
        features_types = daily_df[features_list].dtypes.reset_index()
        features_types.columns = ["name", "type"]
        features_str_type = list(features_types[features_types["type"] == "object"].name.values)
        for feature in features_str_type:
            daily_df[feature] = pd.to_numeric(daily_df[feature], errors='coerce')
        return daily_df

def make_date_range(ewi_etc_final_dev: pd.DataFrame, last_date: str) -> pd.Series:
    """
    Args:
        ewi_etc_final_dev (pd.DataFrame): Основной фрейм
        last_date (str): {'friday', 'today', str(int)}: Последняя дата (ближайшая пятница, текущая дата или несколько дней вперед - можно указать любое целое число)

    Returns:
        pd.Series: Полный набор дат
    """
    start_date = ewi_etc_final_dev['dtdate'].min()

    if last_date == 'friday':
        # если хотим продлить датасет до БЛИЖАЙШЕЙ пятницы вперёд
        end_date = ewi_etc_final_dev['dtdate'].max() + relativedelta(weekday=FR(1))
    elif last_date == 'today':
        # если хотим продлить датасет до ТЕКУЩЕЙ даты (пример: выгрузка в четверг, прогноз - на пятницу, где пятница - ТЕКУЩАЯ дата)
        end_date = datetime.date.today()
    else:
        if last_date.isdigit():
            # если хотим продлить датасет на НЕСКОЛЬКО ДНЕЙ (подставить число) вперёд (пример: выгрузка в среду, прогноз - на пятницу, где пятница, НЕ ТЕКУЩАЯ дата, надо +2 дня)
            end_date = ewi_etc_final_dev['dtdate'].max() + pd.DateOffset(int(last_date))
        else:
            raise ValueError('Некорректное значение last_date')

    date_range = pd.date_range(start=start_date, end=end_date)

    return pd.Series(date_range, name='dtdate')

def move_column(df: pd.DataFrame, column_name: str, to_position: int, inplace: bool = False) -> Optional[pd.DataFrame]:

    if column_name not in df.columns:
        raise ValueError(f"Столбец '{column_name}' не найден в DataFrame.")

    num_columns = len(df.columns)
    if abs(to_position) >= num_columns:
        raise IndexError("Указанная позиция вне диапазона.")

    # Преобразуем отрицательный индекс в положительный
    if to_position < 0:
        to_position += num_columns

    if not inplace:
        df = df.copy()
    df.insert(to_position, column_name, df.pop(column_name))
    if not inplace:
        return df

def rearrange_df_uni(
    df: pd.DataFrame,
    index_colnames: List[str] = ['report_date'],
    new_index_colnames: Dict[str, str] = {},
    new_desc_colname: str = 'feature',
    new_value_colname: str = 'value'
):

    df_ = df.copy()

    # все колонки кроме индекса лягут в плоском виде
    df_new = pd.DataFrame()
    df_.set_index(index_colnames, inplace=True)
    for col in df_.columns:
        df_new = pd.concat([df_new, df_[col].rename(new_value_colname)])
        if new_desc_colname not in df_new.columns:
            df_new[new_desc_colname] = None
        df_new[new_desc_colname] = df_new[new_desc_colname].fillna(col)
    df_new.reset_index(inplace=True)

    # распаковка индекса и переименование
    df_new = df_new.assign(
        **pd.DataFrame(df_new['index'].values.tolist(), columns=index_colnames)
    ).drop(columns='index').rename(columns=new_index_colnames)

    # колонки в правильном порядке
    ordered_columns = []
    for col in index_colnames:
        if col in new_index_colnames:
            ordered_columns.append(new_index_colnames[col])
        else:
            ordered_columns.append(col)
    ordered_columns += [new_desc_colname, new_value_colname]

    return df_new[ordered_columns]

# логарифмируем
def logarithm(df_with_features:pd.DataFrame, log_features:list):
    df_with_features = df_with_features.copy()
    for feature in log_features:

        if feature in df_with_features.columns: # заменяем отриц значение средним предыдущих 4-х неотрицательных зн

            neg_idxs = df_with_features[df_with_features[feature] < 0].index

            for idx in neg_idxs:

                part = df_with_features[df_with_features.index<idx]
                part = part[~part[feature].isna()]

                if part.shape[0] == 0:
                    df_with_features.loc[df_with_features.index==idx, feature] = None
                    continue

                value_to_fill = part[feature].rolling(4).apply(lambda x: np.mean(x)).values[-1]
                df_with_features.loc[df_with_features.index==idx, feature] = value_to_fill

            # подумать, как лучше обрабатывать 0 и отриц зн
            #df_with_features.loc[df_with_features[feature]==0, feature] = 1e-10
            #df_with_features[feature] += 1e-10
            if df_with_features[df_with_features[feature]==0].shape[0]>0:
                df_with_features[feature] += 1e-10

            df_with_features[feature] = np.log(df_with_features[feature])

    return df_with_features


# функции превращения факторов в фичи
def get_important_features(df_with_features: pd.DataFrame, important_features: pd.DataFrame):

    df_with_features = df_with_features.copy()
    important_features = important_features.copy()

    df_part = df_with_features[['report_date']]
    df_std = df_with_features[['report_date']]

    std_neg = []
    for feature_name in important_features['feature_name'].unique():

        feature_slice = important_features[important_features['feature_name'] == feature_name]
        feature = feature_slice['corresponding_factor'].values[0]

        if feature not in df_with_features.columns:
            continue

        # df_important_features = df_with_features[['report_date']]
        df_important_features = df_with_features[['report_date', feature]].rename(
            columns={feature: feature_name}
        ).copy()

        if feature_slice['rolling_mean'].values[0]:

            df_important_features[feature_name+str('_mean')] = df_important_features[feature_name].rolling(
                feature_slice['mean_period'].values[0]
            ).apply(lambda x: np.mean(x))

            if feature_slice['standart'].values[0]:

                df_important_features[feature_name+str('_std')] = df_important_features[feature_name].rolling(
                    feature_slice['mean_period'].values[0]
                ).apply(lambda x: np.std(x))
                 # обрабатываем деление при std = 0: заменяем минимальным std != 0
                df_important_features_std = df_important_features[~df_important_features[feature_name+str('_std')].isna()]

                if df_important_features_std[df_important_features_std[feature_name+str('_std')] <= 0].shape[0] > 0:
                    std_neg.append([feature, feature_name])
                    df_std = df_std.merge(df_important_features[['report_date',feature_name+str('_std')]], how='inner', on='report_date')
                    df_important_features_std = df_important_features_std[df_important_features_std[feature_name+str('_std')]>0]
                    df_important_features.loc[df_important_features[feature_name+str('_std')] < 0, feature_name+str('_std')] = 0
                    df_important_features[feature_name+str('_std')].replace(0, df_important_features_std[feature_name+str('_std')].min())
                    #print(feature_name,df_important_features[df_important_features[feature_name+str('_std')]<=0].shape[0])

                df_important_features[feature_name] = (
                    df_important_features[feature_name] - df_important_features[feature_name+str('_mean')]
                    ) / df_important_features[feature_name+str('_std')]
            else:
                df_important_features[feature_name] -= df_important_features[feature_name+str('_mean')]

        if feature_slice['volatility'].values[0]:
            df_important_features[feature_name] = df_important_features[feature_name].rolling(
                important_features[important_features['feature_name']==feature_name]['volatility_window'].values[0]
            ).apply(lambda x: np.std(x))

        if feature_slice['logarithm'].values[0]:
            df_important_features = logarithm(df_important_features, list(feature))
            df_important_features[feature_name] -= df_important_features[feature_name].shift(1).fillna(0)

        df_part = df_part.merge(df_important_features[['report_date', feature_name]], how = 'inner', on = 'report_date')

    return df_part, df_std

def calc_new_features(df_with_features: pd.DataFrame, techfile: pd.DataFrame) -> pd.DataFrame:
    """Функция для расчета фичей типа NEW.

    Args:
        df_with_features (pd.DataFrame): Датафрейм с недельными данными по факторам
        techfile (pd.DataFrame): Технический файл с параметрами расчета фичей с типом NEW

    Returns:
        pd.DataFrame: Датафрейм с рассчитанными фичами с типом NEW
    """

    new_features_columns = ['rolling_mean', 'mean_period', 'standart', 'delta', 'volatility', 'logarithm', 'volatility_window']
    important_features = techfile.dropna(
        subset=new_features_columns
    )

    C1 = ((important_features['volatility'] == 1) & (important_features['volatility_window'] == 0))
    C2 = ((important_features['rolling_mean'] == 1) & (important_features['standart'] == 1))
    important_features = important_features[(~ C1) & (~ C2)]

    important_features = important_features.drop(columns=['feature_name']).rename(columns={'feature': 'feature_name'})
    important_features[new_features_columns] = important_features[new_features_columns].astype(int)

    # делаем фичи
    df_important_features, df_std = get_important_features(df_with_features, important_features)
    # факторы, для которых стд откл равно 0 на некотором рассматриваемом окне (такие "выбросы" заменяем на минимальное стд откл на всей истории)

    # пока вручную добавляем несколько обязательных фичей: доли рынка (разность с пред месяцем)
    for feature_name in important_features[(important_features['rolling_mean'] == 0) & (important_features['delta'] == 1)]['feature_name'].unique():

        feature = important_features[important_features['feature_name']==feature_name]['corresponding_factor'].values[0]
        df_share = df_with_features[['report_date',feature]].copy()
        df_share[feature_name] = df_with_features[feature] - df_with_features[feature].shift(1)
        # при данном подходе стоит дополнительно проверить, что нет двух подряд месяцев с одинаковыми значениями
        df_share[feature_name] = df_share[feature_name].replace(0, np.nan).ffill()
        if feature_name in df_important_features.columns:
            df_important_features.drop(columns={feature_name},inplace=True)
        df_important_features = df_important_features.merge(df_share, on = 'report_date', how='inner')

    # заменяем бесконечности нулями (это верно, если бесконечности не пришли из log_features)
    df_important_features = df_important_features.replace([np.inf, -np.inf], 0)
    # удаляем лишние "технические" факторы
    df_important_features.drop(columns={'share_kul','share_dul','share_vfl','share_kfl'}, inplace=True, errors='ignore')

    # сохраняем датасет обязательных фичей
    # df_important_features['report_date'] = pd.to_datetime(df_important_features['report_date'])
    df_important_features = df_important_features[df_important_features['report_date'] >= '2017-01-01']

    return df_important_features

def fill_missings(df: pd.DataFrame, shift: bool = True) -> pd.DataFrame:
    """Алгоритм заполнения пропусков.
    Сейчас для каждого фактора рассчитывается наблюдаемый лаг, и весь ряд данных по этому фактору сдвигается вперед на величину этого лага.
    Все оставшиеся пропуски заполняются предыдущим значением.

    Args:
        df (pd.DataFrame): Подневный датафрейм с факторами.
        shift (bool): Флаг сдвига факторов (если False, просто заполняем предыдущим значением).

    Returns:
        pd.DataFrame: Подневный датафрейм с факторами без пропусков (с момента начала данных по факторам).
    """

    df = df.copy()

    if shift:
        # последняя дата с непустым значением для каждого из признаков
        last_date = df['dtdate'].max()
        for col in df.columns:
            actual_date = df.loc[df[col].notna(), 'dtdate'].max()
            lag = (last_date - actual_date).days
            # сдвигаем весь ряд данных вперед на число дней, равное текущему лагу
            df[col] = df[col].shift(lag)

    # замена пропусков предыдущими значениями
    df = df.ffill()

    return df

def convert_obj_to_float(ewi_etc_final_dev: pd.DataFrame, ignore_cols: List[str] = ['dtdate']) -> pd.DataFrame:

    ewi_etc_final_dev = ewi_etc_final_dev.copy()

    obj_cols = ewi_etc_final_dev.select_dtypes(include='object').columns.tolist()
    obj_cols = [col for col in obj_cols if col not in ignore_cols]

    for obj_col in obj_cols:
        ewi_etc_final_dev[obj_col] = pd.to_numeric(ewi_etc_final_dev[obj_col], errors='coerce')

    return ewi_etc_final_dev

def get_weekly_df(
    data_df: pd.DataFrame,
    masterfile: pd.DataFrame,
    holidays_cal: Dict[str, List[str]],
    weekday_n: int = 4,
    use_nowork_data: bool = True
) -> pd.DataFrame:
    """Функция для перехода от подневных данных к понедельным по правилам из мастер-файла.

    Args:
        data_df (pd.DataFrame): Датафрейм, в котором индекс - дата (столбец с названием dtdate).
        masterfile (pd.DataFrame): Мастер-файл.
        holidays_cal (Dict[str, List[str]]): Словарь с данными о выходных днях.
        weekday_n (int, optional): Номер якорного дня недели для недельной агрегации. Defaults to 4 (пятница).
        use_nowork_data (bool, optional): Флаг использования данных о нерабочих днях в соотв. с Указом Президента (реализована поддержка данных https://github.com/d10xa/holidays-calendar). Defaults to True.

    Returns:
        pd.DataFrame: Датафрейм с понедельными данными по факторам.
    """

    if use_nowork_data:
        holidays_list = np.union1d(holidays_cal['holidays'], holidays_cal['nowork'])
    else:
        holidays_list = holidays_cal['holidays']

    averaged_dict = {}
    for factor in data_df.columns:

        if factor not in masterfile['feature'].unique():
            continue

        # все параметры обработки для фактора
        factors_params = masterfile[masterfile['feature'] == factor].to_dict(orient='records')[0]
        calc_method = factors_params['method']
        workdays_only = factors_params['holiday']
        weight_feature = factors_params['weight_feature']

        # нужные файторы - основной фактор и тот, который используется для взвешивания основного
        if isinstance(weight_feature, float) or weight_feature is None:
            # для np.nan
            req_factors = [factor]
        else:
            req_factors = [factor, weight_feature]

        # оставляем нужные факторы и данные о выходных/рабочих днях
        factor_data = data_df[req_factors].copy()

        if workdays_only:
            factor_data.loc[factor_data.index.isin(pd.to_datetime(holidays_list)), req_factors] = None

        # расчет по правилу
        if calc_method == 'last_value':
            factor_averaged = factor_data[factor]
        elif calc_method == 'average':
            factor_averaged = factor_data[factor].rolling(7, min_periods=1).apply(lambda x: np.mean(x)).ffill()
        elif calc_method == 'weighted_average':
            factor_data['mul'] = factor_data[factor] * factor_data[weight_feature]
            factor_averaged = (
                factor_data['mul'].rolling(7, min_periods=1).apply(lambda x: np.sum(x)) \
                / factor_data[weight_feature].rolling(7, min_periods=1).apply(lambda x: np.sum(x))
            ).ffill()

        averaged_dict[factor] = factor_averaged

    # итоговый датафрейм
    averaged_df = pd.DataFrame(averaged_dict)
    averaged_df = averaged_df.reset_index().rename(columns={'dtdate': 'report_date'})
    # берем только нужный день недели
    averaged_df = averaged_df[averaged_df['report_date'].dt.dayofweek == weekday_n].reset_index(drop=True)
    # для пятниц можно вместо этого задать range (для других дней надо делать мэппинг freq и weekday_n) - если в индексе даты
    # pd.date_range(start=averaged_df.index.min(), end=averaged_df.index.max(), freq='W-FRI')

    return averaged_df
