segment_rus_name = {
    'kfl': 'КФЛ',
    'kul': 'КЮЛ',
    'sfl': 'СФЛ',
    'dul': 'ДЮЛ',
    'market': 'Рынок',
    'alm': 'Метрики ALM',
    'total': 'Тотал'
}

# пороги моделей
model_tresholds = {'long_up': 0.47, 'long_down': 0.44, 'short_up': 0.45, 'short_down': 0.45}