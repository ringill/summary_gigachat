from typing import Optional, Dict
import pandas as pd

class SheetsStorage:
    def __init__(self):    
        
        # Фиксированная структура: модели - блоки - листы
        self.models = ['short_up', 'short_down', 'long_up', 'long_down']
        self.blocks = ['kfl', 'kul', 'sfl', 'dul', 'market', 'alm', 'total']
        self.sheets = ['features_info', 'ewi_threshold', 'data_2_modif', 'data_3_signals', 'data_4_signals_decomp', 'data_ewi']
        
        self.data = {m: {b: {s: None for s in self.sheets} for b in self.blocks} for m in self.models}

    def _check_model(self, model: str):
        if model not in self.models:
            return None
        else:
            return model
    
    def _check_block(self, block: str):
        if block not in self.blocks:
            return None
        else:
            return block
        
    def _fill_sheets(self, sheets: Dict[str, Optional[pd.DataFrame]]):
        sheets = sheets.copy()
        # добавляем нужные листы
        for req_sheet in self.sheets:
            if req_sheet not in sheets:
                sheets.update({req_sheet: None})
        # удаляем ненужные
        sheets = {k: sheets[k] for k in sheets if k in self.sheets}
        return sheets
    
    def set_sheets(self, model: str, block: str, sheets: Dict[str, Optional[pd.DataFrame]]):
        model = self._check_model(model)
        block = self._check_block(block)
        sheets = self._fill_sheets(sheets)
        
        if model is not None and block is not None:
            self.data[model][block] = sheets
            
    def get_sheet(self, model: str, block: str, sheet: str):
        return self.data[model][block][sheet]
    
    def get_sheets(self, model: str, block: str):
        return self.data[model][block]
    
    def merge_all_sheets(self) -> Dict[str, pd.DataFrame]:
        
        res = dict(zip(self.sheets, [pd.DataFrame() for _ in self.sheets]))
        
        for model in self.data:
            for block in self.data[model]:
                for sheet in self.data[model][block]:
                    sheet_df = self.data[model][block][sheet]
                    if sheet_df is not None:
                        # добавим ID
                        sheet_df = sheet_df.copy()
                        sheet_df['block'] = block
                        sheet_df['model'] = model
                        
                        # приклеим лист к текущим значениям
                        cur_sheet_df = res[sheet]
                        cur_sheet_df = pd.concat([cur_sheet_df, sheet_df], ignore_index=True)
                        
                        res.update({sheet: cur_sheet_df})
        return res