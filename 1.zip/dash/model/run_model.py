import warnings

import pandas as pd
warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)

import numpy as np
import statsmodels.api as sm

from .model_funcs import MA_I, SD_I, NSD_I, B_I, get_dict_th, get_dict_T
from .report_funcs import get_segment_report
from .model_config import segment_rus_name, model_tresholds
from .report_storage import SheetsStorage


def run_model(
    df_with_features: pd.DataFrame, 
    df_total_info: pd.DataFrame,
    # all_features_info: pd.DataFrame
    ) -> SheetsStorage:
    """Функция для расчета фичей и построения индикаторов для факторов, блоков, моделей.

    Args:
        df_with_features (pd.DataFrame): Датафрейм с факторами в понедельной обработке и фичами типа NEW
        df_total_info (pd.DataFrame): Технический файл

    Returns:
        SheetsStorage: Объект с датафреймом для каждой тройки модель-блок-лист
    """    
    
    # сюда соберем листы-датафреймы
    sheets_storage = SheetsStorage()
    
    
    '''
    тут добавляются ряды для факторов _abs
    '''
    # получаем набор факторов, которые нужно использовать в исходном виде
    abs_factors = df_total_info.loc[
        (df_total_info['type'] == 'new') & (df_total_info['feature'].map(lambda x: str(x).endswith('_abs'))),
        'corresponding_factor'
    ].unique().tolist()
    extra_feat_df = df_with_features[abs_factors].copy()
    extra_feat_df.columns = [col + '_abs' for col in extra_feat_df.columns]

    # отдельно файл important_features не подаем - он уже внутри df_with_features
    # файлы для расчета
    df1 = pd.concat([df_with_features, extra_feat_df], axis=1).drop_duplicates('report_date')
    df1['report_date'] = pd.to_datetime(df1['report_date'])
    df1 = df1.rename(columns={'report_date': 'DATE'}).sort_values('DATE')


    for model in sheets_storage.models:

        #таблицы с техн параметрами
        block_data = df_total_info[~df_total_info['section'].isin(['sfl_model','total_model'])]
        block_data = block_data[block_data['model'] == model]
        # weights = {k: v for k, v in zip(list(block_data.feature_name), list(block_data.weight))}
        weights = dict(zip(list(block_data['feature_name']), list(block_data['weight'])))
        weight_dataset = block_data[['feature_name','weight','section','subsection','feature','info']].drop_duplicates()


        '''
        Расчет
        '''

        new_features = True

        threshold_up_std_T = get_dict_T(block_data, 'up','nstd' )
        threshold_up_reg_T = get_dict_T(block_data, 'up','reg' )
        threshold_down_std_T = get_dict_T(block_data, 'down','nstd' )
        threshold_down_reg_T = get_dict_T(block_data, 'down','reg' )

        threshold_up_std = get_dict_th(block_data, 'up','nstd' )
        threshold_up_reg = get_dict_th(block_data, 'up','reg' )
        threshold_down_std = get_dict_th(block_data, 'down','nstd' )
        threshold_down_reg = get_dict_th(block_data, 'down','reg' )

        arr_down_r = list(threshold_down_reg.keys())
        arr_down_s = list(threshold_down_std.keys())
        arr_up_r = list(threshold_up_reg.keys())
        arr_up_s = list(threshold_up_std.keys())

        std_ind = arr_up_s+arr_down_s
        for i in range(len(std_ind)):
            std_ind[i] = 'IND_'+ std_ind[i]
        reg_ind = arr_up_r+arr_down_r
        for i in range(len(reg_ind)):
            reg_ind[i] = 'IND_'+ reg_ind[i]

        if new_features:
            
            threshold_down_new = get_dict_th(block_data, 'down','new' )
            threshold_up_new = get_dict_th(block_data, 'up','new' )

            arr_down_new = list(threshold_down_new.keys())
            arr_up_new = list(threshold_up_new.keys())

            new_ind = arr_down_new+arr_up_new
            for i in range(len(new_ind)):
                new_ind[i] = 'IND_'+ new_ind[i]

        df_wf = pd.DataFrame.copy(df1)
        df_r = pd.DataFrame.copy(df1)

        for data in threshold_up_reg:
            df_w = pd.DataFrame.copy(df1)
            df_w.dropna(subset=[data], inplace=True)
            T2 = threshold_up_reg_T[data]
            frac = block_data[(block_data['type']=='reg')&(block_data['feature']==data)].frac.values[0] 
            lowess = sm.nonparametric.lowess(list(df_w[data]),[i for i in range(len(df_w))], frac)
            df_w[data + '_LOESS'] =  list(zip(*lowess))[1]
            B_I(T2, data, df_w)
            df_data = df_w[['DATE',data + '_LOESS','B_I_'+data]].copy()
            df_data['IND_'+data]= df_data['B_I_'+data].apply(lambda x: 1 if x >= threshold_up_reg[data]  else 0)
            df_wf = df_wf.merge(df_data,on = 'DATE',how='left')
        for data in threshold_down_reg:
            df_w = pd.DataFrame.copy(df1)
            df_w.dropna(subset=[data], inplace=True)
            T2 = threshold_down_reg_T[data]
            frac = block_data[(block_data['type']=='reg')&(block_data['feature']==data)].frac.values[0] 
            lowess = sm.nonparametric.lowess(list(df_w[data]),[i for i in range(len(df_w))], frac)
            df_w[data + '_LOESS'] =  list(zip(*lowess))[1]
            B_I(T2, data, df_w)
            df_data = df_w[['DATE',data + '_LOESS','B_I_'+data]].copy()
            df_data['IND_'+data]= df_data['B_I_'+data].apply(lambda x: 1 if x <= threshold_down_reg[data]  else 0)
            df_wf = df_wf.merge(df_data,on = 'DATE',how='left')
        for data in threshold_up_std:
            df_w = pd.DataFrame.copy(df1)
            df_w.dropna(subset=[data], inplace=True)
            T = int(threshold_up_std_T[data])
            MA_I(data,T,df_w)   
            SD_I(data, T, df_w )
            NSD_I(data, df_w)
            df_data = df_w[['DATE','MA_I_'+data,'SD_I_'+data,'NSD_I_'+data]].copy()
            df_data['IND_'+data]= df_data['NSD_I_'+data].apply(lambda x: 1 if x >= threshold_up_std[data]  else 0)
            df_r = df_r.merge(df_data,on = 'DATE',how='left')    
        for data in threshold_down_std:
            df_w = pd.DataFrame.copy(df1)
            df_w.dropna(subset=[data], inplace=True)
            T = int(threshold_down_std_T[data])
            MA_I(data,T,df_w)   
            SD_I(data, T, df_w)
            NSD_I(data, df_w)
            df_data = df_w[['DATE','MA_I_'+data,'SD_I_'+data,'NSD_I_'+data]].copy()
            df_data['IND_'+data]= df_data['NSD_I_'+data].apply(lambda x: 1 if x <= threshold_down_std[data] else 0)
            df_r = df_r.merge(df_data,on = 'DATE',how='left')    
        if new_features:
            df_n = pd.DataFrame.copy(df1)
            for data in threshold_up_new:
                df_w = pd.DataFrame.copy(df1)
                df_w.dropna(subset=[data], inplace=True)
                df_data = df_w[['DATE',data]].copy()
                df_data['IND_'+data]= df_data[data].apply(lambda x: 1 if x >= threshold_up_new[data]  else 0)
                df_n = df_n.merge(df_data,on = 'DATE',how='left')
            for data in threshold_down_new:
                df_w = pd.DataFrame.copy(df1)
                df_w.dropna(subset=[data], inplace=True)
                df_data = df_w[['DATE',data]].copy()
                df_data['IND_'+data]= df_data[data].apply(lambda x: 1 if x <= threshold_down_new[data]  else 0)
                df_n = df_n.merge(df_data,on = 'DATE',how='left')    

        df_ind_std = df_r[['DATE']]
        for i in std_ind:
            df_ind_std = pd.merge(df_ind_std,df_r[['DATE',i]],how='left')
        df_ind_std.fillna(value = 0, inplace =True)
        df_ind_reg = df_wf[['DATE']]
        for i in reg_ind:
            df_ind_reg = pd.merge(df_ind_reg,df_wf[['DATE',i]],how='left')
        df_ind_reg.fillna(value = 0, inplace =True)
        reg_features = df_ind_reg.columns[1:].to_list()
        std_features = df_ind_std.columns[1:].to_list()
        features = list(set(std_features + reg_features))
        if new_features:
            df_ind_new = df_n[['DATE']]
            for i in new_ind:
                df_ind_new = pd.merge(df_ind_new,df_n[['DATE',i]],how='left')
            df_ind_new.fillna(value = 0, inplace =True)
            new_features = df_ind_new.columns[1:].to_list()
            features = list(set(std_features + reg_features + new_features))

        df_ind_rez =  pd.DataFrame(columns=[*features], index = [*df1.DATE.values]).reset_index().rename(columns={'index':'DATE'}).sort_values('DATE').reset_index(drop=True)
        for col in df_ind_rez.columns:
            if col != 'DATE':
                df_ind_rez[col] = 0
        for data in df_ind_std[std_ind]:
            if data in df_ind_reg[reg_ind]:
                df_ind_rez[data] = np.logical_or(df_ind_reg[data],df_ind_std[data])        
                # df_ind_rez[data] = df_ind_rez[data].apply(lambda x:int(x))
            else:
                df_ind_rez[data] = df_ind_std[data].apply(lambda x:int(x))
        logic_or_for_new_features = False
        if new_features:
            if logic_or_for_new_features:    
            ## планируется рассмотреть ТОЛЬКО эту 'фичу' в дизъюнкции
            ## Тимофей, если используешь - протестируй
                for data in df_ind_new[new_ind]:
                    if data in df_ind_rez[reg_ind+std_ind]:
                        df_ind_rez[data] = np.logical_or(df_ind_new[data],df_ind_rez[data])
            ## планируется рассмотреть ТОЛЬКО эту 'фичу'
            for data in df_ind_new[new_ind]:
                df_ind_rez[data] = df_ind_new[data].apply(lambda x:int(x))

        # TODO здесь вылезает PerformanceWarning. Было бы хорошо перейти к векторным вычислениям или хотя бы собирать список, а потом уже делать из него датафрейм
        # PerformanceWarning: DataFrame is highly fragmented.  This is usually the result of calling `frame.insert` many times, which has poor performance.  Consider joining all columns at once using pd.concat(axis=1) instead. To get a de-fragmented frame, use `newframe = frame.copy()`
        df_ind_reg_work = pd.DataFrame.copy(df_ind_rez)
        for data in weight_dataset.feature_name:
            df_ind_reg_work[data] = weights[data]*df_ind_reg_work[data]
        for sect in weight_dataset.section:
            if sect!= 'sfl':
                df_ind_reg_work[str(sect)+'_total']=df_ind_reg_work[list(weight_dataset[weight_dataset.section==sect].feature_name)].sum(axis = 1)
            else:
                for subsect in weight_dataset.subsection:
                    df_ind_reg_work[str(subsect)+'_total']=df_ind_reg_work[list(weight_dataset[weight_dataset.subsection==subsect].feature_name)].sum(axis = 1)

        # sfl-params
        all_about_sfl = df_total_info[(df_total_info['model'] == model)&(df_total_info['section'] == 'sfl_model')]
        # df_names_dict_sfl = all_about_sfl [['feature_name','info']]
        tresholds_sfl = {k: v for k, v in zip(list(all_about_sfl['segment']), list(all_about_sfl['treshold']))}
        names_dict_sfl = {k: v for k, v in zip(list(all_about_sfl['feature_name']), list(all_about_sfl['info']))}
        weightsfl = {k: v for k, v in zip(list(all_about_sfl['feature_name']), list(all_about_sfl['weight']))}
        # df_tresholds_sfl =all_about_sfl[['segment','treshold','feature_name']]
        # df_weightsfl=all_about_sfl[['feature_name','weight']]
        # df_names_dict_sfl = all_about_sfl[['feature_name','info']]
        # total-params
        model_params = df_total_info[(df_total_info['model'] == model)&(df_total_info['section'] == 'total_model')]
        # demo_dict = {k: v for k, v in zip(list(model_params['block']), list(model_params['info']))}
        weight = {k: v for k, v in zip(list(model_params['feature']), list(model_params['weight']))}
        tresholds= {k: v for k, v in zip(list(model_params['feature_name']), list(model_params['treshold']))}

        res = df_ind_reg_work.copy()
        for data in tresholds_sfl.keys():
            if data != 'share_vfl':
                res['IND_'+data]= res[data].apply(lambda x: 1 if x >= tresholds_sfl[data]  else 0)
        for data in weightsfl.keys():
            res[data] = weightsfl[data]*res[data]
        res['sfl_total'] = res[list(weightsfl.keys())].sum(axis = 1)
        for data in tresholds.keys():
            res['IND_'+data]= res[data].apply(lambda x: 1 if x >= tresholds[data]  else 0)
        res = res.merge(df1[['DATE']])
        if model != 'short_down' and  model != 'short_up':
            res = res.merge(df_r[['DATE','NSD_I_share_vfl']].rename(columns={'NSD_I_share_vfl':'share_vfl'}), how='left')

        df_ind_reg_work = pd.DataFrame.copy(res)
        features = ['IND_kfl_total',
                        'IND_kul_total',
                        'IND_dul_total',
                        'IND_market_total',
                        'IND_sfl_total',
                        'IND_alm_total',
                            ]
        for data in df_ind_reg_work[features]:
            df_ind_reg_work[data] = weight[data]*df_ind_reg_work[data]
            
        df_ind_reg_work['total']=df_ind_reg_work[features].sum(axis = 1)
        df_ind_reg_work['DATE'] = pd.to_datetime(df_ind_reg_work['DATE'])
        df_w['DATE'] = pd.to_datetime(df_w['DATE'])

        df_ind_reg_work = df_ind_reg_work.merge(df_w,on = 'DATE',how='left')

        # df_names_total = model_params[['feature','info']].rename(columns={'feature':'feature_name'})
        df_features_info = model_params[['feature','weight','info']].rename(columns={'feature':'feature_name'})

        tresholds_df = pd.DataFrame([tresholds]).T.reset_index().rename(columns={0:'treshold', 'index':'segment'})
        tresholds_df['feature_name'] = 'IND_'+tresholds_df['segment']
        df_features_info_total= df_features_info.merge(tresholds_df)

        df_ind_reg_work = df_ind_reg_work.merge(df1[['DATE']])
        
        for col in df_n:
            if col[-2:]=='_x':
                df_n=df_n.rename(columns={col : col[:-2]})


        model_params = df_total_info[(df_total_info['model'] == model)&(df_total_info['section'] == 'total_model')]
        tresholds = {k: v for k, v in zip(list(model_params['feature_name']), list(model_params['treshold']))}
        all_about_sfl = df_total_info[(df_total_info['model'] == model)&(df_total_info['section'] == 'sfl_model')]
        df_features_info_total = model_params[['feature','weight','info','feature_name','treshold']].rename(columns={'feature_name':'segment', 'feature':'feature_name'})
        
        
        for segment in sheets_storage.blocks:
                
            segment_report = get_segment_report(
                model=model,
                segment=segment,
                segment_name=segment_rus_name[segment],
                total_treshold=model_tresholds[model], 
                tresholds=tresholds, 
                df_total_info=df_total_info,
                df_wf=df_wf,
                df_r=df_r,
                df_n=df_n,
                df_ind_reg_work=df_ind_reg_work,
                res=res,
                all_about_sfl=all_about_sfl,
                names_dict_sfl=names_dict_sfl,
                df_features_info_total=df_features_info_total
            )
            # запишем листы в хранилище
            sheets_storage.set_sheets(model=model, block=segment, sheets=segment_report)
            
    return sheets_storage