import pandas as pd


def prep_daily_factors_data(ewi_etc_final_dev: pd.DataFrame) -> pd.DataFrame:
    """Подготовка таблицы с факторами для работы. Возможно, при загрузке из БД потребуются дополнительные шаги.

    Args:
        ewi_etc_final_dev (pd.DataFrame): Датафрейм с факторами - срез витрины.

    Returns:
        pd.DataFrame: Датафрейм с факторами - срез витрины.
    """
    ewi_etc_final_dev = ewi_etc_final_dev.copy()
    ewi_etc_final_dev["dtdate"] = pd.to_datetime(ewi_etc_final_dev["dtdate"])
    ewi_etc_final_dev = ewi_etc_final_dev.drop_duplicates().sort_values('dtdate') # на всякий случай проверяем дубли
    ewi_etc_final_dev['dw'] = ewi_etc_final_dev["dtdate"].dt.dayofweek
    # переводим в нижний регистр названия факторов, возможно, сейчас это лишнее   
    ewi_etc_final_dev.columns = [col.lower() for col in ewi_etc_final_dev.columns]
    # удаляем лишние технические колонки (может понадобится что-то добавить/убрать)
    ewi_etc_final_dev.drop(columns={'calc_date', 'calc_timestamp'}, inplace=True)
    return ewi_etc_final_dev

def prep_master_data(factors_add_info: pd.DataFrame) -> pd.DataFrame:
    """Подготовка мастер-файла для работы. Возможно, при загрузке из БД потребуются дополнительные шаги.

    Args:
        factors_add_info (pd.DataFrame): Датафрейм с данными мастер-файла.

    Returns:
        pd.DataFrame: Датафрейм с данными мастер-файла.
    """
    factors_add_info = factors_add_info.copy()
    factors_add_info = factors_add_info.rename(
        columns={
            'Фактор': 'feature',
            'Способ недельного усреднения': 'method',
            'Брать только рабочие дни': 'holiday',
            'Взвешивать по полю': 'weight_feature'
        }
    )
    factors_add_info['feature'] = factors_add_info['feature'].str.lower()
    factors_add_info['method'] = factors_add_info['method'].map({
        'Простое среднее': 'average',
        'Средневзвешенное': 'weighted_average',
        'Последнее доступное значение': 'last_value'
    })
    return factors_add_info

# def prep_holidays_data(holidays: pd.DataFrame) -> pd.DataFrame:
#     """Подготовка данных по выходным дням для работы. Возможно, при загрузке из БД потребуются дополнительные шаги.

#     Args:
#         holidays (pd.DataFrame): Датафрейм с датами и флагом выходного дня.

#     Returns:
#         pd.DataFrame: Датафрейм с датами и флагом выходного дня.
#     """
#     holidays = holidays.copy()
#     holidays['date'] = pd.to_datetime(holidays['date'])
#     holidays = holidays.rename(columns={'date': 'dtdate'})  
#     return holidays