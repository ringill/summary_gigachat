import pandas as pd
import numpy as np

from typing import Dict, List

from .dataset_funcs import calc_new_features, make_date_range, rearrange_df_uni, move_column, fill_missings, convert_obj_to_float, get_weekly_df
from .data_preprocessing import prep_daily_factors_data, prep_master_data


def prepare_dataset(
    ewi_etc_final_dev: pd.DataFrame,
    factors_add_info: pd.DataFrame,
    holidays: Dict[str, List[str]],
    techfile: pd.DataFrame,
    last_date: str = 'friday', # or 'today' or str(int)
    keep_all_factors: bool = False, # если True, оставляет все факторы витрины; иначе только используемые в модели
) -> Dict[str, pd.DataFrame]:
    """Перевод в понедельные данные.

    Args:
        ewi_etc_final_dev (pd.DataFrame): Датафрейм с факторами - срез витрины.
        factors_add_info (pd.DataFrame): Датафрейм с данными мастер-файла.
        holidays (Dict[str, List[str]]): Словарь с данными о выходных днях.
        techfile (pd.DataFrame): Датафрейм с данными параметров расчета.
        last_date (str, optional): {'friday', 'today', str(int)}: тип конечной даты: ближайшая пятница, текущая дата или несколько дней вперед - можно указать любое целое число). Defaults to 'friday'.

    Returns:
        Dict[str, pd.DataFrame]: Словарь с данными: недельные факторы и фичи типа NEW для модели, недельные факторы с применением и без применения лага для загрузки в Навигатор.
    """
    
    ewi_etc_final_dev = prep_daily_factors_data(ewi_etc_final_dev)
    factors_add_info = prep_master_data(factors_add_info)
    # предобработка не планируется - часть сборки модели
    holidays = holidays.copy()
    techfile = techfile.copy()

    if not keep_all_factors:
        # Оставляем только те факторы, которые присутствуют в модели
        req_factors_1 = techfile['corresponding_factor'].fillna(techfile['original_name']).dropna().unique().tolist()
        req_factors_2 = factors_add_info['weight_feature'].dropna().unique().tolist()
        required_factors = np.union1d(req_factors_1, req_factors_2)
        ewi_etc_final_dev = ewi_etc_final_dev[['dtdate'] + list(required_factors)].copy()

    date_range = make_date_range(ewi_etc_final_dev, last_date=last_date)
    # Получаем отсюда номер дня недели для недельной агрегации
    weekday_n = date_range.dt.dayofweek.values[-1]

    # Дополнили датафрейм так, чтобы был весь набор дат
    ewi_etc_final_dev = ewi_etc_final_dev.merge(date_range, how='right')
    # Добавляем данные о выходных днях - пропуски в данных о выходных не предполагаются (а они есть!!!)
    # ewi_etc_final_dev = ewi_etc_final_dev.merge(holidays, how='left')
    
    # Исправляем ошибки формата - если числа в строковом типе
    ewi_etc_final_dev = convert_obj_to_float(ewi_etc_final_dev)

    # Заполняем пропуски в данных
    ewi_etc_final_dev_no_lag = fill_missings(df=ewi_etc_final_dev, shift=False)
    ewi_etc_final_dev = fill_missings(df=ewi_etc_final_dev)
    
    # Переход к недельным данным
    aggr_res = get_weekly_df(
        data_df=ewi_etc_final_dev.set_index('dtdate'), 
        masterfile=factors_add_info, 
        holidays_cal=holidays,
        weekday_n=weekday_n
    )
    # Переход к недельным данным (без применения алгоритма со сдвигом данных)
    aggr_res_no_lag = get_weekly_df(
        data_df=ewi_etc_final_dev_no_lag.set_index('dtdate'), 
        masterfile=factors_add_info, 
        holidays_cal=holidays,
        weekday_n=weekday_n
    )

    # заменяем бесконечности, получившиеся в результате деления на 0, нулями
    aggr_res = aggr_res.replace([np.inf, -np.inf], 0)
    
    # Расчет фичей с типом NEW - можно перенести в скрипт для прогона модели
    df_important_features = calc_new_features(df_with_features=aggr_res, techfile=techfile)

    # Собираем итоговый фрейм из факторов и фичей с типом NEW
    factors_df = pd.merge(
        aggr_res,
        df_important_features,
        on='report_date',
        how='left'
    )

    # Ниже подготовка к сохранению (+ еще ограничение по дате снизу)
    # создаём файл-отчёт по текущим данным для коллег (c лагами и без)       
    data_1_agg = rearrange_df_uni(
        aggr_res, 
        index_colnames=['report_date'],
        new_desc_colname='factor_origin', 
        new_value_colname='Value'
    )
    data_1_agg['report_date'] = pd.to_datetime(data_1_agg['report_date'])
    data_1_agg_no_lag = rearrange_df_uni(
        aggr_res_no_lag, 
        index_colnames=['report_date'],
        new_desc_colname='factor_origin', 
        new_value_colname='Value'
    )
    data_1_agg_no_lag['report_date'] = pd.to_datetime(data_1_agg_no_lag['report_date'])
    
    # для удобства дату сдвинем в начало
    factors_df = move_column(factors_df, 'report_date', to_position=0)

    all_data = dict(factors_df=factors_df, lag_df=data_1_agg, nolag_df=data_1_agg_no_lag)
    
    return all_data    