import pandas as pd
from typing import List
from utils import edit_column_set

def fasttrack_make_joint_rec_table(data_ewi: pd.DataFrame, data_ewi_archive: pd.DataFrame) -> pd.DataFrame: 
    """Создание таблицы с рекомендациями текущего запуска модели и архивными значениями.

    Args:
        data_ewi (pd.DataFrame): Рекомендации текущего запуска модели
        data_ewi_archive (pd.DataFrame): Архив рекомендаций модели

    Returns:
        pd.DataFrame: Таблица с архивными и текущими рекомендациями
    """
    
    data_ewi_tbl = data_ewi.loc[data_ewi["block"] == "total"]
    data_ewi_tbl = data_ewi_tbl.drop(columns=["block", "ewi"])
    data_ewi_tbl["report_date"] = pd.to_datetime(data_ewi_tbl["report_date"])
    
    data_ewi_archive = data_ewi_archive.drop(columns=["ewi"])
    
    data_ewi_tbl["version"] = "Текущий расчет"
    data_ewi_archive["version"] = "Расчет на дату"
    
    joint_tbl = pd.concat([data_ewi_tbl, data_ewi_archive], axis=0)
    
    return joint_tbl
    
def fasttrack_make_signals_table(joint_tbl: pd.DataFrame, n_weeks: int = 4):
    
    date_vals = sorted(joint_tbl.loc[joint_tbl["version"] == "Текущий расчет", "report_date"].unique())[-n_weeks:]
    joint_tbl = joint_tbl.loc[joint_tbl["report_date"].isin(date_vals)].copy()
    joint_tbl = joint_tbl.sort_values("report_date", ascending=False)
    joint_tbl["report_date"] = joint_tbl["report_date"].astype(str)
    
    joint_tbl = joint_tbl.pivot_table(
        index=["model", "version"],
        columns="report_date",
        values="signal",
        sort=False
    ).reset_index()
    
    # joint_tbl = joint_tbl.sort_values(by=["model", "version"])
    
    return joint_tbl

def fasttrack_make_joint_blocks_table(data_ewi: pd.DataFrame, blocks_ewi_archive: pd.DataFrame) -> pd.DataFrame: 
    """Создание таблицы с рекомендациями текущего запуска модели и архивными значениями по блокам.

    Args:
        data_ewi (pd.DataFrame): Рекомендации текущего запуска модели по блокам
        blocks_ewi_archive (pd.DataFrame): Архив рекомендаций модели по блокам

    Returns:
        pd.DataFrame: Таблица с архивными и текущими рекомендациями по блокам
    """
    
    blocks_ewi_archive = blocks_ewi_archive.copy()
    data_ewi = data_ewi.copy()
    
    blocks_ewi_archive["block"] = blocks_ewi_archive["factor"].map(lambda x: x.replace("_total", ""))
    blocks_ewi_archive = blocks_ewi_archive.rename(columns={'Signal': 'signal_arch'})
    
    data_ewi["report_date"] = pd.to_datetime(data_ewi["report_date"])
    data_ewi = data_ewi.rename(columns={'ewi': 'ewi_act', 'signal': 'signal_act'})
    
    comb_ewi_df = pd.merge(
        blocks_ewi_archive,
        data_ewi,
        on=["report_date", "model", "block"],
        how='outer'
    )
    
    # пометки разных сигналов
    comb_ewi_df["signal_disappeared"] = 0
    comb_ewi_df.loc[(comb_ewi_df["signal_arch"] == 1) & ((comb_ewi_df["signal_act"] == 0)), "signal_disappeared"] = 1

    comb_ewi_df["signal_appeared"] = 0
    comb_ewi_df.loc[(comb_ewi_df["signal_arch"] == 0) & ((comb_ewi_df["signal_act"] == 1)), "signal_appeared"] = 1
    
    return comb_ewi_df

def fasttrack_make_restricted_blocks_table(comb_ewi_df: pd.DataFrame, model: str, all_dates: list, n_weeks: int = 10):
    
    date_vals = sorted(all_dates)[-n_weeks:]
    
    # оставим только выбранную модель
    model_df = comb_ewi_df.loc[(comb_ewi_df['model'] == model) & (comb_ewi_df['block'] != 'total')].copy()
    model_df = model_df.loc[model_df["report_date"].isin(date_vals)]
    
    return model_df
    
def fasttrack_rec_table_columnDefs(signals_tbl_columns: List[str], first_order_version: str):
        
    assert all([x in signals_tbl_columns for x in ["model", "version"]])

    columnDefs = [
        {
            "headerName": "model", 
            "field": "model", 
            "width": 110, 
            "pinned": "left", 
            "rowSpan": {"function": f"params.data.version === '{first_order_version}' ? 2 : 1"},
            "cellClassRules": {
                "spanned-row": "params.value",
            },
            "headerClass": "center-aligned-header",
            "cellStyle": {
                "display": "flex",
                "justifyContent": "center",
                "alignItems": "center",
                "textAlign": "center"
            },
        }, 
        {
            "headerName": "version", 
            "field": "version", 
            "width": 120, 
            "pinned": "left",
            "sortable": False,
            "headerClass": "center-aligned-header",
            "cellStyle": {
                "display": "flex",
                "justifyContent": "center",
                "alignItems": "center",
                "textAlign": "center"
            },
        },
    ]
    for col in signals_tbl_columns[2:]:
        columnDefs.append({
            "headerName": col, 
            "field": col, 
            "width": 110,
            "cellRenderer": "SignalRenderer",
            "cellStyle": {
                "display": "flex",
                "justifyContent": "center",
                "alignItems": "center",
                "textAlign": "center"
            },
            "headerClass": "center-aligned-header",
            "sortable": False,
        })
        
    return columnDefs

def fasttrack_dedata_table_columnDefs(daily_df: pd.DataFrame):
    
    largeNumberFormatting = "params.value == null ? params.value : Math.round(params.value).toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ' ')"
    smallNumberFormatting = "params.value == null ? params.value : params.value.toFixed(2)"
    
    columnDefs = []
    for col in daily_df.columns:
        if pd.api.types.is_numeric_dtype(daily_df[col]):
            max_val = daily_df[col].abs().max()
            fmt = largeNumberFormatting if max_val >= 1_000 else smallNumberFormatting
            columnDefs.append({
                "headerName": col, 
                "field": col,
                "valueFormatter": {
                    "function": fmt
                }
            })
        else:
            columnDefs.append({
                "headerName": col, 
                "field": col,
            })
    
    # добавляем пин
    edit_column_set(
        columnDefs,
        {
            "field": 'dtdate',
            "pinned": True,
            "filter": "agDateColumnFilter"
        },
        mode = 'add'
    )
    
    return columnDefs