from flask import has_app_context
import numpy as np
import pandas as pd
import logging
from typing import Optional

import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.colors as colors

from dash import dash_table
from dash.dash_table.Format import Format, Align, Scheme
import dash_ag_grid as dag




from KP.Model_analysis.prepare_data_v2 import make_target, find_features_types, find_features_levels, find_features_directions
from KP.Model_analysis.validation_v2 import get_runs
from KP.common.graphs import plt_add_target_windows

# Мои модули
from data_preparation_RUB import (
    Trigger,
    Get_Recomend_df,
    Factor_Value_desc
)

from visual_settings import (
    Color_ETC_Up,
    Color_ETC_Down,
    Color_Red_Level,
    Color_Yellow_Level,
    Color_Green_Level,
    Color_Factor,
    level_desc,
    level_desc_num,
    reaction_desc,
    reaction_column,
    column_text,
    reaction_desc_num
)

from data_preparation_Model_Analize import (
    Model_Analysis
)


from dash_load_data import (
    DE_files_date_fields
)


from utils import *

# Убираем прямое создание экземпляра Model_Analysis
_model_current = None

def get_model_current():
    global _model_current
    if _model_current is None:
        # Проверяем, что мы в контексте приложения Dash
        if not has_app_context():
            raise RuntimeError("Model must be initialized in app context")
        # создаем экземпляр Model_Analysis
        _model_current = Model_Analysis()

    return _model_current

block_converter = {"Рынок": "MARKET",
                   "КЮЛ": "KUL",
                   "КФЛ": "KFL",
                   "СФЛ": "SFL",
                   "ДЮЛ": "DUL",
                   "Метрики ALM": "ALM"}

block_desc = {  "MARKET": "Рынок",
                "KUL":"КЮЛ" ,
                "KFL":   "КФЛ" ,
                "SFL":"СФЛ",
                "DUL":"ДЮЛ",
                "ALM":"Метрики ALM"}



model_desc = {"short_up": "Поднятие короткого конца",
              "long_up": "Поднятие длинного конца",
              "short_down": "Снижение короткого конца",
              "long_down": "Снижение длинного конца",}




# Основной график на первой закладке Триггер
def Main_Hist_Graph(Switch_Treshold = False,
                    Switch_Agr = True,
                    filter_factor = False,
                    Switch_ЕТС_hist = True,
                    RI_ftp_curve_part = 'short',
                    Switch_Sum = False, # суммирование рекомендаций
                    Range_start_date  = Trigger.Hist_Start_date,
                    Range_end_date = Trigger.Hist_Last_date
                    ):

    # список факторов, по которым строим
    if filter_factor:
        list_of_factors = [filter_factor]
    else:
        list_of_factors =Trigger.Factor_list


    # График с историей изменения ЕСТ и кумулитивным итогом
    fig = go.Figure()
    df = Trigger.df_FTP_Hist_Trigger_Date
    df = df.loc[(df.index >= Range_start_date) & (df.index <= Range_end_date)]

    x_data =df.index.get_level_values(0)

    fig = make_subplots(specs=[[{"secondary_y": True}]])


    # ------------- Текст для подписи на изменениея ЕТС -------------
    ETC_text_Up = []
    ETC_text_Down = []

    for index, row in df.iterrows():

        # Текст про повышение
        if row['up_value'] > 0:
            text_Up = ('<b>Повышение</b><br><br>' +
                        'Дата: {Date_Friday:%d-%m-%Y}<br>' +
                         'Вся кривая: {ETC_Hist_Up:0,.2f}<br>' +
                         '  Короткие: {ETC_Hist_Up_Short:0,.2f}<br>' +
                         '  Длинные: {ETC_Hist_Up_Long:0,.2f}<br>').format(
            Date_Friday=index,
            ETC_Hist_Down=row['down_value'],
            ETC_Hist_Up=row['up_value'],
            ETC_Hist_Down_Short=row['short_down_value'],
            ETC_Hist_Up_Short=row['short_up_value'],
            ETC_Hist_Down_Long=row['long_down_value'],
            ETC_Hist_Up_Long=row['long_up_value'])

        else:
            text_Up = ""

        ETC_text_Up.append(text_Up)


        # Текст про снижение
        if row['down_value'] < 0:
            text_Down = ('<b>Снижение</b><br><br>' +
                       'Дата: {Date_Friday:%d-%m-%Y}<br>' +
                       'Вся кривая: {ETC_Hist_Down:0,.2f}<br>' +
                       '  Короткие: {ETC_Hist_Down_Short:0,.2f}<br>' +
                       '  Длинные: {ETC_Hist_Down_Long:0,.2f}<br>').format(
                Date_Friday=index,
                ETC_Hist_Down=row['down_value'],
                ETC_Hist_Up=row['up_value'],
                ETC_Hist_Down_Short=row['short_down_value'],
                ETC_Hist_Up_Short=row['short_up_value'],
                ETC_Hist_Down_Long=row['long_down_value'],
                ETC_Hist_Up_Long=row['long_up_value'])

        else:
            text_Down = ""

        ETC_text_Down.append(text_Down)


    df['ETC_text_Up'] = ETC_text_Up
    df['ETC_text_Down'] = ETC_text_Down




    # ------------- История ЕТС -------------
    if Switch_ЕТС_hist:

        ETC_Hist_Columns_Down = {'short':'short_down_value',
                                 'long': 'long_down_value',
                                 'all': 'down_value',
                                 }

        ETC_Hist_Columns_Up = {'short':'short_up_value',
                                 'long': 'long_up_value',
                                 'all': 'up_value',
                                 }

        fig.add_trace(go.Scatter(x=x_data,
                                 # y=df['ETC_Hist_Down'],
                                 y=df[ETC_Hist_Columns_Down[RI_ftp_curve_part]],
                                 mode='none',
                                 name='Факт (снижение)',
                                 fill='tozeroy',
                                 #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                 line_shape='linear',
                                 fillcolor='#2CA02C',
                                 text = df['ETC_text_Down'],
                                 hovertemplate="%{text} <extra></extra> ",
                                 ),
                      secondary_y=True
                      )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

        fig.add_trace(go.Scatter(x=x_data,
                                 # y=df['ETC_Hist_Up'],
                                 y=df[ETC_Hist_Columns_Up[RI_ftp_curve_part]],
                                 mode='none',
                                 name='Факт (повышение)',
                                 fill='tozeroy',
                                 #  line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                 line_shape='linear',
                                 fillcolor='#FF7F0E',
                                 text=df['ETC_text_Up'],
                                 hovertemplate="%{text} <extra></extra> ",
                                 ),
                      secondary_y=True
                      )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'


    # # Switch_ЕТС_hist_noChange:
    # if True:
    #     ETC_Hist_Columns_noChange_Down = {'Short': 'Down_Min_Short',
    #                                       'Long': 'Down_Min_Long',
    #                                       'All': 'Down_Min',
    #                                      }
    #
    #     ETC_Hist_Columns_noChange_Up = {'Short': 'Up_Max_Short',
    #                                     'Long': 'Up_Max_Long',
    #                                     'All': 'Up_Max',
    #                                    }
    #
    #     df_noChange = Trigger.df_FTP_Hist_noChange
    #     x_data_noChange = df_noChange['StartDate_Friday']
    #
    #
    #     fig.add_trace(go.Scatter(x=x_data_noChange,
    #                              y=df_noChange[ETC_Hist_Columns_noChange_Down[RI_ftp_curve_part]],
    #                              mode='lines',
    #                              name='Факт (повышение)',
    #                              fill='tozeroy',
    #                              line=dict( color='rgba(44,160,44,1)'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
    #                              line_shape='linear',
    #                              fillcolor='rgba(44,160,44,0.2)',
    #                              text=df['ETC_text_Up'],
    #                              hovertemplate="%{text} <extra></extra> ",
    #                              ),
    #                   secondary_y=True
    #                   )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'
    #
    #     fig.add_trace(go.Scatter(x=x_data_noChange,
    #                              y=df_noChange[ETC_Hist_Columns_noChange_Up[RI_ftp_curve_part]],
    #                              mode='lines',
    #                              name='Факт (повышение)',
    #                              fill='tozeroy',
    #                              line=dict( color='rgba(255,127,14,1)'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
    #                              line_shape='linear',
    #                              # fillcolor='rgba(255,127,14,0.2)',
    #                              text=df['ETC_text_Up'],
    #                              hovertemplate="%{text} <extra></extra> ",
    #                              ),
    #                   secondary_y=True
    #                   )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'




    # ------ График факторов ------

    # Определяем какой конец нам интересен
    df_Up,df_Down = Get_Recomend_df(RI_ftp_curve_part)

    df_Up = df_Up.loc[(df_Up.index >= Range_start_date) & (df_Up.index <= Range_end_date)]
    df_Down = df_Down.loc[(df_Down.index >= Range_start_date) & (df_Down.index <= Range_end_date)]

    # Считаем сумму рекомендаций
    df_Down_sum = df_Down.sum(axis=1)
    df_Up_sum = df_Up.sum(axis=1)

    # Считаем границы для каждой рекомендации
    Up_sum_min = df_Up_sum.min()
    Up_sum_max = df_Up_sum.max()

    Down_sum_min = df_Down_sum.min()
    Down_sum_max = df_Down_sum.max()

    # Парамметры нормализации
    norm_min = 1
    norm_max = 30

    # df c порогами
    df_Treshold = Trigger.df_Treshold



    # df_Up_sum   =  (df_Up_sum - Up_sum_min)     / (Up_sum_max - Up_sum_min)    * (norm_max - norm_min) + norm_min
    # df_Down_sum = (df_Down_sum - Down_sum_min) / (Down_sum_max - Down_sum_min) * (norm_max - norm_min) + (-1) * norm_max


    # Включена агрегация
    if Switch_Agr:

        # Включено суммирование
        if Switch_Sum:

            df_graph = df_Down_sum + df_Up_sum

            # Включены пороги
            if Switch_Treshold:
                # Определяем границы
                treshold_up   = df_graph.loc[df_graph > 0].quantile(0.9)
                treshold_down = df_graph.loc[df_graph < 0].quantile(0.1)

                # обреза лишне
                df_graph.loc[(df_graph >= treshold_down) & (df_graph <= treshold_up)] = 0

            # Формируем текст подписие
            Agr_Feature_text = []
            for index, value in df_graph.items():
                text = f'Дата: <b>{index:%d-%m-%Y}</b><br>'
                text += f'<br><b>Рекомендация</b> {value:.2}<br>'
                Agr_Feature_text.append(text)

            #  Агрегация факторов
            fig.add_trace(go.Scatter(x=x_data,
                                     y=df_graph,
                                     mode='none',
                                     name='Рекомендация',
                                     fill='tonexty',
                                     #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                     line_shape='linear',
                                     fillcolor=colors.qualitative.G10[0],
                                     stackgroup='one',
                                     hoverinfo='y',
                                     text=Agr_Feature_text,
                                     hovertemplate="%{text} <extra></extra> "
                                     ),
                          )



        # Выключено суммирование
        else:

            # Включены пороги
            if Switch_Treshold:
                # Определяем границы RI_ftp_curve_part
                treshold_up =    float(df_Treshold.loc[(df_Treshold['model'] == RI_ftp_curve_part+'_up') & (df_Treshold['ewi_labels'] == 'red'),'ewi_threshold_val'])
                treshold_down = -float(df_Treshold.loc[(df_Treshold['model'] == RI_ftp_curve_part+'_down') & (df_Treshold['ewi_labels'] == 'red'),'ewi_threshold_val'])

                # обреза лишне
                df_Up_sum.loc[df_Up_sum < treshold_up] = 0
                df_Down_sum.loc[df_Down_sum > treshold_down] = 0


            #  Сумма Up
            # Формируем текст подписие
            Agr_Feature_text = []
            for index, value in df_Up_sum.items():
                text = f'Дата: <b>{index:%d-%m-%Y}</b><br>'
                text += f'<br><b>Повышение</b> {value:.2}<br>'
                Agr_Feature_text.append(text)



            fig.add_trace(go.Scatter(x=x_data,
                                     y=df_Up_sum,
                                     mode='none',
                                     name='Рекомендация поднятия',
                                     fill='tozeroy',
                                     #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                     line_shape='linear',
                                     fillcolor=colors.qualitative.G10[0],
                                     # stackgroup='one',
                                     hoverinfo='y',
                                     text=Agr_Feature_text,
                                     hovertemplate="%{text} <extra></extra> "
                                     ),
                          )

            #  Сумма Down
            # Формируем текст подписие
            Agr_Feature_text = []
            for index, value in df_Down_sum.items():
                text = f'Дата: <b>{index:%d-%m-%Y}</b><br>'
                text += f'<br><b> Снижение </b> {value:.2}<br>'
                Agr_Feature_text.append(text)

            fig.add_trace(go.Scatter(x=x_data,
                                     y=df_Down_sum,
                                     mode='none',
                                     name='Рекомендация снижения',
                                     fill='tozeroy',
                                     #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                     line_shape='linear',
                                     fillcolor=colors.qualitative.G10[0],
                                     # stackgroup='one',
                                     hoverinfo='y',
                                     text=Agr_Feature_text,
                                     hovertemplate="%{text} <extra></extra> "
                                     ),
                          )

    # Каждый фактор отдельно
    else:
        df_curve = df_Up.merge(df_Down, left_index=True, right_index=True)

        # Формируем текст подписие
        Factor_text = []

        # Формируем текст подписие
        Factor_text = []
        for index, row in df_curve.iterrows():
            text = 'Дата: <b>{Date_Friday:%d-%m-%Y}</b><br>'.format(Date_Friday=index)

            text_Up = '<br><b>Повышение</b><br>'
            text_Downp = '<br><b>Снижение</b><br>'
            for feature in row.index:
                if row[feature] > 0:
                    text_Up += feature + '<br>'

                if row[feature] < 0:
                    text_Downp += feature + '<br>'

            text = text + text_Up + text_Downp

            Factor_text.append(text)

        df_curve['Factor_text'] = Factor_text



        # =================== Разрез по факторам ====================
        for f_name in df_curve.columns:
            fig.add_trace(go.Scatter(x=x_data,
                                     y=df_curve[f_name],
                                     mode='none',
                                     # name=Trigger.df_Factor_Set.loc[f_name]['factor_desc'],

                                     name=f_name,
                                     fill='tonexty',
                                     #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                                     line_shape='linear',
                                     #                       #   fillcolor = '#2CA02C'
                                     stackgroup='one',
                                     #     hoverinfo = 'y',
                                     text=df_curve['Factor_text'],
                                     hovertemplate="%{text} <extra></extra> "
                                     ),
                          )

    graph_title = "Факторы изменения ЕТС (USD): Факт vs Рекомендация"
    fig.update_layout(  # title=graph_title,

        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False, gridcolor = 'grey',
                   # dtick = 'M1', ticklabelmode = "period",
                   # rangeslider_visible = True
                   # mirror = dict(ticks = "inside", showgrid = False, ticklen = 4, griddash = 'dot', gridcolor = 'white')
                   ),
        yaxis=dict(title='Факторы', showticklabels=False, range=[-1.5, 1.5], showgrid=False, showline=False,
                   zeroline=False),
        yaxis2=dict(title='', showticklabels=False, range=[-7, 2], showgrid=False, showline=False,
                    zeroline=False),

        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",

        font=dict(color="grey", size=14),

        autosize=True,
        # height = 400,
        # width = 1500,
        margin=dict(l=0, r=0, t=0, b=0)
        #     hovertemplate = "%{label}"
    )

    #    return dcc.Graph(
    #                id=graph_id,
    #                figure=fig,
    #                hoverData={'points': [{'x': '2019-03-15'}]}
    #            )

    return fig

# Гафик по фактору
def Main_Factor_Graph(factor_name, mode = 'Factor_Tab'):
    fig = go.Figure()
    factor_name = factor_name

    # Тип графика
    if Trigger.df_Factor_Dict.loc[factor_name]['graph_type'] == 'Area':
        graph_type = 'tozeroy'
    else:
        graph_type = None

    # Параметры для отрисовки графа
    factor_desc = Trigger.df_Factor_Dict.loc[factor_name]['factor_desc']

    try:
        measure = Trigger.df_Factor_Dict.loc[factor_name]['measure']
    except:
        measure = 'V'


    measure_multip = Trigger.df_Factor_Dict.loc[factor_name]['measure_multip']
    measure_short = Trigger.df_Factor_Dict.loc[factor_name]['measure_short']



    measure_desc = Trigger.df_Factor_Dict.loc[factor_name]['measure_desc']
    decimal = Trigger.df_Factor_Dict.loc[factor_name]['decimal_']
    factor_desc  = f'{factor_desc} ({factor_name})'


    if measure_short == '%':
        yaxis_tickformat = '.'+str(decimal)+'%'
    else:
        yaxis_tickformat = '0,.'+str(decimal)+'f'


    df = Trigger.df_Dataset
    x_data = df.index.get_level_values(0)
    y_data = df[factor_name] / measure_multip


    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # =========================================
    # ЕТС Снижение
    fig.add_trace(go.Scatter(x=x_data,
                             y=df['down_value'],
                             mode='none',
                             name='Снижение ЕТС',
                             fill='tozeroy',
                             #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             fillcolor=Color_ETC_Down #'#2CA02C',

                             ),
                  secondary_y=True
                  )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    # ЕТС Повышение
    fig.add_trace(go.Scatter(x=x_data,
                             y=df['up_value'],
                             mode='none',
                             name='Повышение ЕТС',
                             fill='tozeroy',
                             #  line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             fillcolor = Color_ETC_Up #'#FF7F0E'

                   ),
                  secondary_y=True

                  )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    # =========================================
    # Данные фактора
    fig.add_trace(go.Scatter(x=x_data,
                             y=y_data,
                             mode='lines',
                             name=factor_desc,
                             fill=graph_type,
                             line=dict(color=Color_Factor, width=2.5, dash='solid'),
                             # 'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             #fillcolor=Color_Factor,
                             showlegend=False,
                             connectgaps=True))  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    graph_title = 'graph_title'

    fig.update_layout(
        title=factor_desc,
        #height=300,
        paper_bgcolor="rgba(0,0,0,0)",
        # plot_bgcolor="rgba(0,0,0,1)",
        plot_bgcolor='#1E2130',

        font=dict(color="grey", size=14),

        autosize=True,

        margin=dict(l=0, r=0, t=50, b=0),

        xaxis=dict(tickformat='%d.%m.%Y',
                   showgrid=False,
                   showline=False,
                   zeroline=False),

        yaxis=dict(title=measure_desc,
                   showticklabels=True,
                   # range=[graph_bottom, graph_top],
                   showgrid=True,
                   gridwidth=1,
                   gridcolor='#1e2130',


                   showline=False,
                   zeroline=False,
                   # tickformat = yaxis_tickformat,
                   layer = 'below traces'
                   ),

        yaxis2=dict(  # title = 'ЕТС (факт)',
            showticklabels=False,
            range=[-5, 2],
            showgrid=False,
            showline=False,
            zeroline=False),

    )

    if mode == 'Calibr':
        fig.update_layout(autosize=True,
                          height = 250,
                          showlegend=False)
    return fig

# Гафик по фиче
def Main_Feature_Graph(feature_name, model):
    fig = go.Figure()


    # Тип графика
    graph_type = None

    # Параметры для отрисовки графа
    factor_desc = f' {feature_name}  {model} '
    # measure = Trigger.df_Factor_Dict.loc[factor_name]['measure']
    # measure_multip = Trigger.df_Factor_Dict.loc[factor_name]['measure_multip']
    measure_desc = 'measure_desc'
    decimal = 0



    # if measure == 'P':
    #     yaxis_tickformat = '.'+str(decimal)+'%'
    # elif measure == 'V':
    #     yaxis_tickformat = '0,.'+str(decimal)+'f'

    yaxis_tickformat = '.' + str(decimal) + '%'

    df = Trigger.df_Dataset_Modif_Features
    x_data = df.index.get_level_values(0)
    y_data = df[feature_name]

    df_set = Trigger.df_Factor_Features
    # Уровни пробития
    Level_Red = df_set.loc[(df_set['model'] == model) & (df_set['features'] == feature_name)]['red_val']
    Level_Yellow = df_set.loc[(df_set['model'] == model) & (df_set['features'] == feature_name)]['yellow_val']

    Level_Red = float(Level_Red)
    Level_Yellow = float(Level_Yellow)

    graph_top = y_data.max() * 1.2
    graph_bottom = y_data.min()*1.2



    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Y
    # fig.add_trace(go.Scatter(x=x_data,
    #                          y=pd.Series([graph_bottom for i in range(len(x_data))]),
    #                          name='',
    #                          mode='lines',
    #                          fill='none',
    #                          line=dict(width=1, dash='solid',color='yellow'),
    #                          # 'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
    #                          # line_shape='linear',
    #                          showlegend=False,
    #                          ))

    fig.add_trace(go.Scatter(x=x_data,
                             y=[Level_Red for i in range(len(x_data))],
                             mode='lines',
                             name='',
                             # fill='none',
                             line=dict(width=1, dash='dash', color = Color_Red_Level),
                             # 'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             fillcolor=Color_Red_Level,
                             showlegend=False,

                             ))  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'


    fig.add_trace(go.Scatter(x=x_data,
                             y=[Level_Yellow for i in range(len(x_data))],
                             mode='lines',
                             name='',
                             # fill='none',
                             line=dict(width=1, dash='dash', color = Color_Yellow_Level),
                             # 'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             fillcolor=Color_Yellow_Level,
                             showlegend = False,

                             ))  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    # =========================================
    # ЕТС Снижение
    fig.add_trace(go.Scatter(x=x_data,
                             y=df['down_value'],
                             mode='none',
                             name='Снижение ЕТС',
                             fill='tozeroy',
                             #    line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             fillcolor=Color_ETC_Down #'#2CA02C',

                             ),
                  secondary_y=True
                  )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    # ЕТС Повышение
    fig.add_trace(go.Scatter(x=x_data,
                             y=df['up_value'],
                             mode='none',
                             name='Повышение ЕТС',
                             fill='tozeroy',
                             #  line=dict( width=2, dash='solid'),#'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             fillcolor = Color_ETC_Up #'#FF7F0E'

                   ),
                  secondary_y=True

                  )  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'

    # =========================================
    # Данные фичи
    fig.add_trace(go.Scatter(x=x_data,
                             y=y_data,
                             name=factor_desc,
                             mode='lines',
                             fill=graph_type,
                             line=dict(color=Color_Factor, width=2.5, dash='solid'),
                             # 'solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot'
                             line_shape='linear',
                             #fillcolor=Color_Factor,
                             showlegend=False,
                             connectgaps=True))  # 'linear', 'spline', 'hv', 'vh', 'hvh', 'vhv'


    graph_title = 'graph_title'

    fig.update_layout(
        title=factor_desc,
        #height=300,
        paper_bgcolor="rgba(0,0,0,0)",
        # plot_bgcolor="rgba(200,200,200,1)",
        plot_bgcolor='#1E2130',
        font=dict(color="grey", size=14),

        autosize=True,

        margin=dict(l=0, r=0, t=50, b=0),

        xaxis=dict(tickformat='%d.%m.%Y',
                   showgrid=False,
                   showline=False,
                   zeroline=False),

        yaxis=dict(
                # title=measure_desc,
                   showticklabels=True,
                   range=[graph_bottom, graph_top],
                   showgrid=False,
                   gridwidth=1,
                   gridcolor='#1e2130',
                   showline=False,
                   zeroline=False,
                   # tickformat = yaxis_tickformat,
                   layer = 'below traces'
                   ),

        yaxis2=dict(  # title = 'ЕТС (факт)',
            showticklabels=False,
            range=[-5, 2],
            showgrid=False,
            showline=False,
            zeroline=False),

    )

    return fig


# Закладка "Фактор"
# Табличка с описание фич фактора и моделей, в которых они используются
def Factor_Features_Table(factor_name):
    # Выбираем описание фактора
    df = Trigger.df_Factor_Features.loc[Trigger.df_Factor_Features['feature_base'] == factor_name, :]

    # поля
    column_list =['features','model','coefs' ]

    df['coefs'] = round(df['coefs'],4)

    columnDefs = [
        {"field": column_list[0],'headerName': 'Фича', 'width':190},
        {"field": column_list[1],'headerName': 'Модель', 'width':100},
        {"field": column_list[2],'headerName': 'Критерий', 'width':70}]

    getRowStyle = {
        "styleConditions": [
            {
                "condition": "params.rowIndex % 2 === 0",
                "style": {"backgroundColor": "#1E2130"},
            },
        ]
    }


    AgGrid = dag.AgGrid(
        id = 'Feature_Table_Main',
        className = "ag_theme_feature_main",
        rowData = df[column_list].to_dict("records"),
        columnDefs = columnDefs,
        columnSize = "sizeToFit",
        defaultColDef={'resizable': True, "sortable": True, "filter": False},
        dashGridOptions={'rowSelection': "single"},
        selectedRows= df[column_list].head(n=1).to_dict("records"),
        getRowStyle=getRowStyle
    )

    return AgGrid


# Закладка "Фактор"
# Табличка с описанием уровней фичи
def Feature_Levels_Table(feature_name, model):

    # Выбираем описание фактора
    df = Trigger.df_Factor_Features.loc[(Trigger.df_Factor_Features['features'] == feature_name) & (
                                         Trigger.df_Factor_Features['model'] == model), :]
    # Готовим описание уровней

    # df_left_red = df[['left_red_zone_percent', 'left_red_zone_val', 'left_red_zone_cnt_tot', 'left_red_zone_cnt_1', 'left_red_zone_rate','left_iv','left_max_rate','left_criteria']]
    # df_left_yellow = df[['left_yellow_zone_percent', 'left_yellow_zone_val', 'left_yellow_zone_cnt_tot', 'left_yellow_zone_cnt_1', 'left_yellow_zone_rate','left_iv','left_max_rate','left_criteria']]
    # df_right_red = df[['right_red_zone_percent', 'right_red_zone_val', 'right_red_zone_cnt_tot', 'right_red_zone_cnt_1', 'right_red_zone_rate','right_iv','right_max_rate','right_criteria']]
    # df_right_yellow = df[['right_yellow_zone_percent', 'right_yellow_zone_val', 'right_yellow_zone_cnt_tot',  'right_yellow_zone_cnt_1', 'right_yellow_zone_rate','right_iv','right_max_rate','right_criteria']]

    df_yellow = df[['yellow_perc', 'yellow_val']]
    df_red = df[['red_perc', 'red_val']]




    new_column_name = ['zone_percent', 'zone_val']
    for i_df in [df_yellow, df_red]:
        i_df.columns = new_column_name

    df_desc = pd.concat([df_yellow, df_red], axis=0)
    df_desc.insert(0, 'level', ['yellow', 'red'])

    # Сортируем
    for column in ['zone_val']:
        df_desc[column] = round(df_desc[column],4)

    # Задаём порядок полей
    column_list = ['level','zone_percent', 'zone_val']

    columnDefs = [
        {"field": column_list[0], 'headerName': 'Уровень'},
        {"field": column_list[1], 'headerName': 'Уровень(%)'},
        {"field": column_list[2], 'headerName': 'Уровень'},
        # {"field": column_list[3], 'headerName': 'Коэфф. уровня'},
    ]

    getRowStyle = {
        "styleConditions": [
            {
                "condition": "params.rowIndex % 2 === 0",
                "style": {"backgroundColor": "#1E2130"},
            },
        ]
    }

    AgGrid = dag.AgGrid(
        id='Feature_Table_Desc',
        className="ag_theme_feature_main",
        rowData=df_desc[column_list].to_dict("records"),
        columnDefs=columnDefs,
        columnSize="sizeToFit",
        defaultColDef={'resizable': True, "sortable": False, "filter": False},
        dashGridOptions={'rowSelection': "single"},
        getRowStyle=getRowStyle
    )

    return AgGrid




def Factor_Set_Table():
    # 'features', 'directions', 'yellow_perc', 'red_perc', 'yellow_val',
    # 'red_val', 'coefs', 'feature_base', 'desc', 'model', 'kpi_id'

    columns_names = {'features': 'Фича',
                     'directions': 'Направление пробития',
                     'yellow_val': 'Жёлтый уровень',
                     'red_val': 'Красный уровень',
                     'coefs': 'Вес',

                     'feature_base': 'Фактор',
                     'desc': 'Описание',
                     'model': 'Модель',
                     }

    # columns_names = {'factor_desc': 'Описание фактора',
    #                  'Breaking_Down_Down': 'Пробитие вниз - рекомендация опускать',
    #                  'Breaking_Down_Up': 'Пробитие вниз - рекомендация поднимать',
    #                  'Breaking_Up_Down': 'Пробитие вверх - рекомендация опускать',
    #                  'Breaking_Up_Up': 'Пробитие вверх - рекомендация поднимать',
    #
    #                  'Breaking_Down_Short_Down': 'Пробитие вниз - рекомендация опускать Короткие',
    #                  'Breaking_Down_Short_Up': 'Пробитие вниз - рекомендация поднимать Короткие',
    #                  'Breaking_Up_Short_Down': 'Пробитие вверх - рекомендация опускать Короткие',
    #                  'Breaking_Up_Short_Up': 'Пробитие вверх - рекомендация поднимать Короткие',
    #
    #                  'Breaking_Down_Long_Down': 'Пробитие вниз - рекомендация опускать Длинные',
    #                  'Breaking_Down_Long_Up': 'Пробитие вниз - рекомендация поднимать Длинные',
    #                  'Breaking_Up_Long_Down': 'Пробитие вверх - рекомендация опускать Длинные',
    #                  'Breaking_Up_Long_Up': 'Пробитие вверх - рекомендация поднимать Длинные',
    #                  'Level_Red_1': 'Красный уровень',
    #                  'Level_Yellow_1': 'Жёлтый уровень',
    #                  'Level_Green': 'Зелёный уровень',
    #                  'Level_Yellow_2': 'Жёлтый уровень',
    #                  'Level_Red_2': 'Красный уровень',
    #                  'graph_type': 'Тип графика',
    #                  'measure_desc': 'Описание измерения для графика',
    #                  'measure_short':'Кратно единица измер',
    #                  'measure_multip': 'Делитель',
    #                  'decimal':'Цифры после запятой',
    #                  'graph_bottom': 'Нижняя граница графика',
    #                  'graph_top': 'Верхняя граница графика',
    #                  'measure': 'Процент или Объём',
    #                  'influence': 'Влияние',
    #                  'sort': 'Сорт',
    #                  'sort_Short': 'Сорт Короткие',
    #                  'sort_Long': 'Сорт Длинные',
    #                  'factor_file': 'factor_file',
    #                  'factor_file.1': 'factor_file_1'
    #                  }

    return dash_table.DataTable(id='factor_set_table',
                                data=Trigger.df_Factor_Features[columns_names.keys()].to_dict('records'),
                                columns=[{"name": columns_names[i], "id": i, "editable": True} for i in
                                         Trigger.df_Factor_Features[columns_names.keys()]],
                                #export_format='csv',

                                style_header={'backgroundColor': 'rgb(243,105,3)',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#1E2130',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center'
                                            },
                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'active'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': 'rgb(243,105,3)',
                                        'border': '2px solid rgb(0, 116, 217)',
                                        'color': 'black',
                                    },
                                ]
                                )

def Factor_Reaction_Table(factor_name):
    columns = [
                {'id': '1', 'name': 'Пробитие'},
                {'id': '2', 'name': 'Рекоменадция'},
                {'id': '3', 'name': 'Вся кривая',"editable": True, "type":'numeric'},
                {'id': '4', 'name': 'Короткий конец'},
                {'id': '5', 'name': 'Длинный конец'}

                ]

    table_data = []
    # factor_set = Trigger.df_Factor_Set.loc[factor_name,:]
    #
    #
    #
    # for i in ['Down_Down','Down_Up','Up_Down','Up_Up']:
    #     sum_columns = factor_set[reaction_column[i]].sum()
    #
    #     if sum_columns != 0:
    #         table_data.append({'1': column_text[i][0],
    #                            '2': column_text[i][1],
    #                            '3': factor_set[reaction_column[i][0]],
    #                            '4': factor_set[reaction_column[i][1]],
    #                            '5': factor_set[reaction_column[i][2]]
    #                            })

    table_data.append({'1': 0, '2': 0, '3': 0, '4': 0, '5': 0 })

    return dash_table.DataTable(id='factor_level_table',
                                data=table_data,
                                columns=columns,
                                style_header={'backgroundColor': 'rgba(243,105,3)',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#1E2130',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },
                                style_cell_conditional=[
                                    {'if': {'column_id': '1'},
                                     'width': '15%'},
                                    {'if': {'column_id': '2'},
                                     'width': '40%'},
                                    {'if': {'column_id': '3'},
                                     'width': '15%'},
                                    {'if': {'column_id': '4'},
                                     'width': '15%'},
                                    {'if': {'column_id': '5'},
                                     'width': '15%'},
                                ],
                                style_data_conditional=[
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': 'rgb(243,105,3)',
                                        'border': '2px solid rgb(0, 116, 217)',
                                        'color': 'black',
                                    },

                                ]
                                )

def Factor_Reaction_Table_Calibr(factor_name):
    columns = [
                {'id': '1', 'name': 'Пробитие'},
                {'id': '2', 'name': 'Рекоменадция'},
                {'id': '3', 'name': 'Вся кривая',"editable": True, "type":'numeric'},
                {'id': '4', 'name': 'Короткий конец', "editable": True, "type": 'numeric'},
                {'id': '5', 'name': 'Длинный конец', "editable": True, "type": 'numeric'}
                ]

    table_data = []
    factor_set = Trigger.df_Factor_Set.loc[factor_name, :]
    for i in ['Down_Down', 'Down_Up', 'Up_Down', 'Up_Up']:
        table_data.append({'1': column_text[i][0],
                           '2': column_text[i][1],
                           '3': factor_set[reaction_column[i][0]],
                           '4': factor_set[reaction_column[i][1]],
                           '5': factor_set[reaction_column[i][2]]
                           })

    # if RI_ftp_curve_part == 'All':
    #     seting_columns = ['Breaking_Down_Down', 'Breaking_Down_Up', 'Breaking_Up_Down', 'Breaking_Up_Up']
    #
    # elif RI_ftp_curve_part == 'Short':
    #     seting_columns = ['Breaking_Down_Short_Down', 'Breaking_Down_Short_Up', 'Breaking_Up_Short_Down', 'Breaking_Up_Short_Up']
    #
    # elif RI_ftp_curve_part == 'Long':
    #     seting_columns = ['Breaking_Down_Long_Down', 'Breaking_Down_Long_Up', 'Breaking_Up_Long_Down', 'Breaking_Up_Long_Up']


    # for i in seting_columns:
    #
    #     rec_w = Trigger.df_Factor_Set.loc[factor_name][i]
    #     table_data.append({'1': reaction_desc[i][0], '2': reaction_desc[i][1], '3': rec_w})

    return dash_table.DataTable(id='factor_reaction_table_calibr',
                                data=table_data,
                                columns=columns,
                                style_as_list_view =False,
                                style_header={'backgroundColor': 'rgb(243,105,3)',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#1E2130',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },
                                style_cell_conditional=[
                                    {'if': {'column_id': '1'},
                                     'width': '15%'},
                                    {'if': {'column_id': '2'},
                                     'width': '40%'},
                                    {'if': {'column_id': '3'},
                                     'width': '15%'},
                                    {'if': {'column_id': '4'},
                                     'width': '15%'},
                                    {'if': {'column_id': '5'},
                                     'width': '15%'},
                                ],
                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': 'rgb(243,105,3)',
                                        'border': '2px solid rgb(0, 116, 217)',
                                        'color': 'black',
                                    },
                                    {
                                        'if': {
                                            'filter_query': '{3} = 0 && {4} = 0 && {5} = 0'
                                            # 'column_id': '3'
                                        },
                                        'color': 'grey'
                                    },
                                ]
                                )

def Factor_Level_Table(factor_name, mode = 'Factor'):
    # mode = 'Factor' - режим на странице с факторами
    # mode = 'Calibr' - в режиме калибровки

    table_id = {'Factor':'factor_level_table',
                'Calibr':'factor_level_table_calibr'}

    measure_short = Trigger.df_Factor_Set.loc[factor_name]['measure_short']
    measure_short = "" if measure_short is np.nan else measure_short

    columns = [
                {'id': '1', 'name': 'Уровень'},
                {'id': '2', 'name': 'Значение ('+measure_short+')',"editable": True, "type":'numeric'},
                ]

    table_data = []


    #R2 = Trigger.df_Factor_Set.loc[factor_name]['Level_Red_2']
    Y2 = Trigger.df_Factor_Set.loc[factor_name]['Level_Yellow_2']
    G = Trigger.df_Factor_Set.loc[factor_name]['Level_Green']
    Y1 = Trigger.df_Factor_Set.loc[factor_name]['Level_Yellow_1']
    R1 = Trigger.df_Factor_Set.loc[factor_name]['Level_Red_1']

    table_data.append({'1': 'Жёлтый','2': Factor_Value_desc(factor_name, Y2)})
    table_data.append({'1': 'Зелёный', '2': Factor_Value_desc(factor_name, G)})
    table_data.append({'1': 'Жёлтый', '2': Factor_Value_desc(factor_name, Y1)})
    table_data.append({'1': 'Красный', '2': Factor_Value_desc(factor_name, R1)})


    return dash_table.DataTable(id=table_id[mode],
                                data=table_data,
                                columns=columns,
                                style_as_list_view=False,
                                style_header={'backgroundColor': 'rgb(243,105,3)',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#1E2130',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },

                                # style_cell_conditional=[
                                #     {'if': {'column_id': '1'},
                                #      'max-width': '50%',},
                                #     {'if': {'column_id': '2'},
                                #      'max-width': '50%',},
                                #
                                # ],
                                style_data_conditional=[
                                    {
                                        'if': {
                                            'state': 'active'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': 'rgb(243,105,3)',
                                        'border': '2px solid rgb(0, 116, 217)',
                                        'color': 'black',
                                    },
                                ]
                                )

def Factor_Level_Table_Calibr(factor_name):
    measure_short = Trigger.df_Factor_Set.loc[factor_name]['measure_short']
    measure_short = "" if measure_short is np.nan else measure_short

    columns = [
                {'id': '1', 'name': 'Уровень (верхняя граница)'},
                {'id': '2', 'name': 'Значение ('+measure_short+')',"editable": True, "type":'numeric'},
                ]

    table_data = []


    #R2 = Trigger.df_Factor_Set.loc[factor_name]['Level_Red_2']
    Y2 = Trigger.df_Factor_Set.loc[factor_name]['Level_Yellow_2']
    G = Trigger.df_Factor_Set.loc[factor_name]['Level_Green']
    Y1 = Trigger.df_Factor_Set.loc[factor_name]['Level_Yellow_1']
    R1 = Trigger.df_Factor_Set.loc[factor_name]['Level_Red_1']

    table_data.append({'1': 'Жёлтый','2': Factor_Value_desc(factor_name, Y2)})
    table_data.append({'1': 'Зелёный', '2': Factor_Value_desc(factor_name, G)})
    table_data.append({'1': 'Жёлтый', '2': Factor_Value_desc(factor_name, Y1)})
    table_data.append({'1': 'Красный', '2': Factor_Value_desc(factor_name, R1)})


    # # columns_name = {'1': 'Событие',
    # #                 '2': 'Рекоменадция',
    # #                 '3': 'Вес фактора'}
    #
    # columns = [
    #             {'id': '1', 'name': 'Уровень'},
    #             {'id': '2', 'name': 'Значение',"editable": True,"type":'numeric'}
    #             ]
    #
    # # level_desc = {#'Level_Red_2': 'Красный',
    # #               'Level_Yellow_2': 'Жёлтый',
    # #               'Level_Green': 'Зелёный',
    # #               'Level_Yellow_1': 'Жёлтый',
    # #               'Level_Red_1': 'Красный'
    # #               }
    #
    # table_data = []
    # for i in level_desc.items():
    #
    #     rec_w = Trigger.df_Factor_Set.loc[factor_name][i[0]]
    #     table_data.append({'1': i[1],  '2': rec_w})

    return dash_table.DataTable(id='factor_level_table_calibr',
                                data=table_data,
                                columns=columns,
                                style_as_list_view =False,
                                style_header={'backgroundColor': 'rgb(243,105,3)',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#1E2130',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },
                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': 'rgb(243,105,3)',
                                        'border': '2px solid rgb(0, 116, 217)',
                                        'color': 'black',
                                    },
                                ]
                                )
# Таблица со статистикой угадывани моделтли
def MA_Model_Main_Stat_Table(version, model):

    # Надо ли перегружать версию
    model_current = get_model_current()
    model_current.Load_Model_Analysis_data(version = version)

    # Данные
    df = model_current.Model_summary['metrics_by_years']
    df = df.loc[df['model'] == model, ['year', 'TP', 'FN', 'precision', 'recall', 'F1', 'Fbeta']]

    # percentage = FormatTemplate.percentage(0)
    format_percentage = Format(precision=0,
                        scheme=Scheme.percentage,
                        align=Align.right
                        )
    # Колонки
    columns = [{"id": "year", "name":"Год"},
               {"id": "TP", "name": "Угадано событий"},
               {"id": "FN", "name": "Пропущено событий"},
               {"id": "precision", "name": "Precision",'type': 'numeric', 'format': format_percentage},
               {"id": "recall", "name": "Recall",'type': 'numeric', 'format': format_percentage},
               {"id": "F1", "name": "F1",'type': 'numeric', 'format': format_percentage},
               {"id": "Fbeta", "name": "Fbeta",'type': 'numeric', 'format': format_percentage}
               ]

    style_cell_conditional = [
        {'if': {'column_id': 'year'}, 'width': '20%'},

        {'if': {'column_id': 'TP'}, 'width': '16%'},
        {'if': {'column_id': 'FN'}, 'width': '16%'},
        {'if': {'column_id': 'precision'}, 'width': '12%'},
        {'if': {'column_id': 'recall'}, 'width': '12%'},
        {'if': {'column_id': 'F1'}, 'width': '12%'},
        {'if': {'column_id': 'Fbeta'}, 'width': '12%'},

    ]


    # style_data={
    #     'width': '10px',
    #     'maxWidth': '10px',
    #     'minWidth': '10px',
    # }


    return dash_table.DataTable(id="MA_Table_Model_Main_Stat_id",
                                data=df.to_dict('records'),
                                columns=columns,
                                style_as_list_view =False,
                                style_data = {'border':'20px #48B66E'},


                                style_header={'border': '20px #48B66E',
                                              'backgroundColor': '#289F52',
                                              'textAlign': 'center'},

                                style_cell={'backgroundColor': '#262A44',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16,

                                            'overflow': 'hidden',
                                            'textOverflow': 'ellipsis',
                                            'maxWidth': 0
                                            },

                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': '#262A44',
                                        'border': '1px solid #262A44',
                                        'color': 'white',
                                    },
                                ],
                                style_cell_conditional=style_cell_conditional,
                                # style_data = style_data
                                )

# Таблица с описанием входящих блоков
def MA_Block_Main_Stat_Table(version, model):

    # Надо ли перегружать версию
    model_current = get_model_current()
    model_current.Load_Model_Analysis_data(version = version)

    # Данные
    df = model_current.Block_summary['pivot']
    df =df.loc[df['model'] == model,df.columns.drop(['model','block'])]

    # percentage = FormatTemplate.percentage(0)
    format_percentage = Format(precision=0,
                                scheme=Scheme.percentage,
                                # align=Align.right
                                )
    # Колонки
    columns = [{"id": "segment_name", "name":"Блок"},
               {"id": "coefs", "name": "Вес блока", 'type': 'numeric','format': format_percentage},
               # {"id": "Доля 0", "name": "Доля 0", 'type': 'numeric','format': format_percentage},
               {"id": "Доля 1", "name": "Доля сигнала",'type': 'numeric', 'format': format_percentage},
               {"id": "Макс. длина серии", "name": "Макс. длина серии",'type': 'numeric'},
               {"id": "N_TP событий", "name": "Угадано событий",'type': 'numeric'},
               {"id": "N_FN событий", "name": "Пропущено событий",'type': 'numeric'},
               {"id": "N событий", "name": "Всего событий", 'type': 'numeric'},
               {"id": "precision", "name": "Precision", 'type': 'numeric', 'format': format_percentage},
               {"id": "recall", "name": "Recall", 'type': 'numeric', 'format': format_percentage},
               {"id": "F1", "name": "F1", 'type': 'numeric', 'format': format_percentage},
               {"id": "Fbeta", "name": "Fbeta", 'type': 'numeric', 'format': format_percentage}
               ]

    style_cell_conditional = [
        {'if': {'column_id': 'segment_name'}, 'width': '20%'},
        {'if': {'column_id': 'coefs'}, 'width': '8%'},
        # {'if': {'column_id': 'Доля 0'}, 'width': '16%'},
        {'if': {'column_id': 'Доля 1'}, 'width': '8%'},
        {'if': {'column_id': 'Макс. длина серии'}, 'width': '8%'},
        {'if': {'column_id': 'N_TP событий'}, 'width': '8%'},
        {'if': {'column_id': 'N_FN событий'}, 'width': '8%'},
        {'if': {'column_id': 'N событий'}, 'width': '8%'},
        {'if': {'column_id': 'precision'}, 'width': '8%'},
        {'if': {'column_id': 'recall'}, 'width': '8%'},
        {'if': {'column_id': 'F1'}, 'width': '8%'},
        {'if': {'column_id': 'Fbeta'}, 'width': '8%'},
    ]

    return dash_table.DataTable(id="MA_Table_Block_Main_Stat_id",
                                data=df.to_dict('records'),
                                # active_cell={"row": 0, "column": 0, "column_id": "segment_name" },
                                columns=columns,
                                style_as_list_view =False,

                                style_data={'border': '1px #48B66E'},

                                style_header={'border': '1px #48B66E',
                                              'backgroundColor': '#F86404',
                                              'textAlign': 'center'},
                                style_cell={'backgroundColor': '#262A44',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },
                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': '#262A44',
                                        'border': '1px solid grey',
                                        'color': 'white',
                                    },
                                ],
                                style_cell_conditional=style_cell_conditional,
                                )

# Таблица с факторами в модели
def MA_Factor_Main_Stat_Table(version,model,block):
    # Надо ли перегружать версию
    model_current = get_model_current()
    model_current.Load_Model_Analysis_data(version = version)

    # Данные
    df = model_current.Factors_summary['pivot']
    df = df.loc[(df['model'] == model) & (df['block'] == block_converter[block]),df.columns]

    # percentage = FormatTemplate.percentage(0)
    format_percentage = Format(precision=0,
                        scheme=Scheme.percentage,
                        align=Align.center
                        )


    format_text = Format(align=Align.left)


    # Колонки
    columns = [{"id": "factor", "name":"Фича", 'type': 'text','format':format_text},
               {"id": "coefs", "name": "Вес фичи", 'type': 'numeric','format': format_percentage},
               {"id": "directions", "name": "Направление пробития",'type': 'numeric', 'format': format_percentage},
               {"id": "desc", "name": "Описание фактора",'type': 'numeric'},
               {"id": "Доля 1", "name": "Доля сигнала",'type': 'numeric','format': format_percentage},
               {"id": "Макс. длина серии", "name": "Макс. длина серии",'type': 'numeric'},

               {"id": "N_TP событий", "name": "Угадано событий", 'type': 'numeric'},
               {"id": "N_FN событий", "name": "Пропущено событий", 'type': 'numeric'},
               {"id": "N событий", "name": "N", 'type': 'numeric'},



               {"id": "precision", "name": "Precision", 'type': 'numeric', 'format': format_percentage},
               {"id": "recall", "name": "Recall", 'type': 'numeric', 'format': format_percentage},
               {"id": "F1", "name": "F1", 'type': 'numeric', 'format': format_percentage},
               {"id": "Fbeta", "name": "Fbeta", 'type': 'numeric', 'format': format_percentage},
               {"id": "model", "name": "model"},
               {"id": "block", "name": "block" }

               ]

    style_cell_conditional = [
        {'if': {'column_id': 'factor'}, 'width': '15%'},
        {'if': {'column_id': 'coefs'}, 'width': '4%'},
        {'if': {'column_id': 'directions'}, 'width': '6%'},
        {'if': {'column_id': 'desc'}, 'width': '28%', 'textAlign': 'left'},
        {'if': {'column_id': 'Доля 1'}, 'width': '5%'},
        {'if': {'column_id': 'Макс. длина серии'}, 'width': '5%'},

        {'if': {'column_id': 'N_TP событий'}, 'width': '5%'},
        {'if': {'column_id': 'N_FN событий'}, 'width': '5%'},
        {'if': {'column_id': 'N событий'}, 'width': '5%'},

        {'if': {'column_id': 'precision'}, 'width': '5%'},
        {'if': {'column_id': 'recall'}, 'width': '5%'},
        {'if': {'column_id': 'F1'}, 'width': '5%'},
        {'if': {'column_id': 'Fbeta'}, 'width': '5%'},
    ]

    return dash_table.DataTable(id="MA_Table_Factor_Main_Stat_id",
                                data=df.to_dict('records'),
                                columns=columns,
                                # active_cell={"row": 0, "column": 0, "column_id": "factor"},
                                style_as_list_view =False,

                                style_data={'border': '1px #48B66E'},

                                style_header={'border': '1px #48B66E',
                                              'backgroundColor': '#71138B',
                                              'textAlign': 'center'},

                                style_cell={'backgroundColor': '#262A44',
                                            'color': 'white',
                                            'whiteSpace': 'normal',
                                            'height': 'auto',
                                            'textAlign': 'center',
                                            'font-size': 16
                                            },
                                style_data_conditional = [
                                    {
                                        'if': {
                                            'state': 'selected'  # 'active' | 'selected'
                                        },
                                        'backgroundColor': '#262A44',
                                        'border': '1px solid grey',
                                        'color': 'white',
                                    },
                                ],
                                style_cell_conditional=style_cell_conditional,
                                )


# Готовим данные и запускаем расчёт графика по фактору
def MA_Factor_Graph(version, MODEL, block, FACTORS, factor_desc ):
    model_current = get_model_current()

    target_df = model_current.csv_target_model
    target_df = make_target(target_df, MODEL)

    total_dict = model_current.total_dict

    # data_1_df = total_dict['data_1_agg'].loc[total_dict['data_1_agg']['model'] == MODEL]
    data_1_df = total_dict['data_1_agg']
    data_2_df = total_dict['data_2_modif'].loc[total_dict['data_2_modif']['model'] == MODEL]
    info_df = total_dict['features'].loc[total_dict['features']['model'] == MODEL]
    data_3_df = total_dict['data_3_signals'].loc[total_dict['data_3_signals']['model'] == MODEL]

    data_1_df['report_date'] = pd.to_datetime(data_1_df['report_date'])
    data_2_df['report_date'] = pd.to_datetime(data_2_df['report_date'])
    data_3_df['report_date'] = pd.to_datetime(data_3_df['report_date'])


    FACTORS_ORIG = [info_df.loc[info_df['factor'] == FACTORS[0]]['factor_origin'].values[0]]
    FACTORS_ORIG = [x.replace('_kalman', '') for x in FACTORS_ORIG]

    if set(FACTORS_ORIG).issubset(set(data_1_df['factor_origin'].unique())):
        hist_data = data_1_df.loc[data_1_df['factor_origin'].isin(FACTORS_ORIG)].reset_index(drop=True)
        hist_data['factor'] = FACTORS[0]
    else:
        return None

    # factors_blocks = hist_data['block'].unique()
    # if len(factors_blocks) > 1:
    #     logging.info('factors in different blocks')
    # else:
    #     model_block = factors_blocks[0]
    # logging.info(model_block)

    # model_block = block

    features_types = find_features_types(FACTORS, data_2_df)
    features_levels = find_features_levels(FACTORS, info_df)
    features_directions = find_features_directions(FACTORS, info_df)

    factors_df = data_2_df.loc[(data_2_df['factor'].isin(FACTORS)) & (data_2_df['block'] == block)].reset_index(drop=True)
    signals_df = data_3_df.loc[(data_3_df['factor'].isin(FACTORS)) & (data_3_df['block'] == block)].reset_index(drop=True)

    factors_df['report_date'] = pd.to_datetime(factors_df['report_date'])

    factors_df = pd.merge(
        factors_df.rename(columns={'Value': 'feature_hist'}).drop(columns=['model', 'block']),
        hist_data.rename(columns={'Value': 'factor_hist'}),
        on=['report_date', 'factor']
    ).dropna(
        subset=['factor_hist']
        ).drop_duplicates(
            subset=['report_date', 'factor', 'feature_type']
            )

    factors_df = pd.merge(
        factors_df,
        target_df,
        left_on='report_date',
        right_on='end_date'
    ).drop(columns=['end_date'])

    factors_df = pd.merge(
        factors_df,
        signals_df.drop(columns=['model', 'block']),
        on=['report_date', 'factor']
    )

    # title_text = ' '.join([MODEL, model_block]),

    # title_text = f'{model_desc[MODEL]}({MODEL})     {block_desc[model_block]} ({model_block})<br>{factor_desc}'
    title_text = f'{model_desc[MODEL]} <i>({MODEL})</i> <br>{factor_desc}'

    fig = plot_factors_with_features(
        factors=FACTORS,
        features_types=features_types,
        factors_df=factors_df,
        target_df = target_df,
        add_windows=True,
        features_levels=features_levels,
        features_directions=features_directions,
        title_text= title_text,
        show=True,
        save=True,
        save_path='save_path',
        pct_name='picture1',
        verbose=False
    )

    return fig

# Функция графика по модели
def MA_Model_Graph(version, MODEL, joined_target: bool = False, opposite_target: bool = True):
    model_current = get_model_current()
    model_current.Load_Model_Analysis_data(version=version)

    name_dict = {
        'long_down': 'Снижение ставок ЕТС от 1 года',
        'long_up': 'Повышение ставок ЕТС от 1 года',
        'short_down': 'Снижение ставок ЕТС до 3 мес.',
        'short_up': 'Повышение ставок ЕТС до 3 мес.'
    }

    model_pair = find_paired_model(MODEL, list(name_dict.keys()))
    opposite_model = find_opposite_model(MODEL, list(name_dict.keys()))

    targets_df = model_current.csv_target_model
    total_dict = model_current.total_dict

    target_df = get_target_df(MODEL, targets_df, model_pair=model_pair, joined_target=joined_target)
    model_df = total_dict['data_ewi'].loc[(total_dict['data_ewi']['model'] == MODEL)&(total_dict['data_ewi']['block'] == 'TOTAL')].copy()
    rlevel = total_dict['ewi_threshold'].loc[(total_dict['ewi_threshold']['model'] == MODEL) & (total_dict['ewi_threshold']['block'] == 'TOTAL'), 'ewi_threshold_val'].values[0]
    opposite_target_df = get_target_df(opposite_model, targets_df)

    model_df['report_date'] = pd.to_datetime(model_df['report_date'])

    title_text  = name_dict.get(MODEL)
    title_text = name_dict.get(MODEL)
    title_text = f'<b>История срабатывания модели</b> <br>{model_desc[MODEL]} <i>({MODEL}) </i>'
    
    fig = plot_model_ewi_2(
        model_df = model_df,
        target_df=target_df,
        rlevel=rlevel,
        add_windows=False,
        title_text=title_text,
        add_opposite_target=opposite_target,
        opposite_target_df=opposite_target_df
    )

    return fig


# Функция графика по модели
def MA_Block_Graph(version, MODEL, BLOCK, joined_target: bool = True, opposite_target: bool = True):
    name_dict = {
        'long_down': 'Снижение ставок ЕТС от 1 года',
        'long_up': 'Повышение ставок ЕТС от 1 года',
        'short_down': 'Снижение ставок ЕТС до 3 мес.',
        'short_up': 'Повышение ставок ЕТС до 3 мес.'
    }

    segment_dict = dict(zip(
        ['MARKET', 'SFL', 'DUL', 'ALM', 'KFL', 'KUL'],
        ['Рынок', 'СФЛ', 'ДЮЛ', 'Метрики ALM', 'КФЛ', 'КЮЛ'],
    ))

    model_current = get_model_current()
    targets_df = model_current.csv_target_model
    total_dict = model_current.total_dict

    model_pair = find_paired_model(MODEL, list(name_dict.keys()))
    opposite_model = find_opposite_model(MODEL, list(name_dict.keys()))

    # вес блока
    block_weight = total_dict['features'].loc[
        (total_dict['features']['model'] == MODEL) & (total_dict['features']['segment_name'] == segment_dict[BLOCK]),
        'coefs'
    ].values[0]

    # сегмент
    target_df = get_target_df(MODEL, targets_df, model_pair=model_pair, joined_target=joined_target)

    block_df = total_dict['data_ewi'].loc[
        (total_dict['data_ewi']['model'] == MODEL) & (total_dict['data_ewi']['block'] == BLOCK)
        ]

    rlevel = total_dict['ewi_threshold'].loc[
        (total_dict['ewi_threshold']['model'] == MODEL) & (total_dict['ewi_threshold']['block'] == BLOCK),
        'ewi_threshold_val'
    ].values[0]
    opposite_target_df = get_target_df(opposite_model, targets_df)

    title_text = f''' <b>История сигналов блока </b>  <br>{name_dict.get(MODEL)},   блок {segment_dict.get(BLOCK)}  <i> (вес в модели: {block_weight:.0%}) </i>

                '''
    
    fig = plot_block_ewi(
        block_df=block_df,
        target_df=target_df,
        rlevel=rlevel,
        add_windows=False,
        title_text=title_text,
        add_opposite_target=opposite_target,
        opposite_target_df=opposite_target_df
    )

    return fig


# Основной график на первой закладке Триггер
def plot_factors_with_features( factors: list,
                                features_types: dict,
                                factors_df: pd.DataFrame,
                                target_df: pd.DataFrame,
                                add_windows = False,
                                features_levels: dict = None,
                                features_directions: dict = None,
                                title_text = None,
                                show = True,
                                save = False,
                                save_path = '',
                                pct_name = 'picture1',
                                verbose = False,
    ):

    factors_colors = [ 'rgba(231,41,138,1)', '#E377C2', '#00B5F7', '#FECB52','#EB663B']
    features_colors = ['#3366CC', 'green', '#B82E2E', '#8C564B', '#9467BD', '#17BECF']

    fig = go.Figure().set_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.01
    )

    j = 0
    for i, factor in enumerate(factors):

        factors_df_slice = factors_df.loc[(factors_df['factor'] == factor)].sort_values('report_date')

        # История фактора
        fig.add_trace(go.Scatter(
            x=factors_df_slice['report_date'],
            y=factors_df_slice['factor_hist'],
            name=factor,
            # line_color=factors_colors[i]
            line_color = '#FE00FF'
        ),

            row=1, col=1)

        for feature_type in features_types.get(factor):
            feature_type_slice = factors_df_slice.loc[(factors_df_slice['feature_type'] == feature_type)]

            feature_title = f'{factor} {feature_type}'
            # Добавим направление
            if features_directions is not None:
                direction = features_directions.get(factor).get(feature_type)
                feature_title += f' ({direction})'

            # История фичи
            fig.add_trace(go.Scatter(
                x=feature_type_slice['report_date'],
                y=feature_type_slice['feature_hist'],
                name=feature_title,
                line_color=features_colors[j]
            ),
                row=2, col=1)

            # Уровень фичи
            if features_levels is not None:
                rlevel = features_levels.get(factor).get(feature_type)
                fig.add_hline(
                    rlevel,
                    row=2, col=1,
                    line_color=features_colors[j],
                    # line_color='darkred',
                    line=dict(dash='dash'),
                    opacity=0.5
                )

            j += 1

        # Можно добавить окна горения фактора
        if add_windows:
            assert 'Signal' in factors_df_slice.columns

            df_for_windows = factors_df_slice.drop_duplicates(subset=['report_date', 'factor'], ignore_index=True)
            signal_windows = get_target_periods(df_for_windows['Signal'])

            for start_idx, end_idx in signal_windows:
                start_date = df_for_windows.iloc[int(start_idx)]['report_date']
                end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

                if verbose:
                    logging.info("{}: {} - {}".format(factor, start_date.date(), end_date.date()))

                if start_date == end_date:
                    fig.add_vline(
                        start_date,
                        line_color='#B707E7',
                        opacity=0.3,
                        row=1, col=1,
                        layer="below"
                    )
                else:
                    fig.add_vrect(
                        x0=start_date,
                        x1=end_date,
                        fillcolor='#B707E7',
                        opacity=0.3,
                        line_width=0,
                        row=1, col=1,
                        layer="below"
                    )

    C1 = (target_df['end_date'] >= factors_df['report_date'].min())
    C2 = (target_df['end_date'] <= factors_df['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)
    plt_add_target_windows(fig, df_for_target=df_for_target, color='gray')

    fig.update_layout(
        height=900,
        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        xaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        legend=dict(
            # orientation='h',
            yanchor='top',
            y=0.99,
            xanchor='right',
            x=0.99,
        ),
        title=dict(
            text=title_text,
            yanchor='bottom',
            # y=title_y,
            xanchor='left',
            # x=title_x
        ),
        paper_bgcolor="rgba(10,10,10,0.2)",
        plot_bgcolor="#262A44",#A5C7E0
        font=dict(color="darkgrey", size=14),
        autosize=True
    )

    return fig

# Основной график на первой закладке Триггер
def plot_factors_with_features_2(
    factors: list,
    features_types: dict,
    factors_df: pd.DataFrame,
    target_df: pd.DataFrame,
    add_windows = False,
    features_levels: dict = None,
    features_directions: dict = None,
    title_text = None,
    show = True,
    save = False,
    save_path = '',
    pct_name = 'picture1',
    verbose = False,
    ):

    factors_colors = [ 'rgba(231,41,138,1)', '#E377C2', '#00B5F7', '#FECB52','#EB663B']
    features_colors = ['#3366CC', 'green', '#B82E2E', '#8C564B', '#9467BD', '#17BECF']

    # fig = go.Figure().set_subplots(
    #     rows=2, cols=1,
    #     shared_xaxes=True,
    #     vertical_spacing=0.01
    # )

    fig = make_subplots(
        rows=2, cols=1,
        specs=[[{"secondary_y": False}], [{"secondary_y": True}]],
        shared_xaxes=True,
        vertical_spacing=0.01
        )

    j = 0
    for i, factor in enumerate(factors):

        factors_df_slice = factors_df.loc[(factors_df['factor'] == factor)].sort_values('report_date')

        # История фактора
        fig.add_trace(go.Scatter(
            x=factors_df_slice['report_date'],
            y=factors_df_slice['factor_hist'],
            name=factor,
            # line_color=factors_colors[i]
            line_color = '#FE00FF'
        ),

            row=1, col=1)

        for feature_type in features_types.get(factor):
            feature_type_slice = factors_df_slice.loc[(factors_df_slice['feature_type'] == feature_type)]

            feature_title = f'{factor} {feature_type}'
            # Добавим направление
            if features_directions is not None:
                direction = features_directions.get(factor).get(feature_type)
                feature_title += f' ({direction})'

            # Если фича по регрессии, сделаем вторую ось
            secondary_y = feature_type == 'REG'

            # История фичи
            fig.add_trace(go.Scatter(
                x=feature_type_slice['report_date'],
                y=feature_type_slice['feature_hist'],
                name=feature_title,
                line_color=features_colors[j]
            ),
                row=2, col=1, secondary_y=secondary_y)

            # Уровень фичи
            if features_levels is not None:
                rlevel = features_levels.get(factor).get(feature_type)
                fig.add_hline(
                    rlevel,
                    row=2, col=1,
                    line_color=features_colors[j],
                    # line_color='darkred',
                    line=dict(dash='dash'),
                    opacity=0.5,
                    secondary_y=secondary_y
                )

            j += 1

        # Можно добавить окна горения фактора
        if add_windows:
            assert 'Signal' in factors_df_slice.columns

            df_for_windows = factors_df_slice.drop_duplicates(subset=['report_date', 'factor'], ignore_index=True)
            signal_windows = get_target_periods(df_for_windows['Signal'])

            for start_idx, end_idx in signal_windows:
                start_date = df_for_windows.iloc[int(start_idx)]['report_date']
                end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

                if verbose:
                    logging.info("{}: {} - {}".format(factor, start_date.date(), end_date.date()))

                if start_date == end_date:
                    fig.add_vline(
                        start_date,
                        line_color='#B707E7',
                        opacity=0.3,
                        row=1, col=1,
                        layer="below"
                    )
                else:
                    fig.add_vrect(
                        x0=start_date,
                        x1=end_date,
                        fillcolor='#B707E7',
                        opacity=0.3,
                        line_width=0,
                        row=1, col=1,
                        layer="below"
                    )

    C1 = (target_df['end_date'] >= factors_df['report_date'].min())
    C2 = (target_df['end_date'] <= factors_df['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)
    plt_add_target_windows(fig, df_for_target=df_for_target, color='gray')

    fig.update_layout(
        height=900,
        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        xaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis3=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        legend=dict(
            # orientation='h',
            yanchor='top',
            y=0.99,
            xanchor='right',
            x=0.95,
        ),
        title=dict(
            text=title_text,
            yanchor='bottom',
            # y=title_y,
            xanchor='left',
            # x=title_x
        ),
        paper_bgcolor="rgba(10,10,10,0.2)",
        plot_bgcolor="#262A44",#A5C7E0
        font=dict(color="darkgrey", size=14),
        autosize=True
    )

    return fig

def get_target_periods(target_series: pd.Series):
    runs = get_runs(target_series)
    series_start_index = runs[:, 1].cumsum()
    runs = np.append(runs, series_start_index.reshape(len(series_start_index), 1), axis=1)

    target_end_indices = runs[runs[:, 0] == 1][:, 2]  # не включительно
    target_start_indices = target_end_indices - runs[runs[:, 0] == 1][:, 1]

    # start_n = len(target_start_indices)
    # end_n = len(target_end_indices)

    target_periods = list(zip(target_start_indices, target_end_indices))

    return target_periods


# def update_layout(fig, height, width, title_text, title_y, title_x):
#     fig.update_layout(
#         height=height,
#         width=width,
#         legend=dict(
#             orientation='h',
#             yanchor='bottom',
#             y=1.02,
#             xanchor='right',
#             x=1
#         ),
#         title=dict(
#             text=title_text,
#             yanchor='bottom',
#             y=title_y,
#             xanchor='left',
#             x=title_x
#         )
#     )

# show_params_dict = dict(height=900, width=1000, title_y=0.88, title_x=0.08)

def plot_model_ewi(
        model_df: pd.DataFrame,
        target_df: pd.DataFrame,
        rlevel: float,
        add_windows=False,
        title_text=None,

        save_path='',
        pct_name='picture1',
        verbose=False
) -> None:
    factors_colors = ['purple', '#E377C2', '#00B5F7', '#FECB52']

    model_df_slice = model_df.sort_values('report_date').copy()

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=model_df_slice['report_date'],
        y=model_df_slice['ewi'],
        line_color='#48B66E'
    ))

    fig.add_hline(
        rlevel,
        line_color='#146FF4',
        line=dict(dash='dash')
    )

    if add_windows:
        assert 'signal' in model_df_slice.columns

        df_for_windows = model_df_slice.reset_index(drop=True)
        signal_windows = get_target_periods(df_for_windows['signal'])

        for start_idx, end_idx in signal_windows:
            start_date = df_for_windows.iloc[int(start_idx)]['report_date']
            end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

            fig.add_vrect(
                x0=start_date,
                x1=end_date,
                fillcolor='#33395C',
                opacity=0.3,
                line_width=0,
                row=1, col=1
            )

    C1 = (target_df['end_date'] >= model_df_slice['report_date'].min())
    C2 = (target_df['end_date'] <= model_df_slice['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)


    # добавляем окна
    target_periods = get_target_periods(df_for_target['target'])

    for start_idx, end_idx in target_periods:

        start_date = df_for_target.iloc[int(start_idx)]['end_date']
        end_date = df_for_target.iloc[int(end_idx) - 1]['end_date']

        if verbose:
            logging.info("{} - {}".format(start_date.date(), end_date.date()))

        fig.add_vrect(
            x0=start_date,
            x1=end_date,
            fillcolor='gray',
            opacity=0.5,
            line_width=0
        )

    fig.update_layout(
        height=500,

        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),

        xaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),


        yaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),

        yaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),

        # width=show_params_dict['width'],
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1
        ),

        title=dict(
            text=title_text,
            yanchor='bottom',
            # y=title_y,
            xanchor='left',
            # x=title_x
        ),

        paper_bgcolor="#161a28",
        plot_bgcolor="#262A44",

        font=dict(color="darkgray", size=14),

        autosize=True,
    )


    return  fig

def plot_model_ewi_2(
        model_df: pd.DataFrame,
        target_df: pd.DataFrame,
        rlevel: float,
        add_windows: bool = False,
        title_text: Optional[str] = None,
        add_opposite_target: bool = False,
        opposite_target_df: Optional[pd.DataFrame] = None
        # verbose: bool = False
    ) -> Optional[go.Figure]:
    
    # factors_colors = ['purple', '#E377C2', '#00B5F7', '#FECB52']
    model_df_slice = model_df.sort_values('report_date').copy()

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=model_df_slice['report_date'],
        y=model_df_slice['ewi'],
        line_color='#48B66E'
    ))

    fig.add_hline(
        rlevel,
        line_color='#146FF4',
        line=dict(dash='dash')
    )

    if add_windows:
        assert 'signal' in model_df_slice.columns

        df_for_windows = model_df_slice.reset_index(drop=True)
        signal_windows = get_target_periods(df_for_windows['signal'])

        for start_idx, end_idx in signal_windows:
            start_date = df_for_windows.iloc[int(start_idx)]['report_date']
            end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

            fig.add_vrect(
                x0=start_date,
                x1=end_date,
                fillcolor='#33395C',
                opacity=0.3,
                line_width=0,
                row=1, col=1,
                layer="below"
            )

    C1 = (target_df['end_date'] >= model_df_slice['report_date'].min())
    C2 = (target_df['end_date'] <= model_df_slice['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)
    plt_add_target_windows(fig, df_for_target=df_for_target, color='gray')

    if add_opposite_target:
        if opposite_target_df is None:
            return None
        C1 = (opposite_target_df['end_date'] >= model_df_slice['report_date'].min())
        C2 = (opposite_target_df['end_date'] <= model_df_slice['report_date'].max())
        df_for_target = opposite_target_df.loc[C1 & C2].reset_index(drop=True)
        plt_add_target_windows(fig, df_for_target=df_for_target, color='#dc143c', opacity=0.3)

    fig.update_layout(
        height=500,
        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        xaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1
        ),
        title=dict(
            text=title_text,
            yanchor='bottom',
            # y=title_y,
            xanchor='left',
            # x=title_x
        ),
        paper_bgcolor="#161a28",
        plot_bgcolor="#262A44",
        font=dict(color="darkgray", size=14),
        autosize=True
    )

    return fig


def plot_block_ewi(
        block_df: pd.DataFrame,
        target_df: pd.DataFrame,
        rlevel: float,
        add_windows: bool = False,
        title_text: Optional[str] = None,
        add_opposite_target: bool = False,
        opposite_target_df: Optional[pd.DataFrame] = None
        # verbose: bool = False
    ) -> Optional[go.Figure]:

    factors_colors = ['purple', '#E377C2', '#00B5F7', '#FECB52']

    block_df_slice = block_df.sort_values('report_date').copy()

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=block_df_slice['report_date'],
        y=block_df_slice['ewi'],
        line_color='#F86404'
    ))

    fig.add_hline(
        rlevel,
        line_color='#FF4769',
        line=dict(dash='dash')
    )

    if add_windows:
        assert 'signal' in block_df_slice.columns

        df_for_windows = block_df_slice.reset_index(drop=True)
        signal_windows = get_target_periods(df_for_windows['signal'])

        for start_idx, end_idx in signal_windows:
            start_date = df_for_windows.iloc[int(start_idx)]['report_date']
            end_date = df_for_windows.iloc[int(end_idx) - 1]['report_date']

            fig.add_vrect(
                x0=start_date,
                x1=end_date,
                fillcolor=factors_colors[1],
                opacity=0.3,
                line_width=0,
                row=1, col=1
            )

    C1 = (target_df['end_date'] >= block_df_slice['report_date'].min())
    C2 = (target_df['end_date'] <= block_df_slice['report_date'].max())
    df_for_target = target_df.loc[C1 & C2].reset_index(drop=True)
    plt_add_target_windows(fig, df_for_target=df_for_target)


    if add_opposite_target:
        if opposite_target_df is None:
            return None
        C1 = (opposite_target_df['end_date'] >= block_df_slice['report_date'].min())
        C2 = (opposite_target_df['end_date'] <= block_df_slice['report_date'].max())
        df_for_target = opposite_target_df.loc[C1 & C2].reset_index(drop=True)
        plt_add_target_windows(fig, df_for_target=df_for_target, color='#dc143c', opacity=0.3)

    # Наводим красату
    fig.update_layout(
        height=500,
        xaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        xaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        yaxis2=dict(tickformat='%m.%Y', showgrid=False, showline=False, zeroline=False),
        # width=show_params_dict['width'],
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='right',
            x=1
        ),
        title=dict(
            text=title_text,
            yanchor='bottom',
            # y=title_y,
            xanchor='left',
            # x=title_x
        ),
        paper_bgcolor="#161a28",
        plot_bgcolor="#262A44",
        font=dict(color="darkgray", size=14),
        autosize=True
    )

    return fig


def get_target_df(MODEL, targets_df, model_pair=None, joined_target=False):
    target_df_main = make_target(targets_df, MODEL)
    target_df = target_df_main

    if joined_target:
        assert model_pair is not None

        target_df_pair = make_target(targets_df, model_pair)
        target_df_new = pd.merge(
            target_df_main,
            target_df_pair,
            how='left',
            on='end_date'
        )
        target_df_new['target'] = (target_df_new['target_x'] + target_df_new['target_y']).clip(upper=1)
        target_df_new['event'] = (target_df_new['event_x'] + target_df_new['event_y']).clip(upper=1)

        target_df = target_df_new.drop(columns=['event_x', 'event_y', 'target_x', 'target_y'])

    return target_df

def find_opposite_model(model: str, all_models: list):
    return [m for m in all_models if (m.split('_')[0] == model.split('_')[0]) & (m != model)][0]

def find_paired_model(model: str, all_models: list):
    return [m for m in all_models if (m.split('_')[1] == model.split('_')[1]) & (m != model)][0]



def FastTrack_DE_data_table(df_input = None):

    df = df_input

    # df = df.loc[:, df.columns[0:20]]
    #
    #
    #
    # columns = [
    #     dict(id='dtdate', name='dtdate'),
    #     dict(id='total_vol_pul', name='total_vol_pul'),
    #     dict(id='neg_mrgn_vol_pul', name='neg_mrgn_vol_pul'),
    #     dict(id='shr_neg_mrgn', name='shr_neg_mrgn'),
    #
    #     # dict(id='Discounts', name='Discounts',
    #     #      type='numeric', format=Format(precision=4),
    #     #      # editable = True
    #     #      ),
    # ]

    columns = [{"name": i, "id": i} for i in df.columns]

    columns=[
        {"name": i, "id": i,
         # Для поля BirthDate используем type="datetime" и format для нужного формата вывода
         "type": "datetime",
         # "format": dash_table.Format.Format(
         #     scheme=dash_table.Format.Scheme(
         #         year='numeric',
         #         month='short',
         #         day='numeric',
         #         hour24=True
         #     )
         # )
        } if i in DE_files_date_fields else {"name": i, "id": i}
        for i in df.columns
    ]

    # Стили таблицы
    styles = {
        # Общие настройки стиля ячейки
        'cell': {'padding': '1px',
                 'textAlign': 'right',
                 'color': 'darkblue',
                 },

        # Заголовок таблицы
        'header': {
            'backgroundColor': '#3D9970',
            'color': 'white',
            'fontWeight': 'bold',
            'textAlign': 'center'
        },

        # Четные строки
        'oddRows': {
            'backgroundColor': '#F2F2F2'
        },

        # Нечетные строки
        'evenRows': {
            'backgroundColor': 'white'
        },

        # Нечетные строки
        'datetime':
        {
            'textAlign': 'left',
            # 'type': 'datetime',
            'format': '%YYYY',
            'color': 'darkred'
        }


    }



    return dash_table.DataTable(id = 'FastTrack_DE_data_table_id',
                                data=df.to_dict('records'),
                                # columns=[{'id': c, 'name': c} for c in df.columns],
                                columns = columns,

                                page_action="native",
                                # page_count=10,
                                page_current=16,  # текущая страница
                                # page_size=10,  # строк на странице

                                fixed_rows={"headers": True},
                                # page_size=15,
                                style_table={'height': '500px', 'overflowY': 'auto'},
                                editable=False,

                                style_cell=styles['cell'],
                                style_header=styles['header'],


                                style_data_conditional=[
                                    {   # Чётные строки
                                        'if': {'row_index': 'odd'},
                                        **styles['oddRows']  # Применяем стили чётных строк
                                    },
                                    {   # Нечётные строки
                                        'if': {'row_index': 'even'},
                                        **styles['evenRows']  # Применяем стили нечётных строк
                                    },
                                    {
                                        'if': {'column_id': 'dtdate'},
                                        **styles['datetime']
                                     }
                                ]

                                # style_header={'textAlign': 'center'},
                                # style_cell = {'textAlign': 'center'},

                                # style_cell_conditional = [
                                #                              {
                                #                                  'if': {'column_id': 'Discounts'},
                                #                                  'textAlign': 'right',
                                #                              }
                                #                          ],
                                )

def empty_graph_template() -> go.Figure:

    fig = go.Figure()

    fig.update_layout(
        xaxis=dict(
            visible=False
        ),
        yaxis=dict(
            visible=False
        ),
        paper_bgcolor="#33384c",
        plot_bgcolor="#33384c",
        font=dict(color="grey", size=14),
        annotations=[dict(
            text="Нет данных для отображения",
            xref="paper",
            yref="paper",
            showarrow=False,
            x=0.5,
            y=0.5,
            xanchor="center",
            yanchor="middle"
        )],
    )
    
    return fig

def fasttrack_plot_blocks_signals(model_df: pd.DataFrame, add_pattern: bool = True):
    
    # palette = px.colors.qualitative.Bold
    
    palette = [
        'rgb(127, 60, 141)',
        'rgb(17, 165, 121)',
        'rgb(57, 105, 172)',
        'rgb(242, 183, 1)',
        'rgb(231, 63, 116)',
        'rgb(230, 131, 16)',
    ]

    blocks = sorted(model_df["block"].unique())
    block_colors = {block: palette[i % len(palette)] for i, block in enumerate(blocks)}

    fig = go.Figure()
    
    for block in blocks:

        block_slice = model_df.loc[model_df['block'] == block].sort_values('report_date')

        base_color = block_colors[block]
        r, g, b = extract_rgb(base_color)

        colors = [f"rgba({r},{g},{b},{1 if s == 1 else 0.2})" for s in block_slice["signal_arch"]]
        
        if add_pattern:
            pattern_seq1 = np.where(block_slice['signal_disappeared'].values == 0, '', '/')
            pattern_seq2 = np.where(block_slice['signal_appeared'].values == 0, '', '.')
            pattern_seq = np.where(pattern_seq1 != '', pattern_seq1, pattern_seq2)
        else:
            pattern_seq = ['' for _ in block_slice['report_date']]

        fig.add_trace(go.Bar(
            x=block_slice['report_date'],
            y=[1] * len(block_slice),
            name=block,
            marker_color=colors,
            marker_line_width=0,
            legendgroup=block,
            showlegend=False,
            hovertemplate="Блок: <b>%{fullData.name}</b><br>Сигнал (на дату): <b>%{customdata[0]}</b><br>Сигнал (текущий): <b>%{customdata[1]}</b>", #Дата: %{x|%d.%m.%Y}<br>
            hoverlabel=dict(font_size=15),
            customdata=block_slice[["signal_arch", "signal_act"]],
            marker_pattern_shape=pattern_seq
        ))

        fig.add_trace(go.Bar(
            x=[None],
            y=[None],
            name=block,
            marker_color=base_color,
            marker_line_width=0,
            legendgroup=block,
        ))

    fig.update_layout(
    #     title='target_'+target_type,
        xaxis=dict(
            # tickformat='%d.%m.%Y', 
            tickmode="array",
            tickvals=block_slice['report_date'],
            ticktext=[date.strftime("%d.%m.%Y") for date in block_slice['report_date']],
            # dtick=7*24*60*60*1000,
            # ticklabelmode="period",
            showgrid=False, 
            showline=False, 
            zeroline=False,
            # tickangle=-45,
            automargin=True,
        ),
        yaxis=dict(
            tickformat='%d.%m.%Y',
            showgrid=False, 
            showline=False, 
            zeroline=False, 
            showticklabels=False
        ),
        legend=dict(
            title_text="Блок",
            # title_side="top",
            traceorder="reversed",
            tracegroupgap = 10,
            # yanchor="top",
            # y=1,
            # xanchor="left",
            # x=0,
            # itemsizing="constant",
            # itemwidth=100,
        ),
        barmode='relative',
        paper_bgcolor="#1f2237",
        plot_bgcolor="#262A44",
        font=dict(color="darkgrey", size=14),
        margin=dict(l=20, r=0.1, t=20, b=30),
        # hovermode="x",
        # height=600,
        # width=1200
    )

    return fig