var dagcomponentfuncs = window.dashAgGridComponentFunctions = window.dashAgGridComponentFunctions || {};

dagcomponentfuncs.CustomNoRowsOverlay = function (props) {
    return React.createElement(
        'div',
        {
            style: {
                // border: '1pt solid grey',
                color: props.color || 'grey',
                padding: 10,
                fontSize: props.fontSize || 14
            },
        },
        props.message
    );
};

dagcomponentfuncs.SignalRenderer = function (props) {
    const color = props.value === 1 ? '#ffc107' : 'gray';
    return React.createElement(
        'div', 
        {
            style: {
                width: '14px',
                height: '14px',
                borderRadius: '50%',
                backgroundColor: color,
                margin: 'auto',
            }
        }, 
    );
};