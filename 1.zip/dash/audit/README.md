# Модуль аудита (dash/audit)

Модуль предоставляет систему аудита действий пользователей для приложения Dash с поддержкой различных типов операций и интеграцией с Fluent Bit.

## Структура модуля

```
dash/audit/
└── audit_logger.py
└── middleware.py
```

### audit_logger.py

**Аудит-логгер** - основной класс для записи аудиторских событий в формате JSON и отправки их в Fluent Bit или вывода в лог в режиме отладки.

**Ключевые особенности:**

- Использование контекстных переменных для хранения информации о пользователе в рамках запроса
- Поддержка двух режимов работы: отладка (логирование) и продакшн (отправка в Fluent Bit)
- Автоматическая генерация временных меток и ID трассировки
- Структурированные типы аудиторских событий согласно классификации операций

**Контекстные переменные:**

- `_current_user_login` - логин текущего пользователя (по умолчанию 'UNKNOWN')
- `_current_user_ip` - IP адрес текущего пользователя (по умолчанию 'UNKNOWN')

**Классы:**

- `AuditLogger` - основной класс для аудита действий

**Глобальные функции:**

- `init_audit_logger(debug_mode: bool = False)` - инициализация глобального аудит-логгера из переменных окружения
- `get_audit_logger() -> AuditLogger` - получение экземпляра аудит-логгера
- `set_current_user(user_login: str, user_ip: str)` - установка контекста пользователя для текущего запроса

**Методы AuditLogger:**

- `set_user_context(user_login: str, user_ip: str)` - установка контекста пользователя для текущего запроса
- `audit_read_fiscal(object_name: str, object_id: str, description: str = "Read fiscal data", status: str = "SUCCESS")` - аудит чтения фискальных данных (C1)
- `audit_update_fiscal(object_name: str, object_id: str, object_properties: List[str], description: str = "Update fiscal data", status: str = "SUCCESS")` - аудит обновления фискальных данных (C3)
- `audit_drop_fiscal(object_name: str, object_id: str, description: str = "Drop fiscal data", status: str = "SUCCESS")` - аудит удаления фискальных данных (C5)
- `audit_read_data(object_name: str, object_id: str, description: str = "Read data", status: str = "SUCCESS")` - аудит чтения данных (общий) (C7)
- `audit_other_operation(description: str, status: str = "SUCCESS", b_system_id: Optional[str] = None, system_id_fp: Optional[str] = None)` - аудит прочих операций (C0)

**Внутренние методы:**

- `_get_user_context()` - получение контекста пользователя
- `_get_current_datetime()` - получение текущей даты-времени в формате ISO
- `_generate_trace_id()` - генерация уникального ID трассировки
- `_send_audit_data(data: dict)` - отправка или логирование аудита в зависимости от режима

**Типы операций:**

- **C1** - Чтение фискальных данных
- **C3** - Обновление фискальных данных
- **C5** - Удаление фискальных данных
- **C7** - Общее чтение данных
- **C0** - Прочие операции

**Статические поля аудита:**

- `app_id` - идентификатор приложения
- `type_id` - тип события (всегда "Audit")
- `system` - система (всегда "audit")
- `B_SystemID` - идентификатор системы
- `SystemID_FP` - идентификатор ФП
- `PROCESS_NAME` - название процесса

**Переменные окружения:**

- `audit_host` - хост Fluent Bit сервиса (по умолчанию: 'palm-monitoring-client-logger-svc')
- `audit_port` - порт Fluent Bit сервиса (по умолчанию: 24225)
- `audit_PROCESS_NAME` - название процесса (по умолчанию: "AI-Казначей")
- `audit_APP_ID` - идентификатор приложения (по умолчанию: "PALMSANDBOXUI-CI04747619-CI06357758-202409250000000000")
- `audit_B_SystemID` - идентификатор системы (по умолчанию: "CI02797118")
- `SystemID_FP` - идентификатор ФП (по умолчанию: "CI04747619")

### middleware.py

**Middleware для Flask** - автоматическая установка контекста пользователя перед каждым запросом на основе данных сессии.

**Функции:**

- `setup_user_context()` - middleware для установки контекста пользователя перед каждым запросом

**Особенности:**

- Интегрируется с Flask сессиями для автоматического получения данных пользователя
- Извлекает логин пользователя из `session['user']['login']` (по умолчанию 'UNKNOWN')
- Извлекает IP адрес пользователя из `session['user']['ip']` (по умолчанию 'UNKNOWN')
- Автоматически вызывает `set_current_user` для установки контекста

**Использование в Flask приложении:**

```python
from flask import Flask
from dash.audit.middleware import setup_user_context

app = Flask(__name__)

# Регистрация middleware
app.before_request(setup_user_context)
```

## Использование

```python
from dash.audit.audit_logger import init_audit_logger, get_audit_logger, set_current_user

# Инициализация аудит-логгера
init_audit_logger(debug_mode=True)  # В режиме отладки логирует в консоль

# Получение экземпляра логгера
audit_logger = get_audit_logger()

# Установка контекста пользователя (вручную или через middleware)
set_current_user("user123", "192.168.1.100")

# Запись аудиторских событий
audit_logger.audit_read_fiscal(
    object_name="tax_report",
    object_id="report_2024",
    description="Чтение налогового отчета"
)

audit_logger.audit_update_fiscal(
    object_name="tax_report",
    object_id="report_2024",
    object_properties=["amount", "date"],
    description="Обновление налогового отчета"
)
```

## Интеграция с Flask

```python
from flask import Flask
from dash.audit.middleware import setup_user_context

app = Flask(__name__)
app.before_request(setup_user_context)
```

## Поток данных

1. **Инициализация** - настройка аудит-логгера с параметрами из переменных окружения

2. **Установка контекста** - автоматическое определение пользователя и IP через middleware или ручная установка

3. **Запись события** - вызов соответствующего метода для типа операции

4. **Форматирование** - сборка структурированных данных с метаданными

5. **Отправка** - передача в Fluent Bit (продакшн) или логирование (отладка)

## Пример сообщения

```json
{
  "@timestamp": "2025-10-10T13:49:20.300733Z",
  "app_id": "PALMSANDBOXUI-CI04747619-CI06357758-202409250000000000",
  "type_id": "Audit",
  "system": "audit",
  "B_SystemID": "CI02797118",
  "SystemID_FP": "CI04747619",
  "PROCESS_NAME": "AI-Казначей",
  "USER_LOGIN": "12201312",
  "IP_ADDRESS": "0.0.0.0",
  "subtype_id": "C0",
  "B_Event": "Выполнение операции 'Создание аналитических отчетов",
  "event_name": "Выполнение операции 'Создание аналитических отчетов",
  "DESCRIPTION": "Выполнение операции 'Создание аналитических отчетов",
  "STATUS": "SUCCESS",
  "OPERATION_DATE": "2025-10-10T13:49:20Z",
  "TRACE_ID": "d722fc40-16ba-4830-bec9-0b9e7e8d4689"
}
```
