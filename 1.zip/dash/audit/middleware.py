# dash/audit/middleware.py
from flask import session

from .audit_logger import set_current_user


def setup_user_context():
    """Middleware для установки контекста пользователя перед каждым запросом"""
    user_data = session.get('user', {})
    user_login = user_data.get('login', 'UNKNOWN')
    user_ip = user_data.get('ip', 'UNKNOWN')

    set_current_user(user_login, user_ip)
