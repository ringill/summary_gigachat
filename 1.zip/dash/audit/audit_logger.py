# dash/audit/audit_logger.py
import json
import logging
import os
import socket
import uuid
from contextvars import ContextVar
from datetime import datetime
from typing import List, Optional

# Контекстные переменные для хранения информации о пользователе в рамках запроса
_current_user_login: ContextVar[str] = ContextVar('current_user_login', default='UNKNOWN')
_current_user_ip: ContextVar[str] = ContextVar('current_user_ip', default='UNKNOWN')

class AuditLogger:
    def __init__(self,
                 host: str,
                 port: int,
                 process_name: str,
                 app_id: str,
                 b_systemid: str,
                 systemid_fp: str,
                 debug_mode: bool = False):
        self.host = host
        self.port = port
        self.debug_mode = debug_mode
        self.static_data = {
            "app_id": app_id,
            "type_id": "Audit",
            "system": "audit",
            "B_SystemID": b_systemid,
            "SystemID_FP": systemid_fp,
            "PROCESS_NAME": process_name
        }

    def set_user_context(self, user_login: str, user_ip: str):
        """Установка контекста пользователя для текущего запроса"""
        _current_user_login.set(user_login)
        _current_user_ip.set(user_ip)

    def _get_user_context(self):
        """Получение контекста пользователя"""
        return {
            "USER_LOGIN": _current_user_login.get(),
            "IP_ADDRESS": _current_user_ip.get()
        }

    def _get_current_datetime(self):
        """Текущая дата-время в нужном формате"""
        return datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")

    def _generate_trace_id(self):
        """Генерация ID трассировки"""
        return str(uuid.uuid4())

    def _send_audit_data(self, data: dict):
        """Отправка или логирование аудита в зависимости от режима"""
        # Добавляем обязательные поля
        data.update({
            "OPERATION_DATE": self._get_current_datetime(),
            "TRACE_ID": self._generate_trace_id()
        })

        # Убираем None значения
        audit_data = {k: v for k, v in data.items() if v is not None}

        if self.debug_mode:
            # В режиме отладки - логируем
            logging.info(f"AUDIT (DEBUG MODE): {json.dumps(audit_data, ensure_ascii=False, indent=2)}")
            return True
        else:
            # В продакшн - отправляем в fluent-bit
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.connect((self.host, self.port))
                    json_str = json.dumps(audit_data, ensure_ascii=False) + "\n"
                    json_bytes = json_str.encode('utf-8')
                    sock.sendall(json_bytes)
                logging.debug(f"Audit data sent to {self.host}:{self.port}")
                return True
            except Exception as e:
                logging.error(f"Failed to send audit data: {e}")
                return False

    # C1 - Read fiscal data
    def audit_read_fiscal(self, object_name: str, object_id: str, description: str = "Read fiscal data", status: str = "SUCCESS"):
        """Аудит чтения фискальных данных"""
        data = {
            **self.static_data,
            **self._get_user_context(),
            "subtype_id": "C1",
            "B_Event": description,
            "event_name": description,
            "OBJECT_NAME": object_name,
            "OBJECT_ID": object_id,
            "DESCRIPTION": description,
            "STATUS": status
        }
        return self._send_audit_data(data)

    # C3 - Update fiscal data
    def audit_update_fiscal(self, object_name: str, object_id: str, object_properties: List[str], description: str = "Update fiscal data", status: str = "SUCCESS"):
        """Аудит обновления фискальных данных"""
        data = {
            **self.static_data,
            **self._get_user_context(),
            "subtype_id": "C3",
            "B_Event": description,
            "event_name": description,
            "OBJECT_NAME": object_name,
            "OBJECT_ID": object_id,
            "OBJECT_PROPERTIES": object_properties,
            "DESCRIPTION": description,
            "STATUS": status
        }
        return self._send_audit_data(data)

    # C5 - Drop fiscal data
    def audit_drop_fiscal(self, object_name: str, object_id: str, description: str = "Drop fiscal data", status: str = "SUCCESS"):
        """Аудит удаления фискальных данных"""
        data = {
            **self.static_data,
            **self._get_user_context(),
            "subtype_id": "C5",
            "B_Event": description,
            "event_name": description,
            "OBJECT_NAME": object_name,
            "OBJECT_ID": object_id,
            "DESCRIPTION": description,
            "STATUS": status
        }
        return self._send_audit_data(data)

    # C7 - Read data (общее чтение)
    def audit_read_data(self, object_name: str, object_id: str, description: str = "Read data", status: str = "SUCCESS"):
        """Аудит чтения данных (общий)"""
        data = {
            **self.static_data,
            **self._get_user_context(),
            "subtype_id": "C7",
            "B_Event": description,
            "event_name": description,
            "OBJECT_NAME": object_name,
            "OBJECT_ID": object_id,
            "DESCRIPTION": description,
            "STATUS": status
        }
        return self._send_audit_data(data)

    # C0 - Other operations
    def audit_other_operation(self, description: str, status: str = "SUCCESS",
                          b_system_id: Optional[str] = None,
                          system_id_fp: Optional[str] = None):
        """Аудит прочих операций"""
        data = {
            **self.static_data,
            **self._get_user_context(),
            "subtype_id": "C0",
            "B_Event": description,
            "event_name": description,
            "DESCRIPTION": description,
            "STATUS": status
        }

        # Добавляем опциональные поля если они есть
        if b_system_id:
            data["B_SystemID"] = b_system_id
        if system_id_fp:
            data["SystemID_FP"] = system_id_fp

        return self._send_audit_data(data)

# Глобальный экземпляр аудит-логгера (будет инициализирован при старте приложения)
_audit_logger: Optional[AuditLogger] = None

def init_audit_logger(debug_mode: bool = False):
    """Инициализация глобального аудит-логгера из переменных окружения"""
    global _audit_logger

    # Получаем настройки из переменных окружения
    host = os.getenv('audit_host', 'palm-monitoring-client-logger-svc')
    port = int(os.getenv('audit_port', '24225'))
    process_name = os.getenv('audit_PROCESS_NAME', "AI-Казначей")
    app_id = os.getenv('audit_APP_ID', "PALMSANDBOXUI-CI04747619-CI06357758-202409250000000000")
    b_systemid = os.getenv('audit_B_SystemID', "CI02797118")
    systemid_fp = os.getenv('SystemID_FP', "CI04747619")

    _audit_logger = AuditLogger(host,
                                port,
                                process_name,
                                app_id,
                                b_systemid,
                                systemid_fp,
                                debug_mode)

    # Логируем настройки подключения
    logging.info(f"Audit logger configured - Host: {host}, Port: {port}, Debug: {debug_mode}")

    return _audit_logger

def get_audit_logger() -> AuditLogger:
    """Получение экземпляра аудит-логгера"""
    if _audit_logger is None:
        raise RuntimeError("Audit logger not initialized. Call init_audit_logger first.")
    return _audit_logger

def set_current_user(user_login: str, user_ip: str):
    """Установка контекста пользователя для текущего запроса"""
    if _audit_logger:
        _audit_logger.set_user_context(user_login, user_ip)
