# dash/layouts.py
import logging
from datetime import date
import pandas as pd

import dash_ag_grid as dag
import dash_bootstrap_components as dbc
import dash_daq as daq
from dash import dcc, html

from config import app_config
from enums import CalcState, CalcMessage

from dash_graphs import (
    Factor_Set_Table,
    MA_Block_Graph,
    MA_Model_Graph,
    Main_Hist_Graph,
    empty_graph_template,
    model_desc,
)
from data_preparation_RUB import Direction_sign, Factor_Value_desc, Get_Recomend_df, Trigger
from utils import Get_Folders_in_Folder


def generate_section_banner(title, style = None):

    if style == None:
        return html.Div(className="section-banner", children=title)
    elif style == 'factors':
        return html.Div(className="section-banner",
                        children=title,
                        style={'font-size': 15, "align": "right", 'color' : 'orange'})


# Основной банер над всеми окнами
def build_banner():
    return html.Div(
        id="banner",
        className="banner",
        children=[
            html.Div(
                id="banner-text",
                children=[
                    html.H5("AI Казначей"),
                    html.H6("Рекомендации изменения ЕТС"),
                ],
            ),
            #            html.Div(
            #                id="banner-logo",
            #                children=[
            #                    html.Button(
            #                        id="learn-more-button", children="LEARN MORE", n_clicks=0
            #                    ),
            #                     html.Img(id="logo", src=app.get_asset_url("dash-logo-new.png")),
            #                ],
            #            ),
        ],
    )


# Layout всех закладок
def layout_tabs(tab_id: str):
    return html.Div(
        id="tabs",
        className="tabs",
        children=[
            dcc.Tabs(
                id="app-tabs",
                value=tab_id,  # По умолчанию открываем Анализ модели
                className="custom-tabs",
                # children=[
                #     dcc.Tab(
                #         id="Model-analize-tab",
                #         label="Анализ модели",
                #         value="tab4",
                #         className="custom-tab",
                #         selected_className="custom-tab--selected",
                #     ),
                # ],
            )
        ],
    )


# Tab с основным графиком
def layout_tab_graph():
    return html.Div([

                # Верхний блок
                html.Div([
                        # Парамерты основного график
                        html.Div([
                                    # html.Div(generate_section_banner("Бэктест на истории изменений ЕТС USD"),
                                    #        style={"margin-top": "1rem"},
                                    #        className="three columns"),

                                  # ==============================================================
                                  # Кривая ЕТС
                                  html.Div([
                                      html.H6(["Кривая ЕТС"],
                                              className="subtitle padded",
                                              style={'font-size': 20}
                                              ),
                                      dcc.RadioItems(
                                          id='RI_ftp_curve_part',
                                          options=[
                                              {'label': ' Короткий конец', 'value': 'short'},
                                              {'label': ' Длинный конец', 'value': 'long'},
                                              # {'label': ' Вся кривая', 'value': 'all'}
                                          ],
                                          value='short',
                                          #labelStyle={'display': 'inline-block'},
                                          style={'font-size': 16,
                                                 'color': 'darkgray'}
                                      ),




                                  ],
                                      style={'padding-left': '2rem'},
                                      className="two columns"
                                  ),

                                # ==============================================================
                                #Изменения ЕТС
                                html.Div([
                                    html.H6(["Изменения ЕТС"],
                                            className="subtitle padded",
                                            style={'font-size': 18}
                                            ),

                                    html.Div([
                                        # html.Div('Агрегация',
                                        #          className="four columns",
                                        #          style={'padding-top': '1rem', 'color': 'darkgrey'}),

                                        # ToggleSwitch
                                        html.Div(daq.ToggleSwitch(id='Switch_ЕТС_hist',
                                                                  className='switch-toggle',
                                                                  # label='Агрегация',
                                                                  labelPosition='right',
                                                                  value=True,
                                                                  color='orange'),

                                                 style={'align': 'left', 'width': '35%'}
                                                 ),


                                        # текущая дата
                                        # html.Div('....',
                                        #          id='materials_button_date',
                                        #          style={
                                        #              "margin-top": "0.2rem",
                                        #              "font-size": 16,
                                        #              'color': 'darkgrey',
                                        #              'font-family': "Open Sans, sans-serif"
                                        #          }
                                        #
                                        #          ),




                                        # Кнопка просмотра истории
                                        # html.Button('Метериалы',
                                        #             id = 'materials_button',
                                        #             n_clicks = 0,
                                        #             style={#"margin-top": "1rem",
                                        #                    #"align": "left",
                                        #                    #"margin left": 0,
                                        #                    "font-size": 13,
                                        #                    'color': 'darkgrey',
                                        #                    'font-family': "Open Sans, sans-serif"
                                        #                    #'height': 12
                                        #             }
                                        #             ),



                                        # # Статус нажатой кнопки
                                        # html.Div('',
                                        #          id='materials_button_status',
                                        #          style={
                                        #              "margin-top": "0.5rem",
                                        #              "font-size": 14,
                                        #              'color': 'darkgrey',
                                        #              'font-family': "Open Sans, sans-serif"
                                        #          }
                                        #
                                        #          ),

                                    ]),
                                ], className='two columns'),

                                # ==============================================================
                                # Агрегация
                                html.Div([
                                  html.H6(["Агрегация"],
                                          className="subtitle padded",
                                          style={'font-size': 18}
                                          ),

                                  # Агрегация
                                  html.Div([
                                      html.Div('Агрегация',
                                               className="four columns",
                                               style={'padding-top': '1rem',
                                                      'padding-left': '1rem',
                                                      'color': 'darkgrey',
                                                      'min-width': '50%',
                                                      'max-width': '50%',
                                                      'font-size': 16
                                                      }),

                                      # ToggleSwitch
                                      html.Div(daq.ToggleSwitch(id='Switch_Agr',
                                                                className='switch-toggle',
                                                                #label='Агрегация',
                                                                labelPosition='right',
                                                                value=True,
                                                                color='orange'),

                                               style={'align': 'right', 'width': '85%'}
                                               ),
                                  ]),


                                ],
                                className='two columns'),

                                # ==============================================================
                                # Парамметры агрегации
                                html.Div([
                                    html.H6(["Парамметры агрегации"],
                                            className="subtitle padded",
                                            style={'font-size': 18}
                                            ),
                                    # Пороги
                                    html.Div([
                                        html.Div('Пороги',
                                                 className="three columns",
                                                 style={'padding-top': '1rem',
                                                        'padding-left': '1rem',
                                                        'color': 'darkgrey',
                                                        'min-width': '50%',
                                                        'max-width': '50%',
                                                        'font-size': 16
                                                        }),

                                        # ToggleSwitch
                                        html.Div(daq.ToggleSwitch(id='Switch_Treshold',
                                                                  className='switch-toggle',
                                                                  label='',
                                                                  labelPosition='right',
                                                                  value=False,
                                                                  color='orange'),

                                                 style={'align': 'right', 'width': '85%'}),
                                    ]),

                                    # Складывать сигналы
                                    html.Div([
                                        html.Div('Складывать сигналы',
                                                 className="four columns",
                                                 style={'padding-top': '1rem',
                                                        'padding-left': '1rem',
                                                        'color': 'darkgrey',
                                                        'min-width': '50%',
                                                        'max-width': '50%',
                                                        'font-size': 16
                                                        }),

                                        # ToggleSwitch
                                        html.Div(daq.ToggleSwitch(id='Switch_Sum_Recomend',
                                                                  className='switch-toggle',
                                                                  # label='Агрегация',
                                                                  labelPosition='left',
                                                                  value=False,
                                                                  color='orange'),

                                                 style={'align': 'right', 'width': '85%'}
                                                 ),
                                    ]),


                                ],
                                    className='two columns'),

                                # ==============================================================
                                # Диапазон дат
                                html.Div([
                                    html.H6(["Диапазон дат"],
                                            className="subtitle padded",
                                            style={'font-size': 18}
                                            ),

                                    dcc.DatePickerRange(
                                        id = 'main_graph_datapicker',
                                        month_format='DD.MM.YYYY',
                                        max_date_allowed=Trigger.Hist_Last_date,
                                        min_date_allowed=Trigger.Hist_Start_date,

                                        start_date = Trigger.Hist_Start_date,
                                        end_date=Trigger.Hist_Last_date,

                                        start_date_placeholder_text= 'DD.MM.YYYY',
                                        end_date_placeholder_text='DD.MM.YYYY',
                                        display_format='DD.MM.YYYY',
                                        number_of_months_shown=1,

                                        style={'font-size': 14,
                                               'display':'inline-block',
                                               'border-radius': '2px',
                                               'border': '1px solid #ccc', 'color': '#333',
                                               'border-spacing': '0', 'border-collapse': 'separate',
                                               'width':'125%'

                                               },
                                        day_size=60
                                    )

                                ],
                                className='two columns'),


                                # Режим
                                # html.Div([
                                #     html.H6(["Режим"],
                                #             className="subtitle padded",
                                #             style={'font-size': 18}
                                #             ),
                                #     # Калибровка
                                #     html.Div([
                                #       html.Div('Калибровка',
                                #                className="four columns",
                                #                style={'padding-top': '1rem',
                                #                       'padding-left': '1rem',
                                #                       'color': 'darkgrey',
                                #                       'min-width': '50%',
                                #                       'max-width': '50%',
                                #                       'font-size': 16
                                #                       }),
                                #
                                #       # ToggleSwitch
                                #       html.Div(daq.ToggleSwitch(id='Switch_Calibration',
                                #                                 className='switch-toggle',
                                #                                 label='',
                                #                                 labelPosition='right',
                                #                                 value=False,
                                #                                 color='orange'),
                                #
                                #                style={'align': 'right', 'width': '85%'}),
                                #        ]),
                                # ],
                                # className='two columns'),

                                  # Фильтр по факторам...
                                  # html.Div([
                                  #     # dcc.Dropdown(
                                  #     #     id='Factor_Dropdown_Main_Hist_Graph',
                                  #     #     options=[{'label': Trigger.df_Factor_Set['factor_desc'].loc[i],
                                  #     #               'value': i} for i
                                  #     #              in Trigger.Factor_list],
                                  #     #     value="",  # Trigger.Factor_list[0],
                                  #     #     searchable=False,
                                  #     #     placeholder='Фильтр по факторам...',
                                  #     #     style={"margin-top": "1rem",
                                  #     #            "align": "left",
                                  #     #            "margin left": 0,
                                  #     #            "font-size": 16,
                                  #     #            'height': 12}
                                  #     # )
                                  # ], className="three columns"),

                                  ], className="row"),

                        # Основной график
                        # html.Div([dcc.Graph(id='Main_Hist_Graph', hoverData={'points': [{'x': '2019-03-15'}]})]),
                        html.Div([dcc.Graph(id='Main_Hist_Graph',
                                            figure=Main_Hist_Graph(
                                                                    Switch_Treshold = False,
                                                                    Switch_Agr = True,
                                                                    filter_factor = False,
                                                                    Switch_ЕТС_hist = True,
                                                                    RI_ftp_curve_part = 'short'
                                                                   ),
                                            hoverData={'points': [{'x': '2023-10-13'}]}
                                            )]),

                        # Скрытый Div
                        html.Div(id='hv_1', style={'display': 'none'}),
                        # Скрытый Div
                        html.Div(id='hv_2', style={'display': 'none'}),
                        # Скрытый Div
                        html.Div(id='hv_3', style={'display': 'none'})
                    ]),

                # Store для хранения hover-datы
                dcc.Store(id = 'Main_graph_hover_date_store'),

                # Разделительная линия
                html.Div([], style = {'border-bottom': '2px solid #4b5460',
                                      'padding-top':'1rem'}),

                # Блок под основным графиком
                html.Div(Hist_Graph_bottom_Factors(),# Hist_Graph_bottom('factors_calibr'),
                         id="tab_graph_2",
                         className="row"),
                ], #id="tab_graph",
    )

# Таb c описанием факторов
def layout_tab_factor():
    return html.Div([

            # Выбор и график с историей
            html.Div([
                # === Выбор фактора ===
                html.Div([
                        # Надпись: "Фактор"
                        html.Div(generate_section_banner("Фактор"),style={"padding-left": '1rem'}),

                        # Выбор фактора
                        html.Div([
                                dcc.RadioItems(
                                    id='Factor_Dropdown',
                                    options=[{'label': '  ' + Trigger.df_Factor_Dict['factor_desc'].loc[i], 'value': i}
                                             for i in
                                             Trigger.Factor_list],
                                    value=Trigger.Factor_list[0],

                                    #clearable = False,
                                    style={"margin-top": "1rem",
                                           "Align": "left",
                                           "padding-left": '2rem',
                                           'overflow-y':'scroll',
                                           'height': '400px'}
                                            )],
                                #id="trigger_graph",

                                ),
                        ], className="three columns"),

                # === График с историей фактора ===
                html.Div([
                        html.Div(
                            # id="factor_level_graph",
                            className="twelve columns",
                            children=[
                                generate_section_banner("История фактора"),
                                dcc.Graph(id='Main_Factor_Graph',
                                          # hoverData={'points': [{'x': '2019-03-15'}]}
                                          # figure=Main_Factor_Graph(Trigger.Factor_list[0])
                                          )

                                    ],

                                ),

                        ],className="nine columns"),
                     ],
                     className="row"),


            # === Фичи от фактора ===
            html.Div([
                    # Используемые фичт
                    html.Div(
                        className="three columns",
                        children=[
                            html.Div(generate_section_banner("Используемые фичи фактора"), style={"padding-left": '1rem'}),
                            html.Div(
                                id="Factor_Features_Table_Main",
                                # children=[Factor_Features_Table(Trigger.Factor_list[0])]
                                     ),
                        ],
                        style={"margin-top": "1rem",
                               "Align": "left",
                               "padding-left": '2rem',
                                                              }
                    ),

                    # Рекомендация от пробития фактора
                    html.Div(
                        id="features_level_graph",
                        className="nine columns",
                        children=[
                            generate_section_banner("История фичи"),
                            dcc.Graph(id='Main_Feature_Graph',
                                      # hoverData={'points': [{'x': '2019-03-15'}]}
                                      # figure=Main_Feature_Graph('Roisfix_1Y_delta_3', 'long_down')
                                      )
                        ],
                    ),
                ],
                     className="row"),

            # Табличка с уровнями фичи
            html.Div([
                    # Используемые фичт
                    html.Div(
                        className="three columns",
                        # children=[ ],
                        style={"margin-top": "1rem",
                               "Align": "left",
                               "padding-left": '2rem',
                               }
                    ),

                    html.Div(
                        className="nine columns",
                        children=[
                            html.Div(generate_section_banner("Уровни пробития фичей"),
                                     style={"padding-left": '1rem',
                                            "padding-top": '2rem',
                                            }),
                            html.Div(
                                id="Factor_Features_Table_Desc",
                                # children=[Feature_Levels_Table('Mosprime_1W_delta_3', 'long_down')],
                                style={"padding-left": '2rem',
                                       "padding-right": '25rem',
                                       "padding-top": '1rem'
                                       }
                                # children=[Factor_Features_Table(Trigger.Factor_list[0])]
                            ),
                        ],
                    ),
                ],
                     className="row"),

            html.Pre(id='my_output_factor', children=['FFFFFFFF'], style={'display': 'True'}),
            html.Pre(id='hover_data_factor', children=['FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'], style={'display': 'True'})
        ]
    )

# Таb c калибровкой факторов
def layout_tab_factor_set():
    return html.Div(
        id="tab_factor_set",
        children=[

            # === Выбор фактора и его вес ===
            html.Div(
                #id="tab_graph_1",
                className="row",

                children=[
                    # Надпись: "Настроичная таблица влияния факторов"

                    html.Div([
                        html.Div(className="four columns",
                                 children=html.H6('Настроичная таблица влияния факторов'),
                                 style={"height": "5rem",
                                        #"width": "50%",
                                        "textAlign": "center",
                                        # "margin-top": "1rem"
                                        }),

                        html.Div(id = 'file_name_factor_set',
                                 children = 'Текущее имя файла: '+Trigger.path_Factor_Set,
                                 className="three columns",
                                 style={#"height": "5rem",
                                        # "width": "50%",
                                        "textAlign": "center",
                                         "margin-top": "1.5rem"
                                        }
                                 ),

                        html.Div([
                            html.A('Сохранить файл',
                                   id='download-link',
                                   download="Factor_settings.csv",
                                   href='Ссылка',
                                   target="_blank",
                                   style={
                                       'width': '100%',
                                   }
                                   ),
                                ],
                            className = "two columns",
                            style={'margin-top': '1.5rem',
                                   'height': '30px',
                                   'lineHeight': '30px',
                                   'borderWidth': '1px',
                                   'borderStyle': 'dashed',
                                   'borderRadius': '5px',
                                   'textAlign': 'center'
                                   }
                            ),

                        html.Div([
                            dcc.Upload(
                                id='upload-data',
                                children=html.Div([
                                    html.A('Загрузить файл')
                                ]),
                                style={
                                    'width': '70%',
                                    'height': '30px',
                                    'lineHeight': '30px',
                                    'borderWidth': '1px',
                                    'borderStyle': 'dashed',
                                    'borderRadius': '5px',
                                    'textAlign': 'center',
                                    'margin-top': '1.5rem'
                                },
                                # Allow multiple files to be uploaded
                                multiple=False,

                            ),

                        ],className="three columns"),



                    ],className = 'row'),

                    html.Div(
                        id='factor_set_table_div',
                        style={'padding': '3rem'},
                        children=[Factor_Set_Table()]
                    ),

                    html.Pre(children='factor_set_table_output',
                             id='factor_set_table_output'
                             )



                ],
            ),

        ]
    )

# # Выбор Layout под основным графиком
# def Hist_Graph_bottom(type,hover_date_str = ''):
#     if type == 'factors_details':
#         return Hist_Graph_bottom_Factors()
#     elif type == 'factors_calibr':
#         return Hist_Graph_bottom_Calibr()

# Layout под основным графиком с Калибровкой
# def Hist_Graph_bottom_Calibr():
#     return [
#         html.Div([
#             html.Div([
#                 # Выбор фактора и таблцы
#                 html.Div([
#                     html.Div([
#                         html.Div(['Фактор'],
#                                  style={"height": "5rem",
#                                         "textAlign": "right",
#                                         'padding-top':'1.5rem',
#                                         'padding-left': '1.5rem',
#                                         'color':'darkgrey'
#                                         #"width": "3%"
#                                         },
#                                  className = 'four columns'),
#
#                         # Выбор фактора
#                         html.Div([
#                                      dcc.Dropdown(
#                                          id='Factor_Dropdown_calibr',
#                                          options=[{'label': Trigger.df_Factor_Set['factor_desc'].loc[i], 'value': i} for i
#                                                   in Trigger.Factor_list],
#                                          value=Trigger.Factor_list[0],
#                                          clearable=False,
#                                          style={"margin-top": "1rem",
#                                                 "Align": "left",
#                                                 "margin left": 0}
#                                      )
#                                  ],className="eight columns"),
#                     ],className = 'row'),
#
#
#                     # Блок с таблицами
#                     html.Div([
#                         # Реакция на пробитие
#                         html.Div(
#                             className="eight columns",
#                             children=[
#                                 generate_section_banner("Реакция на пробитие уровней"),
#                                 html.Div(id='Factor_Reaction_Table_Calibr',
#                                          style={'padding-left': '0rem',
#                                                 'padding-top': '0.3rem'
#                                                 },
#                                          children = Factor_Reaction_Table_Calibr('Eurobond')
#                                          ),
#                             ],
#                         ),
#
#                         # Уровни пробитие
#                         html.Div(
#                             className="four columns",
#                             children=[
#                                 generate_section_banner("Уровни (верхняя граница)"),
#                                 html.Div(id='Factor_Level_Table_Calibr',
#                                          style={'padding-left': '0rem',
#                                                 'padding-top': '0.3rem'
#                                                 },
#                                          children=Factor_Level_Table('Eurobond', mode = 'Calibr')
#                                          ),
#                             ],
#                         ),
#                     ],className="rows"),
#
#                 ])
#             ],className = 'five columns'),
#
#             # === График с историей фактора ===
#                     # Факторы на поднятие
#             html.Div(id="factor_level_graph_calibr",
#                      className="seven columns",
#                      children=[
#                          generate_section_banner("История фактора"),
#                          dcc.Graph(id='Main_Factor_Graph_Calibr',
#                                    # hoverData={'points': [{'x': '2019-03-15'}]}
#                                    figure=Main_Factor_Graph('Eurobond', mode = 'Calibr')
#                                    )
#                      ],
#             ),
#
#
#         ],className = 'row'),
#
#
#         html.Pre(id='my_output', children=['FFFFFFFF'], style={'display': 'none'}),
#         html.Pre(id='hover-data', children=['FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'], style={'display': 'none'})
#
#     ]

# Layout под основным графиком с Рекомендациями
def Hist_Graph_bottom_Factors():

    return [
                    # Факторы на поднятие
                    html.Div(
                        id="factor_Up",
                        className="six columns",
                        children=[
                            html.Div(
                                id="factor_Up_banner",
                                children=[generate_section_banner("Факторы повышения ЕТС",'factors')],
                                # children=[html.Div(className="section-banner",
                                #                    children="Факторы повышения ЕТС",
                                #                    style={'font-size': 15, "align": "right", 'color' : 'orange'})],
                                #
                                #

                                # style={'font-size': 45, "align": "right", 'color' : 'orange'}

                            ),

                            html.Div(
                                id="factor_Up_div",
                                children=[
                                    generate_metric_list_header(),
                                    html.Div(id="factor_Up_rows",
                                             # children = Factor_Weight_Rows('factor_Up_Bar', pd.to_datetime("2017-01-13", format='%Y-%m-%d'), 'Up','up')
                                             )]),
                        ],
                    ),

                    # Факторы на снижение
                    html.Div(
                        id="factor_Down",
                        className="six columns",
                        children=[
                            html.Div(
                                id="factor_Down_banner",
                                children=[generate_section_banner("Факторы снижения ЕТС",'factors')]),

                            html.Div(
                                id="factor_Down_div",
                                children=[
                                    generate_metric_list_header(),
                                    html.Div(id="factor_Down_rows")]),
                        ],

                    ),

                    #                            # Output
                    #                            html.Div(
                    #                                id="Output",
                    #                                className="three columns",
                    #                                children=[
                    #                                    generate_section_banner("Output"),
                    #                                    html.Div(id='my_output'),
                    #                                    html.Pre(id='hover-data')
                    #                                ],
                    #                            ),
                ]

def Factor_Weight_Rows(graph_id, slice_date, direction, RI_ftp_curve_part):


    # Выбираем с рекомендациями на какой срок работаем
    df_Up,df_Down = Get_Recomend_df(RI_ftp_curve_part)

    # Выбираем данные исходя из направления
    if direction == 'up':
        Factor_Value = df_Up.loc[slice_date]
        marker_color = '#FF7F0E'

    elif direction == 'down':
        Factor_Value = df_Down.loc[slice_date]
        marker_color = '#2CA02C'

    # Определяем в какую сторону сортировать
    direction_ascending = direction == 'down'

    # Сортируем значимые факторы в порядке значимости и отбрасываем 0
    Factor_Value = Factor_Value.loc[Factor_Value*Direction_sign[direction] > 0].sort_values(ascending =  direction_ascending)
    Factor_Value = pd.DataFrame(Factor_Value)
    Factor_Value.columns = ['importance']

    # Модель
    model_name = f'{RI_ftp_curve_part}_{direction}'

    # Описание фичей
    df_feature_desc = Factor_Value.merge(Trigger.df_Factor_Features.loc[Trigger.df_Factor_Features['model'] == model_name],
                                         left_index=True,
                                         right_on='features')

    # Добавляем описание факторов
    df_feature_desc = df_feature_desc.merge(Trigger.df_Factor_Dict,
                                                left_on='feature_base',
                                                right_index=True
                                                )

    # List для хранения строк
    Factor_Desc_Rows = []

    n = 0


    # Цикл по сработавшим факторам
    for index, row in df_feature_desc.iterrows():
        n += 1
        i = str(n)

        # Определяем вес фичи
        feature_weight = row['coefs']

        # Определяем цвет пробития
        if row['importance'] > feature_weight:
            factor_color = 'red'
        else:
            factor_color = 'yellow'


        # Фактора
        factor_name = row['feature_base']

        # Значение фактора
        factor_value = Trigger.df_Dataset.loc[slice_date, row['feature_base']]
        try:
            factor_value_desc = Factor_Value_desc(factor_name, factor_value)
        except:
            factor_value_desc = 'Ошибка!'


        # Важность пробития
        feature_value = row['importance']*Direction_sign[direction]

        Factor_Desc_Rows.append(
            generate_metric_row(
                i,
                None,
                # Описание фактора
                {"id": 'Factor_desc' + '_' + graph_id + '_' + i,
                 "children": html.Div(style={'font-size': 15,"textAlign": "left"},
                                      children= row['factor_desc'])

                 },

                # Степень влияния
                {"id": 'GraduatedBar' + '_' + graph_id + '_' + i,
                 "children": daq.GraduatedBar(
                     id='ooc_graph_id' + i,
                     className="progressbar_class",
                     color={"gradient": True, "ranges": {"yellow": [0, 4], "red ": [4, 9]}},
                     showCurrentValue=False,
                     size=100,
                     max=9,
                     value=(feature_value/0.3 * 9)
                 )},

                # Степень проития
                {"id": "Indicator" + '_' + graph_id + '_' + i,
                 "children": daq.Indicator(id='indicator_id' + i,
                                           value=True,
                                           color=factor_color,
                                           size=12)},

                # Вес фактора
                {"id": 'Factor_Rec_value' + '_' + graph_id + '_' + i,
                 "children": f'{feature_weight:.1%}'},

                # Значение фактора
                {"id": 'factor_value' + '_' + graph_id + '_' + i,
                 "children": html.Div(style={'font-size': 14,'font-style': 'italic'},
                                      # children=str(Factor_value) + " " + Trigger.df_Factor_Set.loc[i]['measure_short']
                                      children = factor_value
                                      )
                 },

                # обозначение
                {"id": 'Factor_measure' + '_' + graph_id + '_' + i,
                 # "children": Trigger.df_Factor_Set.loc[i]['measure_short']
                 "children": html.Div(style={'font-size': 12,"textAlign": "right",'font-style': 'italic'},
                                      children= row['features'])
                 }

            ))
    return Factor_Desc_Rows

# def generate_metric_row_helper(row_id):
#     return generate_metric_row(
#         row_id,
#         None,
#         {"id": 'Factor_desc' + str(row_id), "children": "ДЮЛ: Привлечения выше максимальных"},
#         {"id": 'GraduatedBar' + str(row_id),
#          "children": daq.GraduatedBar(
#              id='ooc_graph_id' + str(row_id),
#              style={'color': 'green'},
#              color={"gradient": True, "ranges": {"yellow": [0, 4], "red ": [4, 9]}},
#              showCurrentValue=False,
#              size=100,
#              max=9,
#              value=row_id - 1
#          ),
#          },
#
#         {
#             "id": "Indicator" + str(row_id),
#             "children": daq.Indicator(id='indicator_id' + str(row_id), value=True, color="#91dfd2", size=12),
#         },
#
#         {"id": 'Factor_Rec_value' + str(row_id), "children": "5"},
#
#         {"id": 'Factor_value' + str(row_id), "children": "500000000"}
#     )

# Создаёт строку с пробитиями факторов
def generate_metric_row(id, style, col1, col2, col3, col4, col5, col6):
    if style is None:
        style = {"height": "4rem", "width": "100%"}

    return html.Div(
        id="row" + str(id),
        className="row metric-row",
        style=style,
        children=[

            html.Div(
                # Фактор
                id=col1["id"],
                style={"textAlign": "left",
                       "align": "right",
                       "min-width": "43%",
                       "max-width": "43%",
                       "padding-left": "10px"},
                #className="four column",
                children=col1["children"]
            ),

            html.Div(
                # Значимость
                id=col2["id"],
                style={"height": "100%",
                       "margin-top": "1rem",
                       "min-width": "12%",
                       "max-width": "12%",
                       "padding-left": "10px",
                       "textAlign": "left",
                       },
                #className="three columns",
                children=col2["children"],
            ),

            html.Div(
                # Пробитие
                id=col3["id"],
                style={"display": "flex",
                       "justifyContent": "center",
                       "min-width": "5%",
                       "max-width": "5%"
                       },
                #className="one column",
                children=col3["children"],
            ),

            html.Div(
                # Вес
                id=col4["id"],
                style={"textAlign": "center",
                       "min-width": "5%",
                       "max-width": "5%"
                       },
                #className="one column",
                children=col4["children"],
            ),

            html.Div(
                # Значение
                id=col5["id"],
                style={"textAlign": "right",
                       "min-width": "15%",
                       "max-width": "15%",
                       # 'font-size': 16,
                       # 'font-style': 'italic'
                       },

                children=col5["children"],
            ),

            html.Div(
                # Влияние
                id=col6["id"],
                style={"textAlign": "center",
                       "min-width": "19%",
                       "max-width": "19%",
                       "padding-left": "10px"},
                #className="two column",
                children=col6["children"],
            ),

        ],
    )

# Генерит строчку
def generate_metric_list_header():
    return generate_metric_row(
        "metric_header",
        {"height": "3rem", "margin": "1rem 0", "textAlign": "center"},
        {"id": "m_header_1", "children": html.Div("Фактор",style={'font-size': 15,"color": "grey"})},
        {"id": "m_header_2", "children": html.Div("Значимость",style={'font-size': 15,"color": "grey"})},
        {"id": "m_header_3", "children": html.Div("",style={'font-size': 15,"color": "grey"})},
        {"id": "m_header_4", "children": html.Div("Вес",style={'font-size': 15,"color": "grey"})},
        {"id": "m_header_5", "children": html.Div("Значение",style={'font-size': 15,"color": "grey"})},
        {"id": "m_header_6", "children": html.Div("Название фичи",style={'font-size': 15,"color": "grey"})}
    )

# Таb c описанием факторов
def layout_MA_Model():
    try:
        # Выбор Версии
        version_folders = Get_Folders_in_Folder(folder_path=app_config.default_version_folder)

        # Проверяем, что есть версии
        if not version_folders:
            return html.Div([
                html.H2("Анализ моделей", className="compute-title"),
                html.Div("Папка с версиями моделей пуста", className="compute-status")
            ])

        verions=[{'label': i, 'value': i} for i in version_folders]

        # Выбор Модели
        Model_List=[
           {'value': 'short_up', 'label': model_desc['short_up']},
           {'value': 'long_up',   'label': model_desc['long_up']},
           {'value': 'short_down','label': model_desc['short_down']},
           {'value': 'long_down', 'label': model_desc['long_down']}
       ]

        sel_version = version_folders[0]
        sel_model = Model_List[-1]['value']

        RadioItems_version =   html.Div([
                                    dcc.RadioItems(
                                        id='MA_Versions_RadioItems_id',
                                        options=verions,
                                        value=sel_version,

                                        #clearable = False,
                                        style={"margin-top": "1rem",
                                            "Align": "left",
                                            "padding-left": '2rem',
                                            'color': 'darkgrey',
                                            'font-size': 19
                                            #'overflow-y':'scroll',
                                            #'height': '100px'
                                            }
                                    )],
                                    #id="trigger_graph",

                            )



        RadioItems_model =   html.Div([
                                    dcc.RadioItems(
                                        id='MA_Model_Dropdown_id',
                                        options = Model_List,
                                        value = sel_model,

                                        #clearable = False,
                                        style={"margin-top": "1rem",
                                            "Align": "left",
                                            "padding-left": '2rem',
                                            'color': 'darkgrey',
                                            'font-size': 19
                                            #'overflow-y':'scroll',
                                            #'height': '400px'
                                            }),

            # style = {'font-size': 21,
            #          'font-weight': 'bold',
            #          "align": "right",
            #          'color': 'darkgrey',
            #          "padding-left": '1rem'}),


                                    ],
                                    #id="trigger_graph",

                            )

        # Статистика по модели
        Model_main_stat =    html.Div(
                                    id="MA_Model_Main_Stat_id",
                                    # children=[MA_Model_Main_Stat_Table('long_up')]
                                        )

        Block_main_stat = html.Div(
                                    id="MA_Block_Main_Stat_id",
                                    # children=[MA_Block_Main_Stat_Table('long_up')]
                                        )


        Factor_main_stat = html.Div(
                                    id="MA_Factor_Main_Stat_id",
                                    # children=[MA_Factor_Main_Stat_Table('2024-12-28 V2.2','long_up','KFL')]
                                        )

        return html.Div([

                # Выбор версии и модели
                html.Div(className="row",
                        children=[

                        # === Выбор версии ===
                        html.Div([
                                html.Div(generate_section_banner("Версия модели"),style={"padding-left": '1rem'}),

                                # Выбор версии
                                RadioItems_version
                                ],
                                className="three columns",
                                style={"padding-left": '7rem'}),

                        # === График с историей фактора ===
                        html.Div([
                                html.Div(generate_section_banner("Модель"),style={"padding-left": '1rem'}),

                                # Выбор модели
                                RadioItems_model,


                                ],
                                className="three columns"),

                        # Табличка с пописанием модели
                        html.Div(
                        html.Div([
                            html.Div(generate_section_banner("Статистика модели по угадыванию событий"), style={"padding-left": '1rem'}),
                            html.Br(),
                            # Статистика по модели
                            Model_main_stat,
                            ],
                                style={'display': 'inline-block', 'width': '45%'}
                                )
                                ),


                                ]),

                # html.Div(id = 'MA_Model_Graph_title_id',
                #          children = "История срабатываения модели",
                #          style={"padding-left": '1rem'}),

                # html.Div(
                #     children="История срабатывания модели",
                #     style={'font-size': 21,
                #            'font-weight': 'bold',
                #            "align": "right",
                #            'color': 'darkgrey',
                #            "padding-left": '7rem'}),


                # График с моделью и таргетом
                html.Div([dcc.Graph(id='MA_Model_Graph_id',
                                    figure=MA_Model_Graph(version=sel_version,
                                                        MODEL=sel_model
                                                        ),



                                    )]),


                # Табличка с пописанием блоков
                html.Div(children =[
                                    html.Div(
                                            children="Блоки в модели",
                                            style={'font-size': 21,
                                                    'font-weight': 'bold',
                                                    "align": "right",
                                                    'color': 'darkgrey',
                                                    "padding-left": '4rem'}),

                                    # Статистика по модели
                                    Block_main_stat,
                                    # html.Pre(id='helper_Pre1', children=['helper_Pre1'], style={'display': 'False'}),
                                    # html.Div(id='helper_Div1', children=['helper_Div1'], style={'display': 'False'}),
                                    # html.Div(id='helper_Div2', children=['helper_Div2'], style={'display': 'False'}),
                                    html.Br()],
                        style = {'display': 'inline-block', 'width': '48%', "padding-left": '8rem'}
                ),



                # График с блоком и таргетом
                html.Div([dcc.Graph(id='MA_Block_Graph_id',
                                    figure=MA_Block_Graph(version=sel_version,
                                                        MODEL=sel_model,
                                                        BLOCK='KUL',
                                                        #                        FACTORS = ['clt_gain_sum']
                                                        ),
                                    )]),

                # Табличка с описанием факторов
                html.Div([
                    html.Div(
                        children="Факторы в блоке",
                        style={'font-size': 21,
                            'font-weight': 'bold',
                            "align": "right",
                            'color': 'darkgrey',
                            "padding-left": '4rem'}),

                    # Статистика по модели
                    Factor_main_stat,
                    html.Br()],
                    style={ "padding-left": '8rem'}
                ),

                # Блок с тестовыми полями
                # html.Pre(id='ma_my_output_factor', children=['ma_my_output_factor'], style={'display': 'False'}),
                # html.Pre(id='ma_hover_data_factor', children=['ma_hover_data_factor'], style={'display': 'False'}),
                # html.Pre(id='ma_help_output', children=['ma_help_output'], style={'display': 'False'}),
                # html.Pre(id='ma_help_output_2', children=['ma_help_output_2'], style={'display': 'False'}),

                # График фактора
                html.Div([dcc.Graph(id='MA_Factor_Graph_id',
                                    # figure=MA_Factor_Graph(version = '2024-12-28 V2.2',
                                    #                        MODEL = 'long_up',
                                    #                        block = 'ALM',
                                    #                        FACTORS = ['clt_gain_sum'])
                                    )]),
            ]
        )

    except FileNotFoundError as e:
            logging.error(f"Ошибка при загрузке layout_MA_Model: {e}")
            return html.Div([
                html.H2("Анализ моделей", className="compute-title"),
                html.Div(f"Ошибка: {str(e)}", className="compute-status", style={"color": "red"})
            ])
    except Exception as e:
        logging.error(f"Неожиданная ошибка при загрузке layout_MA_Model: {e}")
        return html.Div([
            html.H2("Анализ моделей", className="compute-title"),
            html.Div(f"Неожиданная ошибка: {str(e)}", className="compute-status", style={"color": "red"})
        ])

# Layout для загрузки данных
def Upload_Data_layout():
    logging.info(f'layouts.Fast_Track_layout: Загрузки Layout  для закладки "Загрузка данных" ')
    return html.Div([
        # Основной заголовок
        dbc.Row(dbc.Col(html.H2(style={'text-align': 'center'}, children='Загрузка данных'), width=4)),
        html.Hr(),

        # ===================================================================================================
        # Загрузка кривой
        dbc.Row([

            dbc.Row([
                dbc.Col([
                    dbc.Row(html.H3(children='Файл c витриной от DE')),
                    dbc.Row(html.P(style={'font-size': '16px',
                                          'margin': 'auto',
                                          'width': '90%',
                                          'opacity': '70%',
                                          'fontStyle': 'italic'},
                                   children='''ewi_etc_dev_*.csv'''))
                ], width={"size": 3,
                          "offset": 1,
                          "order": 1,
                          }),

                dbc.Col(
                    html.Div([
                        dbc.Row(html.H5(children='Дата витрины')),
                        dcc.DatePickerSingle(
                            id='upload_DE_data_date_id',
                            min_date_allowed=date(2024, 1, 1),
                            # max_date_allowed=date(2017, 9, 19),
                            # initial_visible_month=date(2017, 8, 5),
                            date=date.today(),
                            display_format='YYYY-MM-DD',
                            calendar_orientation='vertical',
                            # with_portal=True,
                            # style={
                            #     'color': 'red',  # Цвет текста поля
                            #     'backgroundColor': '#2c2c2',  # Фон поля
                            #     # 'border-radius': '5px',  # Радиус углов
                            #     # 'border': 'none',  # Нет границ
                            #     # 'outline': 'none',  # Без фокусного контура
                            #     # 'transition': 'all .3s ease-in-out',  # Переход при изменении свойств
                            #     # ':hover': {  # Стили при наведении мыши
                            #     #     'background-color': '#FF4500'
                            #     #             },
                            #     # ':focus': {  # Стили при получении фокуса
                            #     #     'background-color': '#DC143C'
                            #     #             }
                            # }
                        ),
                    ]),

                    width={"size": 2,
                           # "offset": 1,
                           "order": 2
                           },
                ),

                dbc.Col([
                    dbc.Row(html.H6(children='версия')),
                    dcc.Input(
                        id="upload_DE_data_date_add_id",
                        type='text',
                        placeholder="дополнение",
                        name = 'уточнение к дате'
                    )],

                    width={"size": 2,
                           # "offset": 1,
                           "order": 2
                           },
                )

            ]),

            # Загрузка и результаты
            dbc.Row(
                html.Div([
                    dcc.Upload(
                        id='upload_DE_data_files_id',
                        children=html.Div([
                            html.A('Выберите'), ' или просто закиньте файлы '
                        ]),
                        style={
                            'width': '100%',
                            'height': '60px',
                            'lineHeight': '60px',
                            'borderWidth': '1px',
                            'borderStyle': 'dashed',
                            'borderRadius': '5px',
                            'textAlign': 'center',
                            'margin': '10px'
                        },
                        # Allow multiple files to be uploaded
                        multiple=True
                    ),

                    # Вывод результатов загрузки файлов

                    dbc.Row(html.P(id='upload_DE_data_result_id',
                                   style={'font-size': '14px',
                                          'margin': 'auto',
                                          'width': '90%',
                                          'opacity': '30%',
                                          'fontStyle': 'italic'},
                                   children=''))
                ])
            )
        ]),

        # html.Hr(),
        #
        # # ===================================================================================================
        # # Загрузка HW
        # dbc.Row([
        #
        #     dbc.Row([
        #         dbc.Col([
        #             dbc.Row(html.H4(children='Параметры HW')),
        #             dbc.Row(html.P(style={'font-size': '16px', 'margin': 'auto', 'width': '90%', 'opacity': '70%'},
        #                            children='''*_HW_params_YYYY-MM-DD.json '''))
        #         ], width={"size": 4,
        #                   "offset": 1,
        #                   "order": 1,
        #                   }),
        #
        #         dbc.Col(
        #             html.Div([
        #                 dbc.Row(html.H5(children='Дата параметров')),
        #                 dcc.DatePickerSingle(
        #                     id='upload_HW_date_id',
        #                     min_date_allowed=date(2024, 1, 1),
        #                     # max_date_allowed=date(2017, 9, 19),
        #                     initial_visible_month=date(2017, 8, 5),
        #                     date=date.today(),
        #                     display_format='YYYY-MM-DD'),
        #             ]),
        #
        #             width={"size": 2,
        #                    # "offset": 1,
        #                    "order": 2
        #                    },
        #         ),
        #
        #     ]),
        #
        #     # Загрузка и результаты
        #     dbc.Row(
        #         html.Div([
        #             dcc.Upload(
        #
        #                 id='upload_HW_files_id',
        #                 children=html.Div([
        #                     html.A('Выберите'), ' или просто закиньте файлы '
        #                 ]),
        #                 style={
        #                     'width': '100%',
        #                     'height': '60px',
        #                     'lineHeight': '60px',
        #                     'borderWidth': '1px',
        #                     'borderStyle': 'dashed',
        #                     'borderRadius': '5px',
        #                     'textAlign': 'center',
        #                     'margin': '10px'
        #                 },
        #                 # Allow multiple files to be uploaded
        #                 multiple=True
        #             ),
        #
        #             # Вывод результатов загрузки файлов
        #             html.Pre(id='upload_HW_files_result_id'),
        #         ])
        #     )
        # ]),
        #
        # html.Hr(),
        #
        # # ===================================================================================================
        # # Загрузка CIR
        # dbc.Row([
        #
        #     dbc.Row([
        #         dbc.Col([
        #             dbc.Row(html.H4(children='Параметры CIR')),
        #             dbc.Row(html.P(style={'font-size': '16px', 'margin': 'auto', 'width': '90%', 'opacity': '70%'},
        #                            children=''' *_CIR_params_YYYY-MM-DD.json '''))
        #         ], width={"size": 4,
        #                   "offset": 1,
        #                   "order": 1,
        #                   }),
        #
        #         dbc.Col(
        #             html.Div([
        #                 dbc.Row(html.H5(children='Дата параметров')),
        #                 dcc.DatePickerSingle(
        #                     id='upload_CIR_date_id',
        #                     min_date_allowed=date(2024, 1, 1),
        #                     # max_date_allowed=date(2017, 9, 19),
        #                     initial_visible_month=date(2017, 8, 5),
        #                     date=date.today(),
        #                     display_format='YYYY-MM-DD'),
        #             ]),
        #
        #             width={"size": 2,
        #                    # "offset": 1,
        #                    "order": 2
        #                    },
        #         ),
        #
        #     ]),
        #
        #     # Загрузка и результаты
        #     dbc.Row(
        #         html.Div([
        #             dcc.Upload(
        #                 id='upload_CIR_files_id',
        #                 children=html.Div([
        #                     html.A('Выберите'), ' или просто закиньте файлы '
        #                 ]),
        #                 style={
        #                     'width': '100%',
        #                     'height': '60px',
        #                     'lineHeight': '60px',
        #                     'borderWidth': '1px',
        #                     'borderStyle': 'dashed',
        #                     'borderRadius': '5px',
        #                     'textAlign': 'center',
        #                     'margin': '10px'
        #                 },
        #                 # Allow multiple files to be uploaded
        #                 multiple=True
        #             ),
        #
        #             # Вывод результатов загрузки файлов
        #             html.Pre(id='upload_CIR_files_result_id'),
        #         ])
        #     )
        # ]),

    ])

# def fasttrack_status_style(color: str):
#     return {
#         "padding": "5px 10px",
#         "color": "white",
#         "backgroundColor": color,
#         "borderRadius": "5px",
#         "display": "inline-block",
#         "minWidth": "150px",
#         "textAlign": "center",
#         "margin-right": "20px"
#     }

# Layout для загрузки данных
def Fast_Track_layout():
    logging.info(f'layouts.Fast_Track_layout: Загрузки Layout  для "Fast Track"')

    DE_folder_date_list = Get_Folders_in_Folder(folder_path=app_config.DE_data_path)

    return html.Div([

        dbc.Row(dbc.Col(html.H3(children='Fast Track'))),

        dbc.Row(dbc.Col(html.H5(children='Витрина от DE'))),

        # Дата спреда ликвидности
        dbc.Row([
            dbc.Col(
                dcc.Dropdown(
                    style={
                        'text-align': 'center',
                        'font-size': '1em',
                        'width': '15em',
                        'justify-self': 'left',
                        # 'fontStyle': 'italic'
                    },
                    id='fasttrack_DE_data_id',
                    options=DE_folder_date_list,
                    placeholder="Выберите дату...",
                    clearable=False,
                    persistence=True,
                    persistence_type="session",
                    optionHeight=40,
                ),
                width="auto"
            ),
            dbc.Col(
                dbc.Button(
                    "✔",
                    id="fasttrack-update-button",
                    className="mb-3 d-md-block",
                    color="secondary",
                    n_clicks=0,
                    # outline=True,
                    # size="sm"
                ),
                width="auto"
            ),
        ]),

        html.Br(),

        html.Div(html.Hr()),
        dbc.Row(dbc.Col(
            html.H6(
                id="fasttrack-de-data-title",
                children='Данные витрины'
            )
        )),
        html.Br(),

        # Блок с фильтрами для грида
        html.Div(
            dbc.Row([
                dbc.Col([
                        dbc.Label("Фактор"),
                        dcc.Dropdown(
                            placeholder="Выберите фактор...",
                            disabled=True,
                            # options=df.columns,
                            id="fasttrack-de-data-grid-filter"
                        ),
                ], width=2),
            ], className="mb-2"),
        ),

        html.Div([
            dag.AgGrid(
                id="fasttrack-de-data-grid",
                columnDefs=[],
                rowData=[],
                style={
                    "height": "45vh",
                    "minHeight": 400, 
                    "width": "90%"
                },
                className="ag-theme-quartz-dark ag-theme-custom",
                dashGridOptions={
                    "noRowsOverlayComponent": "CustomNoRowsOverlay",
                    "noRowsOverlayComponentParams": {
                        "message": "📊 Выберите дату витрины для просмотра данных",
                    },
                },
                defaultColDef={
                    "filter": False,
                    "resizable": True,
                    # "flex": 1,
                    # "minWidth": 120
                },
                columnSize="autoSize",
            )
        ]),

        html.Br(),

        # Кнопки
        dbc.Row([
            dbc.Col([
                dbc.Button(
                    "Запуск модели",
                    id="fasttrack-run-btn",
                    className="mb-3",
                    color="primary",
                    n_clicks=0,
                    style={
                        "width": "150px",
                        "margin-right": "200px"
                    }
                ),
                # html.Div(id="fasttrack-run-btn-result", className="mb-3"),
            ], width="auto"),
            dbc.Col([
                html.Div(
                    CalcMessage.IDLE.value,
                    id="fasttrack-run-status", 
                    className=f"fasttrack-run-status {CalcState.IDLE.value}",
                ),
                dcc.Store(
                    id="fasttrack-run-status-store",
                    data={
                        "state": CalcState.IDLE.value,
                        "message": CalcMessage.IDLE.value,
                        "rec_date": "no data"
                    },
                    storage_type="session"
                ),
                dbc.Modal(children=[
                    dbc.ModalHeader(dbc.ModalTitle("Информация")),
                    dbc.ModalBody(id="fasttrack-modal-status-completed-body")
                ], id="fasttrack-modal-status-completed", is_open=False),
            ], width="auto"),
            
        ]),

        # html.Br(),

        dbc.Row([
            dbc.Col([
                dbc.Button(
                    "Скачать результаты",
                    id="fasttrack-download-btn",
                    className="mb-3",
                    n_clicks=0,
                    color="secondary",
                    style={
                        "width": "150px",
                    }
                ),
                dcc.Download(id="fasttrack-download-zip"),
                dbc.Modal([
                    dbc.ModalHeader(dbc.ModalTitle("Информация")),
                    dbc.ModalBody("Результаты еще не готовы. Запустите расчет или дождитесь окончания текущего запуска.")
                ], id="fasttrack-modal-no-file", is_open=False),
                dbc.Modal([
                    dbc.ModalHeader(dbc.ModalTitle("Информация")),
                    dbc.ModalBody("Для того, чтобы скачать результаты, выберите дату витрины от DE в выпадающем списке.")
                ], id="fasttrack-modal-no-date", is_open=False),
            ], width="auto"),
            dbc.Col([
                dbc.Progress(
                    id="fasttrack-run-progress",
                    value=0,
                    striped=True,
                    animated=True,
                    style={
                        "height": "20px",
                        "width": "240px",
                        "marginLeft": "180px",
                        "marginTop": "20px",
                        "font-size": 13, 
                    }
                ),
                dcc.Store(
                    id="fasttrack-run-progress-store",
                    data=0,
                    storage_type="session"
                )
            ])
        ]),

        html.Div(html.Hr()),

        dbc.Row([
            dbc.Col([
                html.H6(children='Текущие рекомендации модели')
            ],
                    width=10,
                    style={
                        "display": "flex",
                        "alignItems": "center",
                        "justifyContent": "left"
                    },
            ),
        ]),

        html.Br(),

        dbc.Row([
            dbc.Col(width=5),
            dbc.Col([
                dcc.Dropdown(
                    id="fasttrack-block-graph-filter",
                    placeholder="Выберите модель...",
                    disabled=True,
                    style={
                        "text-align": "center", 
                        "font-size": "1em", 
                        "width": "15em",
                        "justify-self": "left",
                        # "border": "1px solid rgba(225, 225, 225, 0.30)",
                        # "borderRadius": "10px",
                    },
                    clearable=False
                ),
            ], width=4),
            dbc.Col([
                dcc.Checklist(
                    id="fasttrack-block-graph-check",
                    options=[{'label': html.Div('Сравнить с текущим расчетом', style={'font-size': 15, 'color': 'grey', 'padding-left': 8}), 'value': True}],
                    value=[True],
                    style={"marginTop": "8px", "marginLeft": "10%"},
                    labelStyle={"display": "flex"}
                )
            ]),
        ]),

        html.Div([
            dbc.Row([
                dbc.Col([
                    dag.AgGrid(
                        id="fasttrack-model-rec-grid",
                        columnDefs=[],
                        rowData=[],
                        style={
                            "height": "40vh", # 400px
                            "width": "100%" # 720px
                        },
                        defaultColDef={
                          "resizable": True,
                          "flex": 1,
                          "minWidth": 110  
                        },
                        className="ag-theme-quartz-dark ag-theme-custom",
                        dashGridOptions={
                            "noRowsOverlayComponent": "CustomNoRowsOverlay",
                            "noRowsOverlayComponentParams": {
                                "message": "📂 Данные отсутствуют",
                            },
                            'suppressRowTransform': True
                        }
                    )
                ], width=5),
                dbc.Col([
                    dcc.Graph(
                        id="fasttrack-block-graph",
                        figure=empty_graph_template(),
                        style={
                            "height": "40vh",
                            "width": "100%", # 1100px
                            "border": "1px solid rgba(225, 225, 225, 0.16)",
                            "borderRadius": "8px",
                            "overflow": "hidden",
                            "backgroundColor": "#33384c"
                        },
                        config={"displayModeBar": False}
                    )
                ], width=6)
            ])
        ]),

        ])
