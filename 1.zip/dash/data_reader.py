import warnings
import os
import json
import logging
from typing import Union

import pandas as pd
warnings.simplefilter(action='ignore', category=pd.errors.DtypeWarning)

from config import TableConfig, split_file_params

# список поддерживаемых расширений
CSV_EXT = ".csv"
XLSX_EXT = ".xlsx"
JSON_EXT = ".json"

def load_data(cfg: TableConfig) -> Union[pd.DataFrame, dict]:
    if not cfg.source_type:
        raise ValueError(f"No source for table {cfg.name}")
    
    # params = cfg.source_params.copy() or {}
    
    if cfg.source_type == 'file':
        
        filepath, params = split_file_params(params=cfg.source_params)
        ext = os.path.splitext(filepath)[1]
        
        if not os.path.exists(filepath):
            logging.info(f"Файл не найден: {filepath}")
            return pd.DataFrame()
        
        if ext == CSV_EXT:
            return pd.read_csv(filepath, **params)
        elif ext == XLSX_EXT:
            return pd.read_excel(filepath, **params)
        elif ext == JSON_EXT:
            with open(filepath, 'r') as f:
                data = json.load(f)
            return data
        else:
            raise ValueError(f"Unsupported file extension: {ext}")
    elif cfg.source_type == 'db':
        # потом пропишем
        pass
    else:
        raise ValueError(f"Unknown source type: {cfg.source_type}")
        