# dash/data_preparation_RUB.py
"""
Created on Mon Dec 21 18:46:26 2020

@author: Smirnov10-aa
"""

import logging
import os
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from pandas.tseries.offsets import Week

# Словарь со знаком пробития
Direction_sign = {'up':1,
                  'down':-1
                  }

# Направление для каждой модели
Model_sign = {'long_up': 1,
              'long_down': -1,
              'short_up': 1,
              'short_down': -1}

# список моделей
Model_list = ['long_up', 'long_down', 'short_up', 'short_down']

class Trigger:
    def __init__(self,
                 Desc = None,
                 Hist_Start_date = None,
                 Hist_Last_date =  None,
                 report_weekday_num = None,

                 path_FTP_Hist=None,
                 path_Factors_Dictionary = None,
                 path_Factors_Features_Levels=None,
                 path_Factor_Data=None,
                 path_model_Treshold=None,

                 path_FTP_Hist_noChange=None,
                 path_FTP_Hist_factors=None,

                 path_Factor_Set=None,

                 ):

        # Описание
        self.Desc = Desc



        # Даты
        self.Hist_Start_date = pd.to_datetime(Hist_Start_date, format='%Y-%m-%d')
        self.Hist_Last_date = pd.to_datetime(Hist_Last_date, format='%Y-%m-%d')
        self.report_weekday_num = report_weekday_num #(4-пятница)

        # Списки
        self.Factor_list = None      # Список факторов
        self.Factor_Features_list = None # Список фитч
        self.Factor_Rec_FTPUp_list = None
        self.Factor_Rec_FTPDown_list = None
        self.Model_list = None # Список моделей
        # self.ETC_Hist_columns = None # Список полей с историей ЕТС


        # Пути к файлам
        self.path_FTP_Hist = path_FTP_Hist
        self.path_Factors_Dictionary = path_Factors_Dictionary
        self.path_Factors_Features_Levels = path_Factors_Features_Levels
        self.path_Factor_Data = path_Factor_Data
        self.path_model_Treshold = path_model_Treshold

        self.path_FTP_Hist_noChange = path_FTP_Hist_noChange
        self.path_FTP_Hist_factors = path_FTP_Hist_factors

        self.path_Factor_Set = path_Factor_Set #Путь к файлам с данными

        # Data Frames
        self.df_Trigger_Date = None # Набор дат, на которые строим отчёты
        self.df_Factor_Dict =  None  # Словарь факторов
        self.df_Factor_Features = None  # Уровни моделей
        self.df_Dataset = None  # Данные факторов
        self.df_Dataset_Modif_Features = None  # Модифицированне фичи факторов
        self.df_FTP_Hist =  None    # История ЕТС
        self.df_FTP_Hist_all = None  # История ЕТС на даты фич


        # Рекомендации
        self.Recommend = None # Словарь с пробитиями факторов


        # self.df_Factor_Data =  None # Данные по факторам
        # self.df_Factor_Break_Down =  None # Данные по пробитию факторов Вниз
        # self.df_Factor_Break_Up =  None # Данные по пробитию факторов Вверх
        # self.df_Factor_FTP_Down =  None # Данные по рекомендациям Снижения ЕТС
        # self.df_Factor_FTP_Up =  None # Данные по рекомендациям Поднятия ЕТС
        # self.df_Factor_FTP_Short_Down =  None # Данные по рекомендациям Снижения ЕТС на коротком конце
        # self.df_Factor_FTP_Short_Up = None  # Данные по рекомендациям Поднятия ЕТС на коротком конце
        # self.df_Factor_FTP_Long_Down = None  # Данные по рекомендациям Снижения ЕТС на длинном конце
        # self.df_Factor_FTP_Long_Up =  None # Данные по рекомендациям Поднятия ЕТС на длинном конце
        # self.df_FTP_Hist_noChange = None  # История совещаний по ЕТС, которые не привели к изменению ЕТС
        # self.df_FTP_Hist_factors =  None  # Рассматриваемые факторы на совещаниях по ставкам

    # Формируем датасет с набором дат, на котрые будет строится отчёт
    def Create_df_Trigger_Date(self):
        # Номер дня недели, к которому приводим отчёт
        report_weekday_num = self.report_weekday_num
        logging.info(f' Формируем датасет с датами (weekday_num = {report_weekday_num})')

        # Создаём df с нужным набором дат
        # Сначала определяем даты нужного дня недели, а потом между ними выделяем все такие дни недели

        # Номера дней недели интересующих дат
        Start_date_num = self.Hist_Start_date.weekday()
        Last_date_num = self.Hist_Last_date.weekday()

        if Start_date_num > report_weekday_num:
            day_delta_Start_date = 7 + report_weekday_num - Start_date_num
        else:
            day_delta_Start_date = report_weekday_num - Start_date_num

        if Last_date_num > report_weekday_num:
            day_delta_Last_date = 7 + report_weekday_num - Last_date_num
        else:
            day_delta_Last_date = report_weekday_num - Last_date_num

        report_Start_date = self.Hist_Start_date + timedelta(day_delta_Start_date)
        report_Last_date = self.Hist_Last_date + timedelta(day_delta_Last_date)


        report_date_list = pd.date_range(start = report_Start_date,end = report_Last_date,freq = '7D')

        df = pd.DataFrame()
        df['Trigger_Date'] =  report_date_list
        # df.set_index('Date_Friday', inplace = True)

        self.df_Trigger_Date = df

        # self.df_Factor_Data.merge(self.df_FTP_Hist, right_index= True, left_index = True)

        # self.df_Factor_Data['ETC_Hist_Down'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['down_value'])
        # self.df_Factor_Data['ETC_Hist_Up'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['up_value'])
        #
        # self.df_Factor_Data['ETC_Hist_Down_Short'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['short_down_value'])
        # self.df_Factor_Data['ETC_Hist_Up_Short'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['short_up_value'])
        #
        # self.df_Factor_Data['ETC_Hist_Down_Long'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['long_down_value'])
        # self.df_Factor_Data['ETC_Hist_Up_Long'] = self.df_Factor_Data['Date_Friday'].map(self.df_FTP_Hist['long_up_value'])

        # for i in ['ETC_Hist_Down','ETC_Hist_Up','ETC_Hist_Down_Short','ETC_Hist_Up_Short','ETC_Hist_Down_Long','ETC_Hist_Up_Long']:
        #     self.df_Factor_Data[i].fillna(0,inplace = True)

    def Load_FactorSet(self):
        # Грузим настройки для фич
        logging.info(f' Грузим настройки для фич {self.path_Factors_Features_Levels}')
        df_Factor_Features = pd.read_excel(self.path_Factors_Features_Levels, sheet_name='Features', engine='openpyxl')
        df_Factor_Features.rename(columns = {"rank":"coefs"}, inplace = True)

        df_Factor_Features.sort_values(['model','coefs'], inplace = True)

        # # Проставим coefs из res_criteria, пока его нет
        # max_criteria = df_Factor_Features['res_criteria'].max()
        # min_criteria = df_Factor_Features['res_criteria'].min()
        #
        # df_Factor_Features['coefs'] = round(
        #     (df_Factor_Features['res_criteria'] - min_criteria) / (max_criteria - min_criteria) / 0.2, 0) + 1



        # Описание фичей факторов
        self.df_Factor_Features = df_Factor_Features

        # Список фичей факторов
        self.Factor_Features_list = df_Factor_Features['features']

        # Список используемых факторов
        self.Factor_list = self.df_Factor_Features['feature_base'].unique()
        self.Factor_list.sort()

        # Грузим словарь факторов
        logging.info(f' Грузим словарь факторов {self.path_Factors_Dictionary}')
        df_dict = pd.read_excel(self.path_Factors_Dictionary, sheet_name='Dictionary', engine='openpyxl')

        # Описание факторов (только используемых)
        self.df_Factor_Dict =  df_dict.loc[df_dict['factor'].isin(self.Factor_list),:]
        self.df_Factor_Dict.set_index('factor', inplace=True)




    def Load_FTP_Hist(self):
        logging.info(f' Грузим историю ЕТС {self.path_FTP_Hist}')

        # Номер дня недели, к которому приводим отчёт
        report_weekday_num = self.report_weekday_num


        # Загружаем данные по истории изменения ЕТС
        df_ETC = pd.read_excel(self.path_FTP_Hist, sheet_name='Таргет', engine='openpyxl', skiprows = 2)

        # находим ближайшую пятницу
        df_ETC.insert(1,'Trigger_Date',df_ETC.apply(lambda row: row['Date'] + timedelta(report_weekday_num - row['Date'].dayofweek), axis=1))
        # выбирае следующую пятницу, если нашшли  прошедшую
        df_ETC.loc[df_ETC['Date'] > df_ETC['Trigger_Date'],'Trigger_Date'] = df_ETC['Trigger_Date'] + timedelta(7)

        # Находим максимальное,минимальное значение изменения кривой
        df_ETC['down_value'] = df_ETC.apply(lambda row: min(row['short_down_value'], row['long_down_value']), axis=1)
        df_ETC['up_value'] = df_ETC.apply(lambda row: max(row['short_up_value'], row['long_up_value']), axis=1)

        df_ETC = df_ETC.groupby('Trigger_Date').sum()
        # df_ETC = df_ETC.set_index('StartDate_Friday')

        # История ЕТС по дням отчёта
        self.df_FTP_Hist = df_ETC



    # def Load_FTP_Hist_meetings(self):
    #
    #     # Загружаем истори совещаний, где ничего не меняли
    #     self.df_FTP_Hist_noChange = pd.read_excel(self.path_FTP_Hist_noChange, sheet_name='noChange', engine='openpyxl', index_col=False)
    #
    #     # Загружаем факторы совещаний
    #     self.df_FTP_Hist_factors = pd.read_excel(self.path_FTP_Hist_factors, sheet_name='factors', engine='openpyxl', index_col=False)

    def Load_Factor_Data(self):
        logging.info(f' Грузим данные по факторам и фичам {self.path_Factor_Data}')

        # Грузим данные со значениями факторов
        df_dataset = pd.read_excel(self.path_Factor_Data, sheet_name='data_1_agg',engine='openpyxl')

        # Делаем Trigger_Date из report_date
        df_dataset.insert(1, 'Trigger_Date',df_dataset.apply(lambda row: row['report_date'] + timedelta(4 - row['report_date'].dayofweek),axis=1))
        df_dataset.loc[df_dataset['report_date'] > df_dataset['Trigger_Date'], 'Trigger_Date'] = df_dataset['Trigger_Date'] + timedelta(7)
        df_dataset.set_index('Trigger_Date', inplace=True)

        # Грузим данные с модифицированными фичами
        df_dataset_modif_features = pd.read_excel(self.path_Factor_Data,sheet_name='data_2_modif',engine='openpyxl')
        df_dataset_modif_features.insert(1, 'Trigger_Date',df_dataset_modif_features.apply(lambda row: row['report_date'] + timedelta(4 - row['report_date'].dayofweek),axis=1))
        df_dataset_modif_features.loc[df_dataset_modif_features['report_date'] > df_dataset_modif_features['Trigger_Date'], 'Trigger_Date'] = df_dataset_modif_features['Trigger_Date'] + timedelta(7)
        df_dataset_modif_features.set_index('Trigger_Date', inplace=True)

        # Добавляем значение факторов к значениям фич
        # df_dataset_modif_features = df_dataset_modif_features.merge(df_dataset, left_index=True,right_index=True, how = 'left')

        #Собираем названия колонок
        columns_factors = list(df_dataset.columns)

        # df_dataset_modif_features.drop(columns = columns_factors, inplace=True)

        df_dataset = df_dataset.merge(self.df_FTP_Hist,left_index=True,right_index=True, how = 'left')
        df_dataset_modif_features = df_dataset_modif_features.merge(self.df_FTP_Hist,left_index=True,right_index=True, how = 'left')

        # df_dataset.fillna(0, axis = 1, inplace = True)
        # df_dataset_modif_features.fillna(0, axis = 1, inplace = True)

        self.df_Dataset = df_dataset
        self.df_Dataset_Modif_Features = df_dataset_modif_features

        # Распределяем историю ЕТС по датам факторов
        df_FTP_Hist_Trigger_Date = pd.DataFrame(index = df_dataset.index)
        df_FTP_Hist_Trigger_Date = df_FTP_Hist_Trigger_Date.merge(self.df_FTP_Hist,left_index=True,right_index=True, how = 'left')
        df_FTP_Hist_Trigger_Date.fillna(0, axis=1, inplace=True)
        self.df_FTP_Hist_Trigger_Date = df_FTP_Hist_Trigger_Date


    # Грузим уровни пробития для каждой модели

    def Load_Treshold(self):
        logging.info(f' Грузим данные трешхолдам {self.path_model_Treshold}')

        # Грузим данные со значениями уровней для каждой модели
        df_treshold = pd.read_excel(self.path_model_Treshold, sheet_name='Treshold',engine='openpyxl')

        self.df_Treshold = df_treshold



    def Generate_FTP_Rec(self):
        # logging.info(f' Формируем рекомендации в self.Recommend')


        # Фичи и факторы
        df_Factor_Features = self.df_Factor_Features
        df_Dataset_Modif_Features = self.df_Dataset_Modif_Features


        Recomend = {}

        for model in Model_list:
            # logging.info(f'model = {model}')

            # список фичей для модели
            features_list = list(df_Factor_Features.loc[df_Factor_Features['model'] == model]['features'])

            # создаём df для описания рекомендаций
            df_rec = pd.DataFrame(index=df_Dataset_Modif_Features.index)

            # цикл по фичам
            for feature in features_list:
                #         logging.info(f'  feature = {feature}')

                # описание фичи
                # columns_set = ['left_red_zone_val', 'left_yellow_zone_val', 'left_criteria',
                #                'right_yellow_zone_val', 'right_red_zone_val', 'right_criteria',
                #                'res_criteria', 'coefs', 'feature_base']
                # df_feature_set = df_Factor_Features.loc[(df_Factor_Features['model'] == model) &
                #                                         (df_Factor_Features['features'] == feature)][columns_set]

                df_feature_set = df_Factor_Features.loc[(df_Factor_Features['model'] == model) &
                                                        (df_Factor_Features['features'] == feature)]

                # # определяем в какую сторону пробитие более важное
                # if float(df_feature_set['left_criteria']) >= float(df_feature_set['right_criteria']):
                #     # left
                #     direct = 'left'
                #     direct_mult = -1
                #     red_zone_val = float(df_feature_set['left_red_zone_val'])
                #     yellow_zone_val = float(df_feature_set['left_yellow_zone_val'])
                # else:
                #     # red
                #     direct = 'right'
                #     direct_mult = 1
                #     red_zone_val = float(df_feature_set['right_red_zone_val'])
                #     yellow_zone_val = float(df_feature_set['right_yellow_zone_val'])

                # определяем в какую сторону пробитие более важное

                mult_dic = {"right":1,"left":-1}


                direct_mult = mult_dic[str(df_feature_set['directions'].values[0])]

                red_zone_val = float(df_feature_set['red_val'])
                yellow_zone_val = float(df_feature_set['yellow_val'])

                #         logging.info(f'direct = {direct}')
                #         logging.info(f'direct_mult = {direct_mult}')
                #         logging.info(f'red_zone_val = {red_zone_val}')
                #         logging.info(f'yellow_zone_val = {yellow_zone_val}')

                df_rec[feature] = 0.0
                df_rec.loc[(df_Dataset_Modif_Features[feature] - yellow_zone_val) * direct_mult >= 0, feature] = 1 * \
                                                                                                                 Model_sign[
                                                                                                                     model] * float(df_feature_set['coefs'])
                df_rec.loc[(df_Dataset_Modif_Features[feature] - red_zone_val) * direct_mult >= 0, feature] = 2 * \
                                                                                                              Model_sign[
                                                                                                                  model] * float(df_feature_set['coefs'])

            # сохраняем в словарь c рекомендациями
            Recomend[model] = df_rec
        self.Recommend = Recomend


# Определяем df c рекомендациям в зависимости от конца кривой
def Get_Recomend_df(ftp_curve_part):
    # logging.info(f' Get_Recomend_df (ftp_curve_part = {ftp_curve_part})')

    # Определяем какой конец нам интересен
    if ftp_curve_part  == 'all':
        df_Down = Trigger.Recommend['short_down'].merge(Trigger.Recommend['long_down'], left_index = True, right_index = True)
        df_Up = Trigger.Recommend['short_up'].merge(Trigger.Recommend['long_up'], left_index = True, right_index = True)

    elif ftp_curve_part  == 'short':
        df_Down = Trigger.Recommend['short_down']
        df_Up = Trigger.Recommend['short_up']

    elif ftp_curve_part == 'long':
        df_Down = Trigger.Recommend['long_down']
        df_Up = Trigger.Recommend['long_up']



    return df_Up,df_Down


# ????????????????????????????????????????????????
def csv_from_Factor_Set():
    df = Trigger.df_Factor_Features
    csv_string = df.loc[:,df.columns != 'factor_file'].to_csv(index=True, encoding='utf8',sep = ';')
    #csv_string = df.to_csv(index=True, encoding='utf8',sep = ';')

    # csv_string = "data:text/csv;charset=utf-8,%EF%BB%BF" + quote(csv_string)
    csv_string = "data:text/csv;charset=utf-8,%EF%BB%BF"

    return csv_string



# Считываем в df данные по каталогк Hist_Change_Files
def Get_df_folder():

    # Формируем df c названиями папок в указанной выше директории
    df_folder = pd.DataFrame(os.listdir(materials_path), columns=['Dir_Name'])
    df_folder['ETC_date'] = pd.to_datetime(df_folder['Dir_Name'], format='%Y-%m-%d')
    # df_folder['ETC_date_WD_Name'] = df_folder['ETC_date'].dt.strftime('%a')
    df_folder['ETC_date_WD'] = df_folder.apply(lambda row: row['ETC_date'].dayofweek, axis=1)
    df_folder['ETC_date_Friday'] = df_folder['ETC_date']
    df_folder.loc[df_folder['ETC_date_WD'] != 4, 'ETC_date_Friday'] = df_folder['ETC_date'] + Week(weekday=4)
    # df_folder['ETC_date_Friday_WD'] = df_folder['ETC_date_Friday'].dt.strftime('%a')
    df_folder['ETC_date_Friday_str'] = df_folder['ETC_date_Friday'].dt.strftime('%Y-%m-%d')

    return df_folder

# Формируем описание фактора
def Factor_Value_desc(factor_name, value):

    # Описание факторов
    df_Factor_Dict = Trigger.df_Factor_Dict.loc[factor_name]

    # Опрделяем цифру
    if np.isnan(value):
        return None

    else:
        value_desc = value / df_Factor_Dict['measure_multip']
        decimal = int(df_Factor_Dict['decimal'])
        measure_short = df_Factor_Dict['measure_short']

        if df_Factor_Dict['measure'] == 'P':
            value_desc = round(value_desc, decimal)
            value_desc = f'{value_desc:.1%}'
        else:
            value_desc = int(round(value_desc, decimal))
            value_desc = f'{value_desc:,} {measure_short}'

    return value_desc


def to_numeric_df_Factor_set(df):
    numeric_columns = [
                     'Breaking_Down_Down',
                     'Breaking_Down_Up',
                     'Breaking_Up_Down',
                     'Breaking_Up_Up',
                     'Level_Red_1',
                     'Level_Yellow_1',
                     'Level_Green',
                     'Level_Yellow_2',
                     'Level_Red_2',
                     'measure_multip',
                     'graph_bottom',
                     'graph_top',
                     'sort']

    for i in numeric_columns:
        df[i] = pd.to_numeric(df[i])

    return df


## --- Подготавливаем объект с данными ---

# # Путь к директории с материалами
materials_path = "./data/Hist_Change_Files"
# # Заполняем get_df_folder
# df_folder = Get_df_folder()

# Создаём объект триггер

Trigger =   Trigger(Desc="Триггер по ЕТС RUB",
                    Hist_Start_date='2017-01-01',
                    Hist_Last_date= datetime.today().strftime('%Y-%m-%d'),
                    report_weekday_num = 4, #(4-пятница)

                    path_FTP_Hist="data//Target//Таргет.xlsx",
                    path_Factors_Dictionary="data//TriggerBSM_RUB_Data.xlsx",
                    path_Factors_Features_Levels="data//TriggerBSM_RUB_Data.xlsx",
                    path_Factor_Data="data//Navigator_old.xlsx",
                    path_model_Treshold="data//TriggerBSM_RUB_Data.xlsx",
                    path_Factor_Set="data"
                     )

# # Формируем датасет с набором дат, который потому будем заполнять
# Trigger.Create_df_Trigger_Date()
#
# # Грузим истоию факторов
# Trigger.Load_FactorSet()
#
# # Грузим историю ЕТС
# Trigger.Load_FTP_Hist()
#
# # Грузим данные факторов и фичей
# Trigger.Load_Factor_Data()
#
# # Собираем уровни проббития
# Trigger.Load_Treshold()
#
# # Генерим рекомендации
# Trigger.Generate_FTP_Rec()
