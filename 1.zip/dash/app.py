# dash/app.py
import logging
import os

import calc_provider
import dash_bootstrap_components as dbc

# Импорты для аудита
from audit.audit_logger import get_audit_logger
from audit.middleware import setup_user_context
from components.user_profile import UserProfileComponent
from flask import jsonify, session
from jwt_auth.auth_middleware import auth_middleware
from layouts import Upload_Data_layout, layout_tabs
from task_manager import task_manager  # Импортируем менеджер задач

import dash
from dash import dcc, html, no_update
from dash.dependencies import Input, Output, State

# Получаем базовый путь из переменной окружения
base_path = os.environ.get('PREFIX', '/')
# Обеспечиваем, чтобы путь всегда начинался с / и заканчивался на /
if not base_path.startswith('/'):
    base_path = '/' + base_path
if not base_path.endswith('/'):
    base_path += '/'

app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.DARKLY],
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
    # Dash при инициализации проверяет все callback-и и ищет компоненты, указанные в Input/Output
    # Кнопки находятся только на странице /compute, которая не отображается при старте приложения
    # Без suppress_callback_exceptions=True Dash не может найти компоненты при инициализации
    suppress_callback_exceptions=True,
    requests_pathname_prefix=base_path,  # Важно: добавляем префикс для запросов
    routes_pathname_prefix=base_path     # и для маршрутов
)
app.title = "Рекомендации по ЕТС"
server = app.server

# Ключ для создания сессии Flask
server.secret_key = "acae87c3-37f4-4c01-a36e-27781c4535b8"

# Регистрируем доп.маршруты - ДОЛЖНЫ БЫТЬ ДО ОПРЕДЕЛЕНИЯ LAYOUT!
# healthcheck endpoint
@server.route(f'{base_path}/api/health')
def healthcheck():
    return jsonify({"status": "OK"}), 200

# Добавляем middleware для установки контекста пользователя перед каждым запросом
@server.before_request
def before_request():
    setup_user_context()


# the style arguments for the sidebar. We use position:fixed and a fixed width
SIDEBAR_STYLE = {
    "position": "fixed",
    "top": 0,
    "left": 0,
    "bottom": 0,
    "width": "20rem",
    "padding": "2rem 1rem",
    "background-color": "#161a28",
}

# the styles for the main content position it to the right of the sidebar and
# add some padding.
CONTENT_STYLE = {
    "margin-left": "20rem",
    "margin-right": "2rem",
    "padding": "2rem 1rem",
}

sidebar = html.Div(
    [
        html.H2("AI - Казначей", className="display-6"),
        html.H2("Рекомендации по ЕТС", className="display-6"),
        html.H4("ЦТЦ", className="display-8"),
        html.Hr(),
        dbc.Nav(
            [dbc.NavLink("Описание", href=base_path, active="exact", className="nav-link-custom")],
            vertical=True,
            pills=True,
        ),
        html.Hr(),
        dbc.Nav([
            dbc.NavLink("Загрузка данных", href=f"{base_path}upload", active="exact", className="nav-link-custom"),
            dbc.NavLink("Fast Track", href=f"{base_path}fasttrack", active="exact", className="nav-link-custom"),
            dbc.NavLink("Анализ моделей", href=f"{base_path}dashboard", active="exact", className="nav-link-custom"),
            # TODO: удалить связанный функционал
            # dbc.NavLink("Вычисления", href=f"{base_path}compute", active="exact", className="nav-link-custom"),
            ],
            vertical=True,
            pills=True,
        ),
        html.Hr(),
        dbc.Nav(
            [dbc.NavLink("Информация", href=f"{base_path}settings", active="exact", className="nav-link-custom")],
            vertical=True,
            pills=True,
        ),
    ],

    style=SIDEBAR_STYLE,
)

# Основной layout приложения
app.layout = html.Div(
    className="app-container",
    children=[
        dcc.Location(id="url"),

        html.Div(id="sidebar-container", children=sidebar),

        html.Div(
            id="page-content",
            # className="content-container",
            style=CONTENT_STYLE
        ),
        dcc.Interval(
            id='task-status-check',
            interval=1000,  # Проверка статуса каждую секунду
            n_intervals=0,
            disabled=True
        ),
        dcc.Interval(
            id='fasttrack-run-status-check',
            interval=5000,  # Обновление каждые 5 секунд
            n_intervals=0,
            disabled=True
        ),
        dcc.Store(id='current-task-id', data=None),  # Хранилище для ID текущей задачи
        html.Div(id='compute-status', children='')  # Элемент для отображения статуса
    ]
)


# Auth-middleware
@app.callback(
    Output('url', 'pathname'),
    Input('url', 'pathname'),
    prevent_initial_call=True
)
def check_access_and_redirect(pathname):
    endpoints = [
        base_path,
        f'{base_path}upload',
        f'{base_path}fasttrack',
        f'{base_path}dashboard',
        f'{base_path}compute',
        f'{base_path}settings']
    if pathname in endpoints and not auth_middleware():
        return f'{base_path}error/403'
    else:
        return no_update


# Callback для изменения контента в зависимости от URL
@app.callback(
    Output("page-content", "children"),
    # Output("sidebar-container", "children"),
    [Input("url", "pathname")]
)
def render_page_content(pathname):
    logging.info(f'app.render_page_content: Отрисовываем страницы для выбранного sidebar (url = {pathname})')

    if pathname == base_path:
        return html.Div(
            className="home-container",
            children=[
                html.H2("AI-Казначей - Рекомендации по ЕТС - ЦТЦ", className="home-title"),
                html.P("Ключевой проект Казначейства, созданный для формирования рекомендаций по изменению ЕТС на основании балансовых и рыночных данных.", className="home-description"),
                html.P("Система решает задачи повышения объективности, комплексного учета и визуализации показателей и ускорения процесса изменения ЕТС.", className="home-instruction"),
                # Добавленное меню в виде списка
                html.Ul([
                    html.Li([html.Strong("Загрузка данных"), " - загрузка и управление данными"]),
                    html.Li([html.Strong("Fast Track"), " - расчет, представление и получение результатов модели"]),
                    html.Li([html.Strong("Анализ моделей"), " - анализ и визуализация моделей"]),
                    html.Li([html.Strong("Информация"), " - технические детали инфраструктурного характера"])
                ], className="menu-section")
            ]
        )

    elif pathname == f"{base_path}upload":
        return html.Div(
            id="upload-container",
            children=[Upload_Data_layout()],
                ),

    elif pathname == f"{base_path}fasttrack":
        return html.Div(
            id="fasttrack-container",
            children=[
                layout_tabs("tab5"),
                html.Div(id="app-content"),
            ],
        ),

    elif pathname == f"{base_path}dashboard":
        return html.Div(
            id="big-app-container",
            children=[
                html.Div(
                    id="app-container",
                    children=[
                        layout_tabs("tab4"),
                        html.Div(id="app-content"),
                    ],
                ),
            ]
        )
    elif pathname == f"{base_path}compute":
        return html.Div(
            className="compute-container",
            children=[
                html.H2("Вычислительные задачи", className="compute-title"),
                html.Div(
                    className="compute-controls",
                    children=[
                        dbc.Button(
                            "Создание аналитических отчетов",
                            id="btn-run-reports",
                            className="compute-btn",
                            n_clicks=0
                        ),
                        dbc.Button(
                            "Подготовка данных (заглушка 5 сек.)",
                            id="btn-prepare-data",
                            className="compute-btn",
                            n_clicks=0
                        ),
                        dbc.Button(
                            "Запуск модели (заглушка 7 сек.)",
                            id="btn-run-model",
                            className="compute-btn",
                            n_clicks=0
                        ),
                    ]
                ),
                html.Div(id="compute-status-output", className="compute-status")
            ]
        )

    elif pathname == f"{base_path}settings":
        user = session.get('user', {})  # Получаем данные пользователя из сессии
        return html.Div(
            className="settings-container",
            children=[
                html.H1("Информация", className="settings-title"),
                UserProfileComponent(user=user),  # Используем компонент профиля пользователя
            ]
        )

    elif pathname == f'{base_path}error/403':
        return html.Div(
            style={'left': '0', 'padding': '2rem 1rem', 'text_align': 'center'},
            children=[
                html.H1('403 — Permission Denied', className='text-danger'),
                html.P('У вас нет прав для доступа к запрашиваемому ресурсу.'),
            ],
        )

    # Если страница не найдена
    return html.Div(
        className="not-found-container",
        children=[
            html.H1("404: Страница не найдена", className="not-found-title"),
            html.Hr(className="not-found-divider"),
            html.P(f"Путь {pathname} не распознан...", className="not-found-description"),
            dbc.Button(
                "Вернуться на главную",
                href=base_path,
                className="not-found-button"
            )
        ]
    )


@app.callback(
    [Output('btn-run-reports', 'disabled'),
     Output('btn-prepare-data', 'disabled'),
     Output('btn-run-model', 'disabled'),
     Output('compute-status-output', 'children'),
     Output('task-status-check', 'disabled'),
     Output('current-task-id', 'data')],
    [Input('btn-run-reports', 'n_clicks'),
     Input('btn-prepare-data', 'n_clicks'),
     Input('btn-run-model', 'n_clicks')],
    prevent_initial_call=True
)
def run_compute_task(btn_reports, btn_data, btn_model):
    ctx = dash.callback_context

    if not ctx.triggered:
        return [False, False, False, '', True, None]

    trigger_info = ctx.triggered[0]
    button_id = trigger_info['prop_id'].split('.')[0]
    n_click_value = trigger_info['value']

    # Игнорируем вызовы при загрузке страницы (n_clicks = 0 или None)
    if n_click_value is None or n_click_value < 1:
        return [False, False, False, '', True, None]

    # Определяем тип операции
    operation_name = {
        'btn-prepare-data': 'Подготовка данных',
        'btn-run-reports': 'Создание аналитических отчетов',
        'btn-run-model': 'Запуск модели'
    }.get(button_id, 'Неизвестная операция')

    # Определяем целевую функцию
    target_function = {
        'btn-prepare-data': calc_provider.prepare_data,
        'btn-run-reports': calc_provider.main_processing,
        'btn-run-model': calc_provider.run_model
    }.get(button_id)

    if not target_function:
        return [False, False, False, f"Неизвестная операция: {button_id}", True, None]

    # Пишем в аудит начало операции
    get_audit_logger().audit_other_operation(
        description=f"Запуск операции '{operation_name}'",
        status="SUCCESS"
    )

    # Используем TaskManager для создания и запуска задачи
    task_id = task_manager.create_task(
        task_func=target_function,
        task_type=operation_name
    )

    return [True, True, True, f"Выполняется: {operation_name}...", False, task_id]


# Callback для проверки статуса задачи
@app.callback(
    [Output('btn-run-reports', 'disabled', allow_duplicate=True),
     Output('btn-prepare-data', 'disabled', allow_duplicate=True),
     Output('btn-run-model', 'disabled', allow_duplicate=True),
     Output('compute-status-output', 'children', allow_duplicate=True),
     Output('task-status-check', 'disabled', allow_duplicate=True)],
    [Input('task-status-check', 'n_intervals')],
    [State('current-task-id', 'data')],
    prevent_initial_call=True
)
def check_task_status(n_intervals, task_id):
    if not task_id:
        return [False, False, False, 'Нет активных задач', True]

    # Получаем статус задачи из TaskManager
    task_status = task_manager.get_task_status(task_id)

    if not task_status:
        return [False, False, False, 'Задача не найдена', True]

    # Получаем сообщение о статусе из TaskManager
    status_message = task_manager.get_task_result_message(task_id)

    if task_status['status'] == 'running':
        # Задача еще выполняется
        return dash.no_update
    else:
        # Задача завершена (успешно или с ошибкой)
        # Пишем в аудит завершение операции
        audit_status = "SUCCESS" if task_status['status'] == 'completed' else "FAIL"
        get_audit_logger().audit_other_operation(
            description=f"Задача '{task_id}' завершена со статусом: {task_status['status']}",
            status=audit_status
        )

        return [False, False, False, status_message, True]
