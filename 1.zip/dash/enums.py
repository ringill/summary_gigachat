from enum import Enum

class CalcState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    ERROR = "error"
    
class CalcMessage(Enum):
    IDLE = "Статус: Ожидание"
    RUNNING = "Статус: выполняется"
    COMPLETED = "Статус: завершено"
    ERROR = "Статус: ошибка!"