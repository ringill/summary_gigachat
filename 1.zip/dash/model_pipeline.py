import argparse
import datetime

from config import DataConfig, TableSaverMeta
from data_reader import load_data
from data_writer import write_data, write_to_archive, write_to_zip

from model.prepare_dataset import prepare_dataset
from model.run_model import run_model
from model.report_storage import SheetsStorage
from navigator.run_navigator import make_report
from navigator.navigator_funcs import res_archive_sheets

# здесь будем загружать данные, запускать расчеты и сохраняться

def argparser() -> argparse.ArgumentParser:
    
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--date', type=str, default="2025-07-04", help='дата в формате %Y-%m-%d')
    
    return parser

def run_data_preprocessing(data_config: DataConfig) -> None:
    
    # Загрузка данных для предобработки
    factors_daily = load_data(data_config.schema['factors_daily'])
    masterfile = load_data(data_config.schema['masterfile'])
    holidays = load_data(data_config.schema['holidays'])
    techfile = load_data(data_config.schema['techfile'])

    # Предобработка (от подневных к понедельным данным)
    data_weekly = prepare_dataset(
        ewi_etc_final_dev=factors_daily,
        factors_add_info=masterfile,
        holidays=holidays,
        techfile=techfile
    )
    
    # Запись результатов
    meta = [
        TableSaverMeta(df=data_weekly['factors_df'], cfg=data_config.schema['factors_weekly']),
        TableSaverMeta(df=data_weekly['lag_df'], cfg=data_config.schema['data_1_agg']),
        TableSaverMeta(df=data_weekly['nolag_df'], cfg=data_config.schema['data_1_agg_nolag'])
    ]
    write_data(meta)
    
def run_model_calculation(data_config: DataConfig) -> None:
    
    # Загрузка данных
    factors_weekly = load_data(data_config.schema['factors_weekly'])
    techfile = load_data(data_config.schema['techfile'])
    
    # Прогон модели
    model_storage = run_model(df_with_features=factors_weekly, df_total_info=techfile)
    
    # Запись результатов
    model_res = model_storage.merge_all_sheets()
    meta = []
    for sheet in model_res:
        meta.append(TableSaverMeta(df=model_res[sheet], cfg=data_config.schema[sheet]))
    write_data(meta)
        
def run_navigator(data_config: DataConfig) -> None:
    
    # Загрузка данных
    factors_dictionary = load_data(data_config.schema['factors_dictionary'])
    features_windows = load_data(data_config.schema['features_windows'])
    segments_res_archive = load_data(data_config.schema['segments_res_archive'])
    total_res_archive = load_data(data_config.schema['total_res_archive'])
    factors_lag_df = load_data(data_config.schema['data_1_agg'])
    factors_nolag_df = load_data(data_config.schema['data_1_agg_nolag'])
    
    # отсюда возьмем названия листов
    model_storage = SheetsStorage()
    
    # загрузка аутпута модели в структуру словаря
    model_data = {}
    for sheet in model_storage.sheets:
        model_data[sheet] = load_data(data_config.schema[sheet])
    
    # Создание отчета
    navigator_report = make_report(
        calc_date=data_config.calc_date,
        factors_dictionary=factors_dictionary,
        model_data=model_data,
        segments_res_archive=segments_res_archive,
        total_res_archive=total_res_archive,
        features_windows=features_windows,
        factors_act_data_df=factors_nolag_df,
        factors_lag_data_df=factors_lag_df,
        add_archive_data=True
    )
    
    # запись в архив
    write_to_archive(
        navigator_report=navigator_report,
        navig_report_cfg={
            'segments_report': data_config.schema['segments_res_archive'],
            'total_report': data_config.schema['total_res_archive']
        },
        res_archive_sheets=res_archive_sheets,
        calc_date=data_config.calc_date
    )
    
    # запись в файлы
    meta = []
    for report_name in navigator_report:
        report = navigator_report[report_name]
        for sheet in report:
            meta.append(TableSaverMeta(df=report[sheet], cfg=data_config.schema[sheet]))
    write_data(meta)
    
    # запись в zip
    navigator_report_cfg = [data_config.schema['navigator_segments_report'], data_config.schema['navigator_total_report']]
    write_to_zip(navigator_report_cfg)
    

if __name__ == "__main__":
    
    t0 = datetime.datetime.now().time()
    
    # берем аргументы
    args = argparser().parse_args()
    calc_date = args.date

    # глобальная конфигурация данных
    data_config = DataConfig(calc_date=calc_date)

    # --- Кусок предобработки данных ---
    run_data_preprocessing(data_config=data_config)
    
    # --- Кусок модельных расчетов ---
    run_model_calculation(data_config=data_config)
    
    # --- Кусок создания отчета для навигатора ---
    run_navigator(data_config=data_config)
    
    print(t0, '->', datetime.datetime.now().time())