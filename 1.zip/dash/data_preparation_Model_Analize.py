import logging
import os
from typing import Dict, List

import pandas as pd
from config import app_config
from KP.common.update_csv_target_new import update_target
from KP.Model_analysis.prepare_data_v2 import make_target

# # Словарь со знаком пробития
# Direction_sign = {'up':1,
#                   'down':-1
#                   }
#
# # Направление для каждой модели
# Model_sign = {'long_up': 1,
#               'long_down': -1,
#               'short_up': 1,
#               'short_down': -1}

# список моделей
Model_list = ['long_up', 'long_down', 'short_up', 'short_down']

# data\Model Version\2024-12-28 V2.2\Model_Analysis_Data
# os.path.join(default_verion_folder,Folder,Model_Analysis_Data)
class Model_Analysis:
    def __init__(self,
                 Desc = None,
                 Folder_Path = None,
                 excel_target_path = None,

                 Model_summary = None,
                 Factors_summary = None,
                 Block_summary = None

                 ):

        # Описание
        self.Desc = Desc
        # Папка с моделями
        self.Folder_Path = Folder_Path or app_config.default_version_folder
        # Папка с таргетом
        self.excel_target_path = excel_target_path or app_config.excel_target_path

        # Загруженная версия модели
        self.Folder = None

        # Данные анализа
        self.Model_summary = None      # Список факторов
        self.Factors_summary = None # Список фитч
        self.Block_summary = None

        # Данные истории
        self.total_dict = None
        self.csv_target_model = None

    def Load_Model_Analysis_data(self, version = None):
        logging.info(f'====================================================================================')
        logging.info(f'Вошли в загрузку  self.Folder ={self.Folder}.   version = {version}!')

        if version is None:
            need_load = True
            loading_version = self.Folder
        elif self.Folder == version:
            need_load = False
        else:
            need_load = True
            loading_version = version

        if need_load:
            # Грузим статистику по модели
            self.Get_Model_Data(version=loading_version)
            # Грузим данные для графиков
            self.Get_Data_for_Graph(version=loading_version)
            logging.info(f'Oбновили версию {self.Folder} на {loading_version}!')
            self.Folder = loading_version
        else:
            logging.info(f'Версия {self.Folder} загужена ранее')

        logging.info(f'====================================================================================')

    def Get_Model_Data(self, version):

        path = os.path.join(self.Folder_Path, version, 'model_stats', 'Blocks_summary.xlsx')
        self.Block_summary = pd.read_excel(path, sheet_name=None, engine='openpyxl')

        path = os.path.join(self.Folder_Path, version, 'model_stats', 'Factors_summary.xlsx')
        self.Factors_summary = pd.read_excel(path, sheet_name=None, engine='openpyxl')

        path = os.path.join(self.Folder_Path, version, 'model_stats', 'Model_summary.xlsx')
        self.Model_summary = pd.read_excel(path, sheet_name=None, engine='openpyxl')

    def Get_Data_for_Graph(self, version):

        # Список файлов с данными
        files_name_list = ['features', 'data_1_agg', 'data_2_modif', 'data_3_signals', 'data_ewi', 'ewi_threshold']

        total_dict = {}
        for key in files_name_list:
            file_path = os.path.join(self.Folder_Path, version, "csv", f'{key}.csv')
            total_dict[key] = pd.read_csv(file_path)

        self.total_dict = total_dict
        self.csv_target_model = update_target(self.excel_target_path, last_date='today', save=False, verbose=False)


    # def Prepare_data_for_Factor_Graph(self):
    #
    #     MODELS = [
    #         'short_up',
    #         'long_up',
    #         'short_down',
    #         'long_down'
    #     ]
    #
    #     BLOCKS = [
    #         'KFL',
    #         'KUL',
    #         'ALM',
    #         'MARKET',
    #         'SFL',
    #         'DUL'
    #     ]
    #
    #     # Загрузка таргета
    #     excel_target_path = '/Data/Target/Таргет.xlsx'
    #     targets_df = update_target(excel_target_path, last_date='today', save=False)
    #
    #
    #     return targets_df

def add_model_id(model_dict: Dict[str, pd.DataFrame], model: str, block: str) -> dict:

    n_model_dict = {}

    for key in model_dict:
        df = model_dict[key]
        df['model'] = model
        df['block'] = block
        n_model_dict[key] = df

    return n_model_dict

def concat_dfs_in_dicts(list_of_dicts: List[Dict[str, pd.DataFrame]], uni_keys=None) -> Dict[str, pd.DataFrame]:

    if uni_keys is None:
        uni_keys = list_of_dicts[0].keys()

    result = {}
    for key in uni_keys:
        result[key] = pd.concat([d.get(key) for d in list_of_dicts], ignore_index=True)

    return result

def rearrange_df(
    df,
    date_colname='report_date',
    new_data_colname='feature',
    new_date_colname='report_date',
    new_value_colname='value',
    new_model_colname='model',
    model=None
):

    df_ = df.copy()

    df_.set_index(date_colname, inplace=True)
    df_.drop(columns=['model'], inplace=True, errors='ignore')

    df_new = pd.DataFrame()
    for col in df_.columns:
        df_new = pd.concat([df_new, df_[col]])
        if new_data_colname not in df_new.columns:
            df_new[new_data_colname] = None
        df_new[new_data_colname] = df_new[new_data_colname].fillna(col)

    if model is not None:
        df_new[new_model_colname] = model

    df_new.reset_index(inplace=True)
    df_new.rename(columns = {0: new_value_colname, 'index': new_date_colname}, inplace=True)

    ORDERED_COLS = [new_date_colname]
    if model is not None:
        ORDERED_COLS.append(new_model_colname)
    ORDERED_COLS += [new_data_colname, new_value_colname]

    df_new = df_new[ORDERED_COLS]

    return df_new

def load_data_init_format(
    subfolder_path: str,
    target_path: str = None,
    verbose: bool = False
) -> Dict[str, pd.DataFrame]:

    # Разрешение пути к целевым данным
    resolved_target_path = target_path or app_config.excel_target_path

    # Константы для шаблонов имен файлов
    MODEL_FILE_TEMPLATE = 'KSmodel_v2'
    FACTORS_FILE_TEMPLATE = 'factors_weekly_lag'

    if verbose:
        logging.info(f'Entering subfolder: {subfolder_path}')

    # Определение путей
    csv_path = os.path.join(subfolder_path, 'csv')
    model_stats_path = os.path.join(subfolder_path, 'model_stats')

    # Проверка условий
    csv_cond = not os.path.exists(csv_path) or not os.listdir(csv_path)
    stats_cond = not os.path.exists(model_stats_path) or not os.listdir(model_stats_path)

    factors_df = pd.DataFrame()
    targets_df = pd.DataFrame()

    if csv_cond or stats_cond:
        data_list = []
        for entry in os.listdir(subfolder_path):
            entry_path = os.path.join(subfolder_path, entry)

            if MODEL_FILE_TEMPLATE in entry and not entry.startswith('~$'):
                if verbose:
                    logging.info(f'Processing model block: {entry_path}')

                parts = entry.split('_')
                model = '_'.join(parts[:2])
                block = parts[4].replace('.xlsx', '')

                block_data = pd.read_excel(entry_path, sheet_name=None)
                processed_data = add_model_id(model_dict=block_data, model=model, block=block)
                data_list.append(processed_data)

            elif FACTORS_FILE_TEMPLATE in entry:
                factors_df = pd.read_csv(entry_path)
                factors_df = rearrange_df(
                    df=factors_df,
                    new_data_colname='factor_origin',
                    new_value_colname='Value'
                )

        # Загрузка целевых данных
        if os.path.exists(resolved_target_path):
            targets_df = update_target(
                resolved_target_path,
                last_date='today',
                save=False,
                verbose=False
            )

        # Объединение данных
        combined_data = concat_dfs_in_dicts(
            data_list,
            uni_keys=['features', 'data_2_modif', 'data_3_signals', 'data_ewi', 'ewi_threshold']
        )

        combined_data.update({
            'data_1_agg': factors_df,
            'targets': targets_df
        })

        return combined_data

    return {}

def create_csv_files(total_dict: Dict[str, pd.DataFrame], subfolder_path: str) -> None:

    csv_path = os.path.join(subfolder_path, 'csv')
    csv_cond = not os.path.exists(csv_path) or len(os.listdir(csv_path)) == 0

    # csv_cond = os.path.basename(subfolder_path) == 'SU_New_925base_158'

    if csv_cond:

        os.makedirs(csv_path, exist_ok=True)

        for key in total_dict:
            if key != 'targets':
                total_dict[key].to_csv(os.path.join(csv_path, key+'.csv'), index=False)
            else:
                for MODEL in Model_list:
                    file_path = os.path.join(csv_path, 'target_'+MODEL+'.csv')
                    make_target(total_dict[key], MODEL).to_csv(file_path, index=False)



# Создаём модели
# Model_Current = Model_Analysis()

# Грузим данные
# Model_Current.Load_Model_Analysis_data()
